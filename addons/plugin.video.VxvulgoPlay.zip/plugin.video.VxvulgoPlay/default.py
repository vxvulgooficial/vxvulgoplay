# -*- coding: utf-8 -*-
import sys
try:
    import six
except:
    xbmc.executebuiltin("UpdateLocalAddons()")
    xbmc.executebuiltin("UpdateAddonRepos()")
    xbmc.executebuiltin('InstallAddon(script.module.six)')
    xbmc.executebuiltin('SendClick(11)')
    exit()
if six.PY2:
    reload(sys)
    sys.setdefaultencoding('utf8')
    from io import open
try:
    import cookielib
except ImportError:
    import http.cookiejar as cookielib
try:
    import urllib.parse as urllib
except ImportError:
    import urllib
try:
    import urllib2
except ImportError:
    import urllib.request as urllib2
import datetime
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
if six.PY3:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from urllib.parse import parse_qsl, urlparse
    from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
else:
    from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler
    from urlparse import urlparse, parse_qsl
    try:
        from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
    except:
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.executebuiltin("UpdateAddonRepos()")
        xbmc.executebuiltin('InstallAddon(script.module.kodi-six)')
        xbmc.executebuiltin('SendClick(11)')
        exit()
import threading
import re
import os
import base64
import codecs
import traceback
import time
import requests
import random
import sqlite3
import ast
import hashlib
import zlib
try:
    from urllib3.util.retry import Retry
except ImportError:
    from requests.packages.urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
try:
    import json
except:
    import simplejson as json
try:
    # Ativa DNS globalmente com múltiplos servidores
    from codec import DNSOverride
    DNSOverride(dns_servers=["1.1.1.1", "8.8.8.8", "9.9.9.9"])
except:
    pass

versao = '29.11.25.vx1'
donatemsg = '[B]Obrigado pela sua doação [COLOR gold]S2[/COLOR][/B]'
base_rc = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x65\x64\x65\x63\x61\x6e\x61\x69\x73\x2e\x63\x78'
WOVY_URL = '\x77\x34\x72\x44\x70\x73\x4f\x6b\x77\x35\x7a\x44\x6c\x4d\x4b\x7a\x77\x70\x5f\x43\x6f\x63\x4f\x51\x77\x71\x44\x43\x6c\x4d\x4b\x6b\x77\x71\x4c\x44\x69\x38\x4f\x57\x77\x70\x37\x44\x6f\x38\x4f\x43\x77\x36\x33\x44\x6b\x38\x4f\x61\x77\x36\x54\x43\x6d\x56\x37\x43\x71\x63\x4b\x55\x77\x35\x62\x44\x6c\x63\x4f\x59'
OVERFLIXTV_HOST = '\x6f\x76\x65\x72\x66\x6c\x69\x78\x74\x76\x2e\x63\x66\x64'

useragent = 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
sec_ch_ua = '"Google Chrome";v="131", "Not-A.Brand";v="8", "Chromium";v="131"'
compatible = 'C6D687E256371626E6F6464616D223531386F2D6F636E237F6279656D65727F666E29716C607163657A7162726F2F2A33707474786'
basedem = compatible[::-1]
CHBase = base64.b16decode(basedem).decode('utf-8')

addon = xbmcaddon.Addon()
addon_name = addon.getAddonInfo('name')
addon_id = xbmcaddon.Addon().getAddonInfo('id')
icon = addon.getAddonInfo('icon')
addon_version = addon.getAddonInfo('version')
canais_adultos = xbmcaddon.Addon().getSetting("canais_extra")
player_opt = xbmcaddon.Addon().getSetting("player_opt")
ffmpeg_opt = xbmcaddon.Addon().getSetting("ffmpeg_opt")
redecanais_opt = xbmcaddon.Addon().getSetting("redecanais_opt")
repeat_opt = xbmcaddon.Addon().getSetting("repeat_opt")
ch_layout = xbmcaddon.Addon().getSetting("ch_layout")
disable_canais_extra = xbmcaddon.Addon().getSetting("disable_canais_extra")
features_enable = xbmcaddon.Addon().getSetting("features_enable")
features_pass = xbmcaddon.Addon().getSetting("features_pass")
playlist_command = 'lsname'
translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
profile = translate(addon.getAddonInfo('profile')) if six.PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
favorites = os.path.join(profile, 'favorites.dat')
favoritos = xbmcaddon.Addon().getSetting("favoritos")
#CERT_FILE = translate('special://xbmc/system/certs/cacert.pem')
addon_data_path = translate(os.path.join('special://home/userdata/addon_data', addon_id))
watch_later_approved = {
    'tvshows': ['resolver1_tvshows=','resolver2_tvshows='],
    'episodes': ['resolver1_episodes=','resolver2_episodes=']
}
if not 'content_status' in globals():
    globals()["content_status"] = {
        'active_menu': 'unknown',
        'watch_later_url': 'unknown',
        'watch_later_name': 'unknown',
        'watch_later_season': 'unknown'
    }
if sys.argv[1] == 'donatemercadopago':
    import xbmc
    import webbrowser
    donatetext = '[B][COLOR white]DOAR[/COLOR] [COLOR gold]%s[/COLOR][/B]'
    dialog = xbmcgui.Dialog()
    donate = dialog.select(donatemsg, [donatetext%('R$ %s')%value for value in range(5,31)])
    android_action = 'StartAndroidActivity(,android.intent.action.VIEW,,%s)'
    if donate == 0:
        valor = 'https://mpago.la/1vSohb3'
        if xbmc.getCondVisibility('system.platform.windows'):#5
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#5
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 1:
        valor = 'https://mpago.la/2BGTnJz'
        if xbmc.getCondVisibility('system.platform.windows'):#6
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#6
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 2:
        valor = 'https://mpago.la/1toxKcu'
        if xbmc.getCondVisibility('system.platform.windows'):#7
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#7
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 3:
        valor = 'https://mpago.la/1JuqwoC'
        if xbmc.getCondVisibility('system.platform.windows'):#8
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#8
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 4:
        valor = 'https://mpago.la/22M7EVK'
        if xbmc.getCondVisibility('system.platform.windows'):#9
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#9
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 5:
        valor = 'https://mpago.la/2SWsUSM'
        if xbmc.getCondVisibility('system.platform.windows'):#10
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#10
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 6:
        valor = 'https://mpago.la/27qTDPZ'
        if xbmc.getCondVisibility('system.platform.windows'):#11
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#11
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 7:
        valor = 'https://mpago.la/1qNwS7j'
        if xbmc.getCondVisibility('system.platform.windows'):#12
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#12
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 8:
        valor = 'https://mpago.la/2pzM3jH'
        if xbmc.getCondVisibility('system.platform.windows'):#13
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#13
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 9:
        valor = 'https://mpago.la/2jEKXum'
        if xbmc.getCondVisibility('system.platform.windows'):#14
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#14
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 10:
        valor = 'https://mpago.la/1gYaNa1'
        if xbmc.getCondVisibility('system.platform.windows'):#15
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#15
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 11:
        valor = 'https://mpago.la/2NJ57dY'
        if xbmc.getCondVisibility('system.platform.windows'):#16
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#16
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 12:
        valor = 'https://mpago.la/2StB4BU'
        if xbmc.getCondVisibility('system.platform.windows'):#17
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#17
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 13:
        valor = 'https://mpago.la/1Pqgz3y'
        if xbmc.getCondVisibility('system.platform.windows'):#18
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#18
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 14:
        valor = 'https://mpago.la/1jgLHZT'
        if xbmc.getCondVisibility('system.platform.windows'):#19
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#19
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 15:
        valor = 'https://mpago.la/1UowrWh'
        if xbmc.getCondVisibility('system.platform.windows'):#20
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#20
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 16:
        valor = 'https://mpago.la/2hym37i'
        if xbmc.getCondVisibility('system.platform.windows'):#21
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#21
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 17:
        valor = 'https://mpago.la/2NpkzNY'
        if xbmc.getCondVisibility('system.platform.windows'):#22
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#22
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 18:
        valor = 'https://mpago.la/1SdWshX'
        if xbmc.getCondVisibility('system.platform.windows'):#23
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#23
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 19:
        valor = 'https://mpago.la/2aPxuth'
        if xbmc.getCondVisibility('system.platform.windows'):#24
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#24
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 20:
        valor = 'https://mpago.la/2pYMak2'
        if xbmc.getCondVisibility('system.platform.windows'):#25
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#25
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 21:
        valor = 'https://mpago.la/2SbGnhu'
        if xbmc.getCondVisibility('system.platform.windows'):#26
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#26
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 22:
        valor = 'https://mpago.la/2mNZueg'
        if xbmc.getCondVisibility('system.platform.windows'):#27
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#27
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 23:
        valor = 'https://mpago.la/1Mdd1Gd'
        if xbmc.getCondVisibility('system.platform.windows'):#28
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#28
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 24:
        valor = 'https://mpago.la/2fw9M2R'
        if xbmc.getCondVisibility('system.platform.windows'):#29
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#29
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 25:
        valor = 'https://mpago.la/1Bd4PLB'
        if xbmc.getCondVisibility('system.platform.windows'):#30
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):#30
            xbmc.executebuiltin(android_action%(valor))
    exit()

if sys.argv[1] == 'donatepaypal':
    import xbmc
    import webbrowser
    donatetext = '[B][COLOR white]DOAR[/COLOR] [COLOR gold]%s[/COLOR][/B]'
    dialog = xbmcgui.Dialog()
    donate = dialog.select(donatemsg, [donatetext%('R$ REAIS'), donatetext%('USD DOLAR')])
    android_action = 'StartAndroidActivity(,android.intent.action.VIEW,,%s)'
    if donate == 0:
        valor = 'https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=WDBB7ADQCPJQE&item_name=Streamer+S.A&currency_code=BRL&source=url'
        if xbmc.getCondVisibility('system.platform.windows'):
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin(android_action%(valor))
    elif donate == 1:
        valor = 'https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=WDBB7ADQCPJQE&item_name=Streamer+S.A&currency_code=USD&source=url'
        if xbmc.getCondVisibility('system.platform.windows'):
            webbrowser.open(valor)
        elif xbmc.getCondVisibility('system.platform.android'):
            xbmc.executebuiltin(android_action%(valor))
    exit()

if sys.argv[1] == 'donatepicpay':
    import xbmc
    import webbrowser
    android_action = 'StartAndroidActivity(,android.intent.action.VIEW,,%s)'
    valor = 'https://app.picpay.com/user/vxvulgoplay'
    if xbmc.getCondVisibility('system.platform.windows'):
        webbrowser.open(valor)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin(android_action%(valor))
    exit()

if sys.argv[1] == 'siteoficial':
    import xbmc
    import webbrowser
    valor = 'https://bit.ly/BRPLAYREPODL'
    android_action = 'StartAndroidActivity(,android.intent.action.VIEW,,%s)'
    if xbmc.getCondVisibility('system.platform.windows'):
        webbrowser.open(valor)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin(android_action%(valor))
    exit()

if sys.argv[1] == 'removerEPG':
    arquivo = os.path.join(profile, "epgbr.xml")
    exists = os.path.isfile(arquivo)
    if exists:
        try:
            os.remove(arquivo)
            xbmc.executebuiltin("Notification("+addon_name+", [B]EPG removido com sucesso![/B]"+",600,"+icon+")")
        except:
            pass
    else:
        xbmc.executebuiltin("Notification("+addon_name+", [B]EPG não encontrado.[/B]"+",600,"+icon+")")
    xbmcaddon.Addon().setSetting("epg_last", "")
    xbmc.sleep(2000)
    exit()

if sys.argv[1] == 'SetPass':
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    addon_data_path = translate(os.path.join('special://home/userdata/addon_data', addonID))
    if os.path.exists(addon_data_path)==False:
        os.mkdir(addon_data_path)
    xbmc.sleep(4)
    #Path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
    #arquivo = os.path.join(Path, "password.txt")
    arquivo = os.path.join(addon_data_path, "pass.txt")
    exists = os.path.isfile(arquivo)
    keyboard = xbmcaddon.Addon().getSetting("keyboard")
    if exists == False:
        password = '0000'
        p_encoded = base64.b64encode(password.encode()).decode('utf-8')
        p_file1 = open(arquivo,'w', encoding='utf-8')
        p_file1.write(p_encoded)
        p_file1.close()
        xbmc.sleep(4)
        p_file = open(arquivo,'r+', encoding='utf-8')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            ps2 = dialog.numeric(0, 'Insira a nova senha:')
            if ps2 != '':
                ps2_b64 = base64.b64encode(ps2.encode()).decode('utf-8')
                p_file = open(arquivo,'w', encoding='utf-8')
                p_file.write(ps2_b64)
                p_file.close()
                xbmc.executebuiltin("Notification("+addon_name+", [B]Senha alterada com sucesso![/B]"+",600,"+icon+")")
            else:
                xbmc.executebuiltin("Notification("+addon_name+", [B]Não foi possivel alterar a senha![/B]"+",600,"+icon+")")
        else:
            xbmc.executebuiltin("Notification("+addon_name+", [B]Senha invalida![/B]"+",600,"+icon+")")
    else:
        p_file = open(arquivo,'r+', encoding='utf-8')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            ps2 = dialog.numeric(0, 'Insira a nova senha:')
            if ps2 != '':
                ps2_b64 = base64.b64encode(ps2.encode()).decode('utf-8')
                p_file = open(arquivo,'w', encoding='utf-8')
                p_file.write(ps2_b64)
                p_file.close()
                xbmc.executebuiltin("Notification("+addon_name+", [B]Senha alterada com sucesso![/B]"+",600,"+icon+")")
            else:
                xbmc.executebuiltin("Notification("+addon_name+", [B]Não foi possivel alterar a senha![/B]"+",600,"+icon+")")
        else:
            xbmc.executebuiltin("Notification("+addon_name+", [B]Senha invalida![/B]"+",600,"+icon+")")
    exit()

if sys.argv[1] == 'limparFavoritos':
    arquivo = os.path.join(profile, "favorites.dat")
    exists = os.path.isfile(arquivo)
    if exists:
        try:
            os.remove(arquivo)
            xbmc.executebuiltin("Notification("+addon_name+", [B]Favoritos removido com sucesso![/B]"+",600,"+icon+")")
        except:
            pass
    else:
        xbmc.executebuiltin("Notification("+addon_name+", [B]Favoritos não encontrado![/B]"+",600,"+icon+")")
    xbmc.sleep(2000)
    exit()

if sys.argv[1] == 'controledospais':
    addon.setSettingBool(id='disable_canais_extra', value=True)
    xbmc.executebuiltin("Notification("+addon_name+", [B]Opção desativada![/B]"+",600,"+icon+")")
    exit()

addon_handle = int(sys.argv[1])

if os.path.exists(favorites)==True:
    FAV = open(favorites, 'r', encoding='utf-8').read()
else:
    FAV = {}

def hash_url(url):
    try:
        """Gera um hash SHA-256 de um URL para uso como chave de cache."""
        # Garante que a URL é tratada como bytes UTF-8 antes do hashing
        return hashlib.sha256(url.encode('utf-8')).hexdigest()
    except:
        return url

class CacheDatabase:
    """
    Gerencia as operações de cache síncronas usando SQLite.
    Foca na persistência (leitura, escrita, exclusão) de dados cacheados 
    para serem usados por futuras funções de conexão. Os dados de resposta
    são armazenados compactados via Zlib.
    """

    def __init__(self, db_name='cache.db'):
        self.db_name = db_name
        self.create_table()
        self.cleanup(optimize=True)
    
    def create_table(self):
        """Cria a tabela de cache se ela não existir, usando BLOB para dados compactados."""
        # Verifica se o caminho do diretório não está vazio (exclui o caso de ser 'cache.db' no dir atual)
        db_dir = os.path.dirname(self.db_name)
        if db_dir and not os.path.isdir(db_dir):
            try:
                # Se a pasta não existir, tente criá-la.
                os.makedirs(db_dir)
            except OSError as e:
                return False
        # Cria a tabela de cache
        try:
            with sqlite3.connect(self.db_name) as db:
                db.execute("""
                    CREATE TABLE IF NOT EXISTS cache (
                        url TEXT PRIMARY KEY,
                        method TEXT,
                        expire REAL,
                        response_text BLOB,
                        response_headers BLOB,
                        response_cookies BLOB
                    )
                """)
                # Tabela de controle de otimização
                db.execute("""
                    CREATE TABLE IF NOT EXISTS metadata (
                        key TEXT PRIMARY KEY,
                        value REAL
                    )
                """)
                db.commit()
        except sqlite3.Error:
            return False
    
    def check_optimization_status(self, db):
        """Verifica se o VACUUM pode ser executado (apenas uma vez a cada 24h)."""
        try:
            now = int(time.time())
            vacuum_interval = 86400
            
            # 1. Tenta ler o timestamp da última otimização
            cursor = db.execute("SELECT value FROM metadata WHERE key = 'last_vacuum'")
            last_vacuum_ts = cursor.fetchone()
            
            if last_vacuum_ts:
                last_vacuum_ts = last_vacuum_ts[0]
                # 2. Verifica se o intervalo mínimo já passou
                if (now - last_vacuum_ts) < vacuum_interval:
                    return False # Não execute o VACUUM, ainda não deu o tempo
            
            # 3. Se não existe ou se já passou do tempo, atualiza o timestamp e permite o VACUUM
            db.execute("INSERT OR REPLACE INTO metadata (key, value) VALUES ('last_vacuum', ?)", (now,))
            db.commit()
            return True # Execute o VACUUM
        except sqlite3.Error:
            return False
    
    def cleanup(self, optimize=False):
        """
        Remove entradas expiradas e, se 'optimize' for True, executa VACUUM
        somente se o intervalo mínimo de tempo tiver passado.
        """
        try:
            now_timestamp = int(time.time())
            
            with sqlite3.connect(self.db_name) as db:
                # 1. Deleta entradas expiradas
                db.execute("DELETE FROM cache WHERE expire < ?", (now_timestamp,))
                # db.commit() é feito ao sair do bloco 'with'
                
                # 2. Otimização (VACUUM)
                if optimize:
                    # Usa a função de controle de otimização persistente
                    if self.check_optimization_status(db):
                        # O VACUUM é custoso e só é executado aqui se o check permitir.
                        db.execute("VACUUM")
                
                db.commit()
        except sqlite3.Error:
            pass

    def get_cache(self, url, method):
        """
        Recupera dados cacheados de um URL e método específicos.
        """
        try:
            with sqlite3.connect(self.db_name) as db:
                cursor = db.execute("SELECT * FROM cache WHERE url = ? AND method = ?", (url, method))
                result = cursor.fetchone()
                if result:
                    return {
                        'expire': int(result[2]),
                        'response_text': result[3],
                        'response_headers': result[4],
                        'response_cookies': result[5]
                    }
                return None
        except sqlite3.Error:
            return None

    def delete_cache(self, url, method):
        """Remove uma entrada de cache específica."""
        try:
            with sqlite3.connect(self.db_name) as db:
                db.execute("DELETE FROM cache WHERE url = ? AND method = ?", (url, method))
                db.commit()
        except sqlite3.Error:
            pass

    def cache_limit(self, cache_config=None):
        """
        Calcula o timestamp de expiração com base na configuração de cache.
        """
        now = datetime.now()
        if not cache_config:
            return now + timedelta(minutes=60) # Padrão 60 minutos

        cache_format = cache_config.get('format')
        cache_limit_value = cache_config.get('limit')

        if cache_format == 'days':
            return now + timedelta(days=cache_limit_value)
        elif cache_format == 'hours':
            return now + timedelta(hours=cache_limit_value)
        elif cache_format == 'minutes':
            return now + timedelta(minutes=cache_limit_value)
        
        return now + timedelta(minutes=60)

    def save_cache(self, url, method, cache_config, 
                   response_headers, response_cookies, 
                   response_text):
        """
        Salva ou atualiza os dados da resposta no cache, usando Zlib para compressão.
        """
        expiration_time = self.cache_limit(cache_config)
        
        # 1. Serializa objetos complexos (headers/cookies) para string
        headers_str = str(response_headers)
        cookies_str = str(response_cookies)
        
        # 2. COMPRESSÃO ZLIB: Converte a string (utf-8) para bytes e comprime
        compressed_text = zlib.compress(response_text.encode('utf-8'))
        compressed_headers = zlib.compress(headers_str.encode('utf-8'))
        compressed_cookies = zlib.compress(cookies_str.encode('utf-8'))

        # Python 2.7
        compressed_text = buffer(compressed_text) if six.PY2 else compressed_text
        compressed_headers = buffer(compressed_headers) if six.PY2 else compressed_headers
        compressed_cookies = buffer(compressed_cookies) if six.PY2 else compressed_cookies

        # Cálculo do timestamp (compatível com Python 2.7)
        expire_timestamp = int(time.mktime(expiration_time.timetuple()))

        try:
            with sqlite3.connect(self.db_name) as db:
                cursor = db.execute("SELECT * FROM cache WHERE url = ? AND method = ?", (url, method))
                exists = cursor.fetchone()
                
                if not exists:
                    db.execute("""
                        INSERT INTO cache (url, method, expire, response_text, response_headers, response_cookies)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (url, method, expire_timestamp, compressed_text, compressed_headers, compressed_cookies))
                else:
                    db.execute("""
                        UPDATE cache SET expire = ?, response_text = ?, response_headers = ?, response_cookies = ?
                        WHERE url = ? AND method = ?
                    """, (expire_timestamp, compressed_text, compressed_headers, compressed_cookies, url, method))
                db.commit()
        except sqlite3.Error:
            pass

    def get_decoded_cache_data(self, cache_data):
        """
        Descomprime e desserializa os dados do cache recuperados do banco de dados.
        """
        try:
            # 1. DESCOMPRESSÃO ZLIB e Deserialização
            
            # Texto
            text_bytes = zlib.decompress(cache_data['response_text'])
            text = text_bytes.decode('utf-8')

            # Headers
            headers_bytes = zlib.decompress(cache_data['response_headers'])
            headers_str = headers_bytes.decode('utf-8')
            response_headers = ast.literal_eval(headers_str)
            
            # Cookies
            cookies_bytes = zlib.decompress(cache_data['response_cookies'])
            cookies_str = cookies_bytes.decode('utf-8')
            response_cookies = ast.literal_eval(cookies_str)
            
            return {
                'text': text,
                'headers': response_headers,
                'cookies': response_cookies,
                'expire': cache_data['expire']
            }
        except Exception as e:
            return {}

# --- Inicialização do Cache ---
cache_db_path = os.path.join(addon_data_path, 'cache.db')
cache_manager = CacheDatabase(db_name=cache_db_path)

def notify(message, timeShown=5000):
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (addon_name, message, timeShown, icon))

def monitor_switch():
    monitor = xbmc.Monitor()
    while True:
        if not monitor.waitForAbort(0.01):
            break

def corrigir_texto(texto, modo=None):
    if isinstance(texto, six.binary_type):
        texto = texto.decode('utf-8')
    if six.PY2:
        import HTMLParser
        parser = HTMLParser.HTMLParser()
    else:
        import html as parser
    texto = parser.unescape(texto)
    texto = texto.strip()
    if modo == 'upper':
        return texto.upper()
    elif modo == 'lower':
        return texto.lower()
    elif modo == 'title':
        return texto.title()
    return texto

def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = keyboard.getText()
        #search_string = to_unicode(keyboard.getText())
        search_string = search_clean(search_string).lower()
    return search_string

def update_dict(existing={}, pos=None, key='', value=''):
    keys = list(existing.keys())
    keys.insert(pos, key)
    return {k: existing.get(k, value) for k in keys}

def create_retry_session(
    total_retries=5,
    backoff_factor=0.3,
    status_forcelist=(429, 500, 502, 503, 504),
    session=None
):
    """
    :param total_retries: Total number of retry attempts before giving up.
    :param backoff_factor: Exponential backoff factor between retry attempts.
    :param status_forcelist: HTTP status codes that trigger retries.
    :param session: (Optional) Existing session to apply configuration to.
    """
    session = session or requests.Session()
    retry = Retry(
        total=total_retries,
        read=total_retries,
        connect=total_retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session

def DNSEntry(hostname, action):
    try:
        API_BASE_URL = "\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6a\x6c\x76\x66\x72\x64\x76\x7a\x78\x67\x77\x79\x78\x66\x71\x78\x65\x78\x6b\x64\x2e\x73\x75\x70\x61\x62\x61\x73\x65\x2e\x63\x6f\x2f\x72\x65\x73\x74\x2f\x76\x31\x2f"
        if action not in ['requests', 'responses']:
            return {"error": "O tipo de action deve ser 'requests' ou 'responses'."}
        request_headers = {
            '\x61\x70\x69\x6b\x65\x79': '\x65\x79\x4a\x68\x62\x47\x63\x69\x4f\x69\x4a\x49\x55\x7a\x49\x31\x4e\x69\x49\x73\x49\x6e\x52\x35\x63\x43\x49\x36\x49\x6b\x70\x58\x56\x43\x4a\x39\x2e\x65\x79\x4a\x70\x63\x33\x4d\x69\x4f\x69\x4a\x7a\x64\x58\x42\x68\x59\x6d\x46\x7a\x5a\x53\x49\x73\x49\x6e\x4a\x6c\x5a\x69\x49\x36\x49\x6d\x70\x73\x64\x6d\x5a\x79\x5a\x48\x5a\x36\x65\x47\x64\x33\x65\x58\x68\x6d\x63\x58\x68\x6c\x65\x47\x74\x6b\x49\x69\x77\x69\x63\x6d\x39\x73\x5a\x53\x49\x36\x49\x6d\x46\x75\x62\x32\x34\x69\x4c\x43\x4a\x70\x59\x58\x51\x69\x4f\x6a\x45\x33\x4d\x44\x67\x31\x4e\x7a\x6b\x33\x4e\x6a\x55\x73\x49\x6d\x56\x34\x63\x43\x49\x36\x4d\x6a\x41\x79\x4e\x44\x45\x31\x4e\x54\x63\x32\x4e\x58\x30\x2e\x62\x67\x6f\x4d\x73\x5a\x5f\x54\x4a\x6c\x6c\x44\x7a\x6b\x6f\x49\x58\x6c\x5a\x6a\x68\x4c\x67\x66\x49\x52\x38\x6a\x34\x76\x4d\x45\x75\x62\x69\x44\x67\x54\x55\x68\x43\x57\x34',
            '\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e': "\x42\x65\x61\x72\x65\x72\x20\x65\x79\x4a\x68\x62\x47\x63\x69\x4f\x69\x4a\x49\x55\x7a\x49\x31\x4e\x69\x49\x73\x49\x6e\x52\x35\x63\x43\x49\x36\x49\x6b\x70\x58\x56\x43\x4a\x39\x2e\x65\x79\x4a\x70\x63\x33\x4d\x69\x4f\x69\x4a\x7a\x64\x58\x42\x68\x59\x6d\x46\x7a\x5a\x53\x49\x73\x49\x6e\x4a\x6c\x5a\x69\x49\x36\x49\x6d\x70\x73\x64\x6d\x5a\x79\x5a\x48\x5a\x36\x65\x47\x64\x33\x65\x58\x68\x6d\x63\x58\x68\x6c\x65\x47\x74\x6b\x49\x69\x77\x69\x63\x6d\x39\x73\x5a\x53\x49\x36\x49\x6d\x46\x75\x62\x32\x34\x69\x4c\x43\x4a\x70\x59\x58\x51\x69\x4f\x6a\x45\x33\x4d\x44\x67\x31\x4e\x7a\x6b\x33\x4e\x6a\x55\x73\x49\x6d\x56\x34\x63\x43\x49\x36\x4d\x6a\x41\x79\x4e\x44\x45\x31\x4e\x54\x63\x32\x4e\x58\x30\x2e\x62\x67\x6f\x4d\x73\x5a\x5f\x54\x4a\x6c\x6c\x44\x7a\x6b\x6f\x49\x58\x6c\x5a\x6a\x68\x4c\x67\x66\x49\x52\x38\x6a\x34\x76\x4d\x45\x75\x62\x69\x44\x67\x54\x55\x68\x43\x57\x34",
            '\x50\x72\x65\x66\x65\x72': '\x72\x65\x74\x75\x72\x6e\x3d\x72\x65\x70\x72\x65\x73\x65\x6e\x74\x61\x74\x69\x6f\x6e'
        }
        s = create_retry_session()
        endpoint = "{}dnsresolver_{}".format(API_BASE_URL, action)
        if action == 'requests':
            agora = datetime.now().isoformat()
            json_data = {'hostname': hostname, 'created_at': agora}
            insert_response = s.post(endpoint, headers=request_headers, json=json_data, timeout=15)
            if insert_response.status_code in [200, 201]:
                return {"status": "success", "message": "Request enviado com sucesso."}
            elif insert_response.status_code == 409:
                return {"status": "exists", "message": "O hostname '{}' já existe na tabela dnsresolver_requests.".format(hostname)}
            else:
                return {"status": "error", "message": insert_response.text, "code": insert_response.status_code}
        elif action == 'responses':
            response = s.get("{}?hostname=eq.{}".format(endpoint, hostname), headers=request_headers, timeout=15)
            if response.status_code == 200:
                data = response.json()
                if data:
                    address = data[0]['address']
                    return {"status": "success", "hostname": hostname, "address": address}
                else:
                    return {"status": "not_found", "message": "Nenhum registro encontrado para hostname: {}".format(hostname)}
            else:
                return {"status": "error", "message": response.text, "code": response.status_code}
    except ValueError as ve:
        return {"status": "error", "message": str(ve)}
    except requests.exceptions.RequestException as e:
        return {"status": "error", "message": "Falha ao acessar a API.", "details": str(e)}
    except Exception as e:
        return {"status": "error", "message": "Erro inesperado.", "details": str(e)}

def resolve_dns(url):
    # Desabilitar avisos de segurança SSL
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    # Extract the domain name from the provided URL
    domain = urlparse(url).hostname
    endpoints = [
        ("https://one.one.one.one/dns-query", "1.1.1.1"),                # Cloudflare primary DNS
        ("https://dns.google/resolve", "8.8.8.8"),                       # Google primary DNS
        ("https://chrome.cloudflare-dns.com/dns-query", "172.64.41.3"),  # Cloudflare secondary DNS
        ("https://security.cloudflare-dns.com/dns-query", "1.1.1.2")     # Cloudflare secondary DNS
    ]
    params = {"name": domain, "type": "A"}  # Query for DNS type A (IPv4)
    dns_headers = {"Accept": "application/dns-json"}  # Expect response in JSON format
    for endpoint, proxy in endpoints:
        time.sleep(0.01)
        try:
            base_dns(endpoint, proxy)
            session = create_retry_session()
            response = session.get(endpoint, headers=dns_headers, params=params, timeout=10, verify=False)
            response.raise_for_status()
            dns_data = response.json()
            if "Answer" in dns_data:
                return dns_data["Answer"][-1].get("data", "")
        except Exception as e:
            pass
    timeout = 30
    start_time = time.time()
    while time.time() - start_time < timeout:
        result_response = DNSEntry(domain, 'responses')
        if result_response.get('status') == 'success':
            return result_response.get('address')
        elif result_response.get('status') == 'not_found':
            DNSEntry(domain, 'requests')
        time.sleep(5)
    return None

def getRequest(url,referer=False,origin=False,custom_useragent=False,CloudIP=False):
    try:
        request_headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'sec-ch-ua': sec_ch_ua,
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': custom_useragent or useragent
        }
        if referer:
            request_headers = update_dict(request_headers, 3, 'Referer', referer)
        if origin:
            request_headers = update_dict(request_headers, 3, 'Origin', origin)
        if CloudIP:
            request_headers.update(CloudIP)
        request = urllib2.Request(url, headers=request_headers)
        response = urllib2.urlopen(request).read().decode('utf-8')
        return response
    except:
        return ''

def getRequestv2(
    url,
    referer=None,
    origin=None,
    custom_useragent=None,
    post=None,
    head=False,
    cookies=None,
    getcookies=False,
    replace_headers=None,
    proxy=None,
    getrequest=False,
    remove_forcelist=None,
    timeout=15,
    verify=True
):
    try:
        import ssl
        import zlib
        request_headers = replace_headers if replace_headers else {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'sec-ch-ua': sec_ch_ua,
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': custom_useragent or useragent
        }
        if referer:
            request_headers = update_dict(request_headers, 3, 'Referer', referer)
        if origin:
            request_headers = update_dict(request_headers, 3, 'Origin', origin)
        data = urllib2.urlencode(post).encode() if post else None
        req = urllib2.Request(url, headers=request_headers, data=data)
        if head:
            req.get_method = lambda: 'HEAD'
        context = ssl.create_default_context()
        if not verify:
            context = ssl._create_unverified_context()
        try:
            with urllib2.urlopen(req, timeout=timeout, context=context) as response:
                raw_data = response.read()
                if response.info().get('Content-Encoding') == 'gzip':
                    raw_data = zlib.decompress(raw_data, 16+zlib.MAX_WBITS)
                elif response.info().get('Content-Encoding') == 'deflate':
                    raw_data = zlib.decompress(raw_data)
                result = raw_data.decode('utf-8')
                if getcookies:
                    return result, response.info().headers
                return result
        except urllib2.URLError as e:
            if isinstance(e.reason, ssl.SSLError):
                return getMovieData(url, referer, origin, custom_useragent, post, head, cookies, getcookies, replace_headers, proxy, getrequest, remove_forcelist, timeout, verify=False)
            return ''
        except ssl.SSLError as e:
            return getMovieData(url, referer, origin, custom_useragent, post, head, cookies, getcookies, replace_headers, proxy, getrequest, remove_forcelist, timeout, verify=False)
    except Exception as e:
        return ''

def getRedirect(url,referer=False,origin=False,custom_useragent=False):
    try:
        try:
            import urllib.request as urllib2
        except ImportError:
            import urllib2
        request_headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'sec-ch-ua': sec_ch_ua,
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': custom_useragent or useragent
        }
        if referer:
            request_headers = update_dict(request_headers, 3, 'Referer', referer)
        if origin:
            request_headers = update_dict(request_headers, 3, 'Origin', origin)
        request = urllib2.Request(url, headers=request_headers)
        response = urllib2.urlopen(request).geturl()
        return response
    except:
        pass

def getMovieData(
    url,
    referer=None,
    origin=None,
    custom_useragent=None,
    post=None,
    head=False,
    cookies=None,
    getcookies=False,
    replace_headers=None,
    append_headers=None,
    proxy=False,
    getrequest=False,
    remove_forcelist=None,
    timeout=15,
    verify=True,
    retry=True,
    cache=True
):
    try:
        method = 'POST' if post else 'HEAD' if head else 'GET'
        url_hash = hash_url(url)
        if cache:
            cache_data = cache_manager.get_cache(url_hash, method)
            if cache_data and cache_data['expire'] > int(time.time()):
                decoded_data = cache_manager.get_decoded_cache_data(cache_data)
                # Decodificar o texto e cookies/headers
                response = decoded_data['text']
                response_cookies = decoded_data['cookies']
                response_headers = decoded_data['headers']
                if head:
                    # Se for HEAD, retorna apenas os headers
                    return response_headers
                if getcookies:
                    # Se pedir cookies, retorna texto e cookies
                    return response, response_cookies
                # Retorno padrão: apenas o texto
                return response
        request_headers = replace_headers if replace_headers else {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'sec-ch-ua': sec_ch_ua,
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': custom_useragent or useragent
        }
        if referer:
            request_headers = update_dict(request_headers, 3, 'Referer', referer)
        if origin:
            request_headers = update_dict(request_headers, 3, 'Origin', origin)
        if append_headers:
            request_headers.update(append_headers)
        #if proxy:
        #    if isinstance(proxy, bool):
        #        proxy = resolve_dns(url)
        #    if proxy and not isinstance(proxy, bool):
        #        base_dns(url, proxy)
        if 'gist.githubusercontent.com' in url: # 429: Too Many Requests
            remove_forcelist = [429]
        status_forcelist = [429, 500, 502, 503, 504]
        if remove_forcelist:
            status_forcelist = [x for x in status_forcelist if x not in remove_forcelist]
        s = create_retry_session(status_forcelist=status_forcelist) if retry else requests
        try:
            import platform
            node = platform.node().lower()
        except:
            node = ''
        try:
            import certifi
            ssl_verify = certifi.where()
        except:
            ssl_verify = True
        if verify:
            verify = ssl_verify if not node == 'xboxone' else False
        if cookies and post:
            request = s.post(url, headers=request_headers, cookies=cookies, data=post, timeout=timeout, verify=verify)
        elif cookies:
            request = s.get(url, headers=request_headers, cookies=cookies, timeout=timeout, verify=verify)
        elif post:
            request = s.post(url, headers=request_headers, data=post, timeout=timeout, verify=verify)
        elif head:
            request = s.head(url, headers=request_headers, timeout=timeout, verify=verify)
            return request
        else:
            request = s.get(url, headers=request_headers, timeout=timeout, verify=verify)
            # Bit.ly Fix
            if urlparse(request.url).netloc == 'bit.ly':
                match = re.search('\x68\x72\x65\x66\x3d\x22\x28\x5b\x5e\x22\x5d\x2b\x29\x22\x5c\x73\x2b\x69\x64\x3d\x22\x61\x63\x74\x69\x6f\x6e\x3a\x63\x6f\x6e\x74\x69\x6e\x75\x65\x5f\x73\x6d\x22', request.text)
                if match: request = s.get(match.group(1), headers=request_headers, timeout=timeout, verify=verify)
        request.encoding = 'utf-8'
        response = request.text
        response_cookies = request.cookies.get_dict()
        response_headers = dict(request.headers)
        # Configuração de cache
        cache_config = {
            'limit': 60,
            'format': 'minutes'
        }
        # Salvar no Cache se a configuração foi fornecida e o status for 2xx (OK)
        if cache and 200 <= request.status_code < 300:
            cache_manager.save_cache(
                url_hash, 
                method, 
                cache_config, 
                response_headers, 
                response_cookies, 
                response
            )
        if getrequest:
            return request
        if getcookies:
            return response, response_cookies
        return response
    except requests.exceptions.SSLError as e:
        return getMovieData(url,referer,origin,custom_useragent,post,head,cookies,getcookies,replace_headers,proxy,getrequest,remove_forcelist,timeout,verify=False,retry=retry,cache=cache)
    except Exception as e:
        return ''

def Version_CloudRequest():
    try:
        verify = os.path.join(home+'\\cloudrequest\\requests_toolbelt', "__init__.py")
        with open(verify, encoding='utf-8') as f:
            ver = re.compile('\x5f\x5f\x76\x65\x72\x73\x69\x6f\x6e\x5f\x5f\x20\x3d\x20\x27\x28\x2e\x2a\x3f\x29\x27').findall(f.read())[0]
            if not ver == '1.0.0':
                import zipfile, io
                if six.PY3: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x33\x2e\x7a\x69\x70')
                if six.PY2: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x32\x2e\x7a\x69\x70', stream=True)
                z = zipfile.ZipFile(io.BytesIO(r.content))
                z.extractall(home)
    except:
        pass

def CloudRequest(url,referer=False,custom_useragent=False,CloudIP=False,CloudInfo=False,post=False,verify=True,cache=True):
    try:
        try:
            if os.path.exists(home+'\cloudrequest')==False:
                import zipfile, io
                if six.PY3: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x33\x2e\x7a\x69\x70')
                if six.PY2: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x32\x2e\x7a\x69\x70', stream=True)
                z = zipfile.ZipFile(io.BytesIO(r.content))
                z.extractall(home)
            else:
                Version_CloudRequest()
        except:
            notify('[B]Erro ao importar plugin![/B]')
        import cloudrequest
        method = 'POST' if post else 'GET'
        url_hash = hash_url(url)
        if cache:
            cache_data = cache_manager.get_cache(url_hash, method)
            if cache_data and cache_data['expire'] > int(time.time()):
                decoded_data = cache_manager.get_decoded_cache_data(cache_data)
                # Decodificar o texto e cookies/headers
                response = decoded_data['text']
                response_cookies = decoded_data['cookies']
                response_headers = decoded_data['headers']
                if CloudInfo:
                    # Se pedir cookies, retorna texto e cookies
                    return response, response_cookies
                # Retorno padrão: apenas o texto
                return response
        request_headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'sec-ch-ua': sec_ch_ua,
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': custom_useragent or useragent
        }
        if referer:
            request_headers = update_dict(request_headers, 3, 'Referer', referer)
        s = cloudrequest.create_scraper(
            sess=create_retry_session(),
            browser={'browser': 'firefox','platform': 'windows','mobile': False}
        )
        try:
            import platform
            node = platform.node().lower()
        except:
            node = ''
        try:
            import certifi
            ssl_verify = certifi.where()
        except:
            ssl_verify = True
        if verify:
            verify = ssl_verify if not node == 'xboxone' else False
        if CloudIP and post:
            request = s.post(url, headers=request_headers, cookies=CloudIP, data=post, timeout=15, verify=verify)
        elif CloudIP:
            request = s.get(url, headers=request_headers, cookies=CloudIP, timeout=15, verify=verify)
        elif post:
            request = s.post(url, headers=request_headers, data=post, timeout=15, verify=verify)
        else:
            request = s.get(url, headers=request_headers, timeout=15, verify=verify)
        request.encoding = 'utf-8'
        response = request.text
        response_cookies = request.cookies.get_dict()
        response_headers = dict(request.headers)
        # Configuração de cache
        cache_config = {
            'limit': 60,
            'format': 'minutes'
        }
        # Salvar no Cache se a configuração foi fornecida e o status for 2xx (OK)
        if cache and 200 <= request.status_code < 300:
            cache_manager.save_cache(
                url_hash, 
                method, 
                cache_config, 
                response_headers, 
                response_cookies, 
                response
            )
        if CloudInfo:
            return response,response_cookies
        else:
            return response
    except requests.exceptions.SSLError as e:
        return CloudRequest(url,referer,custom_useragent,CloudIP,CloudInfo,post,verify=False,cache=cache)
    except:
        return ''

def getWVMData(url,referer,custom_useragent,CloudIP=False,CloudInfo=False,post=False,verify=True):
    try:
        try:
            Path = home
            if os.path.exists(Path+'\cloudrequest')==False:
                import zipfile, io
                if six.PY3: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x33\x2e\x7a\x69\x70')
                if six.PY2: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x32\x2e\x7a\x69\x70', stream=True)
                z = zipfile.ZipFile(io.BytesIO(r.content))
                z.extractall(Path)
            else:
                Version_CloudRequest()
        except:
            notify('[B]Erro ao importar plugin![/B]')
        WOVY_URI = decode(features_pass, WOVY_URL)
        import cloudrequest
        request_headers = {}
        if '\x2f\x74\x76\x2f' in url:
            request_headers = {
                'Host':urlparse(url).netloc,
                'upgrade-insecure-requests':'1',
                'user-agent':custom_useragent,
                'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'x-requested-with':'\x63\x6f\x6d\x2e\x61\x70\x70\x2e\x77\x61\x74\x63\x68\x75\x67',
                'sec-fetch-site':'same-origin',
                'sec-fetch-mode':'navigate',
                'sec-fetch-user':'?1',
                'sec-fetch-dest':'document',
                'referer':referer,
                'accept-encoding':'gzip, deflate',
                'accept-language':'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
            }
        elif '\x61\x6a\x61\x78\x2f\x65\x6d\x62\x65\x64' in url or '/api/watch' in url:
            request_headers = {
                'Host':urlparse(url).netloc,
                'accept':'*/*',
                #'x-requested-with':'XMLHttpRequest',
                'x-requested-with':'\x63\x6f\x6d\x2e\x61\x70\x70\x2e\x77\x61\x74\x63\x68\x75\x67',
                'user-agent':custom_useragent,
                'content-type':'application/json',
                'origin':WOVY_URI,
                'sec-fetch-site':'same-origin',
                'sec-fetch-mode':'cors',
                'sec-fetch-dest':'empty',
                'referer':referer,
                'accept-encoding':'gzip, deflate',
                'accept-language':'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
            }
        elif 'proxy/m3u8' in url:
            request_headers = {
                'Host':urlparse(url).netloc,
                'upgrade-insecure-requests':'1',
                'user-agent':custom_useragent,
                'accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'x-requested-with':'\x63\x6f\x6d\x2e\x61\x70\x70\x2e\x77\x61\x74\x63\x68\x75\x67',
                'sec-fetch-site':'cross-site',
                'sec-fetch-mode':'navigate',
                'sec-fetch-user':'?1',
                'sec-fetch-dest':'iframe',
                'referer':'%s/'%WOVY_URI,
                'accept-encoding':'gzip, deflate',
                'accept-language':'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
            }
        else:
            request_headers = {
                'Host':urlparse(url).netloc,
                'user-agent':custom_useragent,
                'accept':'*/*',
                'origin':referer,
                'x-requested-with':'\x63\x6f\x6d\x2e\x61\x70\x70\x2e\x77\x61\x74\x63\x68\x75\x67',
                'sec-fetch-site':'same-site',
                'sec-fetch-mode':'cors',
                'sec-fetch-dest':'empty',
                'referer':referer + '/',
                'accept-encoding':'gzip, deflate',
                'accept-language':'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
            }
        s = cloudrequest.create_scraper(browser={'browser': 'firefox','platform': 'windows','mobile': False})
        if post:
            request = s.post(url, data=post, headers=request_headers, timeout=15, verify=verify)
        else:
            request = s.get(url, headers=request_headers, timeout=15, verify=verify)
        request.encoding = 'utf-8'
        response = request.text
        if CloudInfo:
            return response,request.cookies.get_dict()
        else:
            return response
    except requests.exceptions.SSLError as e:
        return getWVMData(url,referer,custom_useragent,CloudIP,CloudInfo,post,verify=False)
    except:
        return ''

def custom_proxy(host,referer='',origin='',post='',head='',cache='',headers=''):
    try:
        import ast
        params = {'action':'get'}
        if post:
            params.update({'action':'post'})
        if head:
            params.update({'action':'head'})
        params.update({'host':host,'referer':referer,'origin':origin,'post':post,'cache':cache,'headers':headers})
        params = str(base64.b64encode(str(params).encode('utf-8')).decode('utf-8'))
        res = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params))
        res = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(res)[0]
        if head:
            return ast.literal_eval(base64.b64decode(res.encode('utf-8')).decode('utf-8'))
        return base64.b64decode(res.encode('utf-8')).decode('utf-8')
    except:
        return ''

def features_checker():
    try:
        if six.PY3: import hashlib
        if six.PY3: from hmac import compare_digest
        if six.PY2: import hashlib
        if six.PY2: from hmac import compare_digest
        if six.PY2: import binascii
        SALT = b'l$k\xe1\x80\xfc\xee\xb5\xd6\xdc\xb1\xd3\xb8\x9ad7\xbf"8\x9b\x176\x1e\xed\xf1\x1a\x1f\xb2\x8d\xb9\xd0z'
        hashed_pw = 'caeecdb4fd0d61bedb64a98db944fb8f2d7f2f790f0d84d34a79c06972a99409'
        if six.PY3: hashed_pw_verify = hashlib.pbkdf2_hmac("sha256", features_pass.encode(), SALT, 4096).hex()
        if six.PY2: hashed_pw_verify = hashlib.pbkdf2_hmac("sha256", features_pass.encode(), SALT, 4096)
        if six.PY2: hashed_pw_verify = binascii.hexlify(hashed_pw_verify)
        if compare_digest(hashed_pw, hashed_pw_verify):
            return hashed_pw_verify
        return ''
    except:
        return ''

def SendUpdateLog(log,up=''):
    try:
        request_headers = {
            '\x61\x70\x69\x6b\x65\x79': '\x65\x79\x4a\x68\x62\x47\x63\x69\x4f\x69\x4a\x49\x55\x7a\x49\x31\x4e\x69\x49\x73\x49\x6e\x52\x35\x63\x43\x49\x36\x49\x6b\x70\x58\x56\x43\x4a\x39\x2e\x65\x79\x4a\x70\x63\x33\x4d\x69\x4f\x69\x4a\x7a\x64\x58\x42\x68\x59\x6d\x46\x7a\x5a\x53\x49\x73\x49\x6e\x4a\x6c\x5a\x69\x49\x36\x49\x6d\x70\x73\x64\x6d\x5a\x79\x5a\x48\x5a\x36\x65\x47\x64\x33\x65\x58\x68\x6d\x63\x58\x68\x6c\x65\x47\x74\x6b\x49\x69\x77\x69\x63\x6d\x39\x73\x5a\x53\x49\x36\x49\x6e\x4e\x6c\x63\x6e\x5a\x70\x59\x32\x56\x66\x63\x6d\x39\x73\x5a\x53\x49\x73\x49\x6d\x6c\x68\x64\x43\x49\x36\x4d\x54\x63\x77\x4f\x44\x55\x33\x4f\x54\x63\x32\x4e\x53\x77\x69\x5a\x58\x68\x77\x49\x6a\x6f\x79\x4d\x44\x49\x30\x4d\x54\x55\x31\x4e\x7a\x59\x31\x66\x51\x2e\x33\x33\x59\x50\x64\x63\x46\x54\x70\x6b\x35\x66\x6f\x32\x4d\x57\x34\x46\x75\x33\x6b\x68\x36\x32\x51\x6d\x61\x43\x39\x30\x37\x63\x4b\x75\x37\x49\x56\x32\x70\x61\x4f\x2d\x6f',
            '\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpsdmZyZHZ6eGd3eXhmcXhleGtkIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcwODU3OTc2NSwiZXhwIjoyMDI0MTU1NzY1fQ.33YPdcFTpk5fo2MW4Fu3kh62QmaC907cKu7IV2paO-o',
            '\x50\x72\x65\x66\x65\x72': '\x72\x65\x74\x75\x72\x6e\x3d\x72\x65\x70\x72\x65\x73\x65\x6e\x74\x61\x74\x69\x6f\x6e'
        }
        s = create_retry_session()
        agora = datetime.now()
        agora = agora.strftime("%d/%m/%y %H:%M:%S")
        if up:
            json_data = {'id': log.replace('\x73\x65\x72\x69\x65\x32\x3d','').replace('\x6d\x69\x78\x3d',''),'list': str(up)}
            request = s.post('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6a\x6c\x76\x66\x72\x64\x76\x7a\x78\x67\x77\x79\x78\x66\x71\x78\x65\x78\x6b\x64\x2e\x73\x75\x70\x61\x62\x61\x73\x65\x2e\x63\x6f\x2f\x72\x65\x73\x74\x2f\x76\x31\x2f\x75\x70\x64\x61\x74\x65\x73', headers=request_headers, json=json_data, timeout=15)
        else:
            request = s.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6a\x6c\x76\x66\x72\x64\x76\x7a\x78\x67\x77\x79\x78\x66\x71\x78\x65\x78\x6b\x64\x2e\x73\x75\x70\x61\x62\x61\x73\x65\x2e\x63\x6f\x2f\x72\x65\x73\x74\x2f\x76\x31\x2f\x75\x70\x64\x61\x74\x65\x73\x3f\x69\x64\x3d\x65\x71\x2e\x25\x73\x26\x73\x65\x6c\x65\x63\x74\x3d\x2a'%log, headers=request_headers, timeout=15)
            return request.text
    except:
        pass

def SendErrorLog(log):
    try:
        request_headers = {
            '\x61\x70\x69\x6b\x65\x79': '\x65\x79\x4a\x68\x62\x47\x63\x69\x4f\x69\x4a\x49\x55\x7a\x49\x31\x4e\x69\x49\x73\x49\x6e\x52\x35\x63\x43\x49\x36\x49\x6b\x70\x58\x56\x43\x4a\x39\x2e\x65\x79\x4a\x70\x63\x33\x4d\x69\x4f\x69\x4a\x7a\x64\x58\x42\x68\x59\x6d\x46\x7a\x5a\x53\x49\x73\x49\x6e\x4a\x6c\x5a\x69\x49\x36\x49\x6d\x70\x73\x64\x6d\x5a\x79\x5a\x48\x5a\x36\x65\x47\x64\x33\x65\x58\x68\x6d\x63\x58\x68\x6c\x65\x47\x74\x6b\x49\x69\x77\x69\x63\x6d\x39\x73\x5a\x53\x49\x36\x49\x6e\x4e\x6c\x63\x6e\x5a\x70\x59\x32\x56\x66\x63\x6d\x39\x73\x5a\x53\x49\x73\x49\x6d\x6c\x68\x64\x43\x49\x36\x4d\x54\x63\x77\x4f\x44\x55\x33\x4f\x54\x63\x32\x4e\x53\x77\x69\x5a\x58\x68\x77\x49\x6a\x6f\x79\x4d\x44\x49\x30\x4d\x54\x55\x31\x4e\x7a\x59\x31\x66\x51\x2e\x33\x33\x59\x50\x64\x63\x46\x54\x70\x6b\x35\x66\x6f\x32\x4d\x57\x34\x46\x75\x33\x6b\x68\x36\x32\x51\x6d\x61\x43\x39\x30\x37\x63\x4b\x75\x37\x49\x56\x32\x70\x61\x4f\x2d\x6f',
            '\x41\x75\x74\x68\x6f\x72\x69\x7a\x61\x74\x69\x6f\x6e': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImpsdmZyZHZ6eGd3eXhmcXhleGtkIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTcwODU3OTc2NSwiZXhwIjoyMDI0MTU1NzY1fQ.33YPdcFTpk5fo2MW4Fu3kh62QmaC907cKu7IV2paO-o',
            '\x50\x72\x65\x66\x65\x72': '\x72\x65\x74\x75\x72\x6e\x3d\x72\x65\x70\x72\x65\x73\x65\x6e\x74\x61\x74\x69\x6f\x6e'
        }
        s = create_retry_session()
        agora = datetime.now()
        agora = agora.strftime("%d/%m/%y %H:%M:%S")
        json_data = {'id': log,'day': agora}
        if log.startswith('\x6d\x69\x78\x3d'):
            request = s.post('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6a\x6c\x76\x66\x72\x64\x76\x7a\x78\x67\x77\x79\x78\x66\x71\x78\x65\x78\x6b\x64\x2e\x73\x75\x70\x61\x62\x61\x73\x65\x2e\x63\x6f\x2f\x72\x65\x73\x74\x2f\x76\x31\x2f\x6c\x6f\x67\x73\x32', headers=request_headers, json=json_data, timeout=15)
        else:
            request = s.post('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6a\x6c\x76\x66\x72\x64\x76\x7a\x78\x67\x77\x79\x78\x66\x71\x78\x65\x78\x6b\x64\x2e\x73\x75\x70\x61\x62\x61\x73\x65\x2e\x63\x6f\x2f\x72\x65\x73\x74\x2f\x76\x31\x2f\x6c\x6f\x67\x73', headers=request_headers, json=json_data, timeout=15)
        if request.status_code == 201 or request.status_code == 200:
            if not '.proxy_error' in log: notify('[B]Link não encontrado - reportado ao centro de logs.[/B]',1000)
        else:
            if not '.proxy_error' in log: notify('[B]Este link já foi reportado ao centro de logs.[/B]',1000)
    except:
        notify('[B]Falha ao reportado ao centro de logs.[/B]',1000)

def get_platform():
    try:
        if xbmc.getCondVisibility('system.platform.osx'):
            return "OSX"
        elif xbmc.getCondVisibility('system.platform.atv2'):
            return "ATV2"
        elif xbmc.getCondVisibility('system.platform.ios'):
            return "iOS"
        elif xbmc.getCondVisibility('system.platform.windows'):
            return "Windows"
        elif xbmc.getCondVisibility('system.platform.android'):
            return "Linux/Android"
        elif xbmc.getCondVisibility('system.platform.linux.raspberrypi'):
            return "Linux/RPi"
        elif xbmc.getCondVisibility('system.platform.linux'):
            return "Linux"
        else:
            return "Unknown" 
    except:
        return "Unknown"

def gerar_uuid5(string):
    import uuid
    namespace = uuid.UUID("12345678-1234-5678-1234-567812345678")
    return str(uuid.uuid5(namespace, string))

def localizar_water_later(stream):
    def remove_symbols(title):
        """Remove formatação para criar chave interna limpa"""
        return re.sub(r'\[.*?\]', '', title).strip()
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    folder = translate(os.path.join('special://home/userdata/addon_data', addonID))
    filepath = os.path.join(folder, "watch_later.json")
    formatos_video = [".mp4",".avi",".mkv",".webm",".ogv",".mpeg",".mov",".flv",".wmv"]
    # Verifica se o arquivo JSON existe
    if not os.path.exists(filepath):
        return stream
    # Carrega o JSON
    try:
        with codecs.open(filepath, "r", encoding="utf-8") as file:
            data = json.load(file)
    except Exception as e:
        xbmcgui.Dialog().notification("[B]Assistir mais tarde[/B]", "[B]Erro ao carregar[/B]", icon, 5000)
        return
    data = data.get('series', {})
    for series_name in data:
        seasons = data.get(series_name, {}).get('temporadas', {})
        for series_seasons in seasons:
            episodes = seasons.get(series_seasons, [])
            for series_episodes,episode_id in episodes:
                if episode_id == gerar_uuid5(stream) if not stream.startswith('watch_later=') else stream.split('watch_later=')[1]:
                    formatos_video = [".mp4",".avi",".mkv",".webm",".ogv",".mpeg",".mov",".flv",".wmv"]
                    url_episodio = os.path.join(folder, "watch_later", "series", remove_symbols(series_name), remove_symbols(series_seasons), series_episodes)
                    return url_episodio
    return stream

def watch_later_menu(mode=False):
    def normalize_key(key):
        """Remove caracteres especiais e espaços extras para comparação correta"""
        if six.PY2:
            key = key.strip().encode("utf-8") if isinstance(key, unicode) else key.strip()
        else:
            key = key.strip()
        return re.sub(r'\[.*?\]', '', key)
    def remove_symbols(title):
        """Remove formatação para criar chave interna limpa"""
        return re.sub(r'\[.*?\]', '', title).strip()
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    folder = translate(os.path.join('special://home/userdata/addon_data', addonID))
    filepath = os.path.join(folder, "watch_later.json")
    formatos_video = [".mp4",".avi",".mkv",".webm",".ogv",".mpeg",".mov",".flv",".wmv"]
    # Verifica se o arquivo JSON existe
    if not os.path.exists(filepath):
        xbmcgui.Dialog().notification("[B]Assistir mais tarde[/B]", "[B]Não há conteúdos salvos![/B]", icon, 5000)
        return
    # Carrega o JSON
    try:
        with codecs.open(filepath, "r", encoding="utf-8") as file:
            data = json.load(file)
    except Exception as e:
        xbmcgui.Dialog().notification("[B]Assistir mais tarde[/B]", "[B]Erro ao carregar[/B]", icon, 5000)
        return
    # Adiciona o menu das séries
    if not mode:
        params = [
            ('FILMES','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x64\x31\x31\x79\x37\x33\x73\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x6a\x77\x72\x31\x51\x37\x50\x2e\x6a\x70\x67'),
            ('ANIMES','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x67\x79\x68\x49\x34\x43\x62\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x32\x74\x36\x4e\x37\x75\x6b\x2e\x6a\x70\x67'),
            ('SERIES','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x43\x54\x69\x79\x65\x35\x6f\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x71\x49\x47\x59\x55\x77\x53\x2e\x6a\x70\x67'),
            ('DORAMAS','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x41\x63\x72\x6b\x5a\x6e\x45\x2e\x70\x6e\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x6d\x61\x67\x65\x2e\x74\x6d\x64\x62\x2e\x6f\x72\x67\x2f\x74\x2f\x70\x2f\x6f\x72\x69\x67\x69\x6e\x61\x6c\x2f\x37\x42\x6f\x52\x68\x67\x38\x7a\x58\x50\x30\x63\x61\x39\x5a\x71\x6c\x34\x70\x38\x6c\x6c\x43\x46\x52\x32\x50\x2e\x6a\x70\x67'),
            ('DESENHOS','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x58\x61\x74\x4d\x69\x6b\x4f\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x58\x32\x47\x4d\x33\x54\x68\x2e\x6a\x70\x67'),
            ('NOVELAS','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x6e\x4a\x31\x48\x47\x71\x57\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x6f\x56\x56\x49\x39\x37\x55\x2e\x6a\x70\x67')
        ]
        for selected,thumbnail,fanart in params:
            selected_search = selected.lower()
            quantity = len(data.get(selected_search, {}))
            addDir('[B][COLOR gold]●[/COLOR] [COLOR white]%s[/COLOR] [COLOR blue](%s)[/COLOR][/B]'%(selected,quantity),selected_search,18,thumbnail,fanart,'[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, os conteúdos que são salvos para assistir mais tarde ficam todos reunidos aqui para assistir quando quiser.[/COLOR][/B]','','')
    if mode and mode.startswith('show_temps='):
        # Adiciona o menu das temporadas
        mode,serie_name = mode.split('show_temps=')[1].split('|')
        # Buscar a chave correspondente no JSON
        for key in data.get(mode, {}):
            if normalize_key(key) == normalize_key(serie_name):
                serie_name = key  # Usa a chave exata do JSON
                break
        serie_info = data.get(mode, {}).get(serie_name, {})
        thumbnail = serie_info.get('thumbnail', '')
        fanart = serie_info.get('fanart', '')
        description = serie_info.get('description', '')
        for key, item in serie_info.items():
            if key == 'thumbnail' or key == 'fanart' or key == 'description':
                continue
            for temporada in sorted(item):
                url_temporada = "show_episodes={}|{}|{}".format(mode, serie_name, temporada)
                addDir(temporada, url_temporada, mode=18, iconimage=thumbnail, fanart=fanart, description=description, genre="", date="")
    elif mode and mode.startswith('show_episodes='):
        # Adiciona o menu das temporadas
        mode,serie_name,temporada = mode.split('show_episodes=')[1].split('|')
        # Buscar a chave correspondente no JSON
        for key in data.get(mode, {}):
            if normalize_key(key) == normalize_key(serie_name):
                serie_name = key  # Usa a chave exata do JSON
                break
        serie_info = data.get(mode, {}).get(serie_name, {})
        # Buscar chave correspondente no JSON
        for key in serie_info.get('temporadas', {}):
            if normalize_key(key) == normalize_key(temporada):
                temporada = key  # Usa a chave exata que existe no JSON
                break
        thumbnail = serie_info.get('thumbnail', '')
        fanart = serie_info.get('fanart', '')
        description = serie_info.get('description', '')
        addonID = xbmcaddon.Addon().getAddonInfo('id')
        base_folder = translate(os.path.join('special://home/userdata/addon_data', addonID))
        # Adiciona os episódios dentro da temporada
        for episodio,episodio_id in sorted(serie_info.get('temporadas', {}).get(temporada, {})):
            url_episodio = 'watch_later=%s'%episodio_id #os.path.join(base_folder, "watch_later", mode, remove_symbols(serie_name), remove_symbols(temporada), episodio)
            episodio = [episodio.replace(ep,'') for ep in formatos_video][0]
            addLink('[B]%s[/B]'%episodio, url_episodio, mode=16, iconimage=thumbnail, fanart=fanart, description=description, genre="", date="")
    elif mode:
        for series_name in sorted(data.get(mode, {})):
            # Buscar a chave correspondente no JSON
            serie_data = data.get(mode, {}).get(series_name, {})
            thumbnail = serie_data.get('thumbnail', '')
            fanart = serie_data.get('fanart', '')
            description = serie_data.get('description', '')
            uri = '{}|{}'.format(mode, series_name)
            if 'unknown' in serie_data['temporadas']:
                addonID = xbmcaddon.Addon().getAddonInfo('id')
                base_folder = translate(os.path.join('special://home/userdata/addon_data', addonID))
                # Adiciona os episódios dentro da temporada
                for episodio,episodio_id in sorted(serie_data['temporadas']['unknown']):
                    episodio = [episodio.replace(ep,'') for ep in formatos_video][0]
                    url_episodio = 'watch_later=%s'%episodio_id #os.path.join(base_folder, "watch_later", mode, series_name, 'unknown', episodio)
                    addLink('[B]%s[/B]'%episodio, url_episodio, mode=16, iconimage=thumbnail, fanart=fanart, description=description, genre="", date="")
            else:
                addDir(series_name, 'show_temps=%s'%uri, 18, thumbnail, fanart, description, '', '')

def watch_later_downloader(url, url_resolver, series_name, temporada, filename_base, thumbnail, fanart, description):
    def extract_header_value(url, header_name):
        value = url.split(header_name)[1]
        try:
            value = value.split("&")[0]
        except:
            pass
        try:
            value = unquote_plus(value)
        except:
            pass
        try:
            value = unquote(value)
        except:
            pass
        return value
    def remove_symbols(title):
        """Remove formatação para criar chave interna limpa"""
        return re.sub(r'\[.*?\]', '', title).strip()
    active_menu = content_status['active_menu']
    if active_menu == 'unknown':
        xbmcgui.Dialog().notification("[B]Assistir mais tarde[/B]", "[B]Categoria não encontrada - Volte ao menu anterior e tente novamente.[/B]", icon, 5000)
        return
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    base_folder = translate(os.path.join('special://home/userdata/addon_data', addonID))
    folder = os.path.join(base_folder, "watch_later", active_menu, remove_symbols(series_name), remove_symbols(temporada))
    if not os.path.exists(folder):  # Verifica se a pasta já existe
        os.makedirs(folder)  # Cria a pasta se não existir
    # Obter headers
    headers = {
        "User-Agent": useragent,
        "Connection": "keep-alive"
    }
    if '|' in url:
        if "User-Agent=" in url:
            headers["User-Agent"] = extract_header_value(url, "User-Agent=")
        if "Referer=" in url:
            headers["Referer"] = extract_header_value(url, "Referer=")
        if "Origin=" in url:
            headers["Origin"] = extract_header_value(url, "Origin=")
        url = url.split('|')[0] # Extrair url
    response = requests.get(url, stream=True, headers=headers)
    content_type = response.headers.get("Content-Type", "")
    # Lista de formatos de vídeo suportados
    formatos_video = {
        "video/mp4": "mp4",
        "video/x-msvideo": "avi",
        "video/x-matroska": "mkv",
        "video/webm": "webm",
        "video/ogg": "ogv",
        "video/mpeg": "mpeg",
        "video/quicktime": "mov",
        "video/x-flv": "flv",
        "video/x-ms-wmv": "wmv"
    }
    # Determina a extensão do vídeo
    extensao = formatos_video.get(content_type, "mp4")  # Se não identificado, usa mp4 como padrão
    filename_base = remove_symbols(filename_base)
    filename = "{}.{}".format(filename_base, extensao)  # Adiciona a extensão ao nome do episódio
    filepath = os.path.join(folder, filename)
    # Verifica se o arquivo já existe
    if os.path.exists(filepath):
        xbmcgui.Dialog().notification("[B]Download Cancelado[/B]", "[B]{} já existe.[/B]".format(filename_base), icon, 5000)
        return
    dialog = xbmcgui.DialogProgress()
    dialog.create("[B]Download Manager[/B]", "[B]Baixando {}[/B]".format(filename_base))
    total_size = int(response.headers.get("Content-Length", 0))
    downloaded_size = 0
    start_time = time.time()
    try:
        with open(filepath, "wb") as file:
            for chunk in response.iter_content(chunk_size=1024 * 1024):  # Lê 1 MB por vez
                if not chunk:
                    break
                file.write(chunk)
                downloaded_size += len(chunk)
                elapsed_time = time.time() - start_time
                speed = (float(downloaded_size) / elapsed_time) / (1024 * 1024) if elapsed_time > 0 else 0
                progress = (float(downloaded_size) / float(total_size)) * 100 if total_size > 0 else 0
                dialog.update(int(progress), "[B]Progresso: {:.2f}%[CR]Velocidade: {:.2f} MB/s[/B]".format(progress, speed))
                if dialog.iscanceled():
                    xbmcgui.Dialog().notification("[B]Download Cancelado[/B]", "[B]O usuário cancelou o download.[/B]", icon, 5000)
                    raise Exception("Cancelado pelo usuário")
        dialog.close()
        xbmcgui.Dialog().notification("[B]Download Concluído[/B]", "[B]{} foi baixado com sucesso![/B]".format(filename_base), icon, 5000)
        # Salva informações no JSON com a extensão correta do episódio
        watch_later_json(series_name, url_resolver, temporada, filename, thumbnail, fanart, description)
    except Exception:
        if os.path.exists(filepath):
            os.remove(filepath)  # Remove apenas o arquivo de vídeo, mantendo a pasta intacta
        dialog.close()
        xbmcgui.Dialog().notification("[B]Download Cancelado[/B]", "[B]O arquivo foi excluído.[/B]", icon, 5000)

def watch_later_json(series_name, url_resolver, temporada, filename, thumbnail, fanart, description):
    active_menu = content_status['active_menu']
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    folder = translate(os.path.join('special://home/userdata/addon_data', addonID))
    if not os.path.exists(folder):  
        os.makedirs(folder)  
    filepath = os.path.join(folder, "watch_later.json")
    existing_data = {}
    if os.path.exists(filepath):
        try:
            with codecs.open(filepath, "r", encoding="utf-8") as file:
                existing_data = json.load(file)
        except Exception:
            existing_data = {}
    if six.PY2 and isinstance(series_name, str):
        series_name = unicode(series_name, "utf-8")
    # Criar chave limpa para referência interna
    if active_menu not in existing_data:
        existing_data[active_menu] = {}
    # Verificar se a chave limpa já existe no JSON
    if series_name not in existing_data[active_menu]:
        existing_data[active_menu][series_name] = {
            "thumbnail": thumbnail,
            "fanart": fanart,
            "description": description,
            "temporadas": {}
        }
    # Adicionar temporada
    if temporada not in existing_data[active_menu][series_name]["temporadas"]:
        existing_data[active_menu][series_name]["temporadas"][temporada] = []
    # Adicionar episódio na temporada
    if filename not in existing_data[active_menu][series_name]["temporadas"][temporada]:
        existing_data[active_menu][series_name]["temporadas"][temporada].append((filename,gerar_uuid5(url_resolver)))
    # Salvar JSON atualizado
    with codecs.open(filepath, "w", encoding="utf-8") as file:
        json.dump(existing_data, file, indent=4)
    #xbmcgui.Dialog().notification("[B]Assistir mais tarde[/B]", "[B]Salvo com sucesso![/B]", icon, 5000)

def watch_later_delete(stream):
    def remove_symbols(title):
        """Remove formatação para criar chave interna limpa"""
        return re.sub(r'\[.*?\]', '', title).strip()
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    folder = translate(os.path.join('special://home/userdata/addon_data', addonID))
    filepath = os.path.join(folder, "watch_later.json")
    # Verifica se o arquivo JSON existe
    if not os.path.exists(filepath):
        xbmcgui.Dialog().notification("[B]Assistir mais tarde[/B]", "[B]Não há conteúdos salvos![/B]", icon, 5000)
        return
    # Carrega o JSON
    try:
        with codecs.open(filepath, "r", encoding="utf-8") as file:
            data = json.load(file)
    except Exception as e:
        xbmcgui.Dialog().notification("[B]Assistir mais tarde[/B]", "[B]Erro ao carregar[/B]", icon, 5000)
        return
    episode_id = gerar_uuid5(stream) if not stream.startswith('watch_later=') else stream.split('watch_later=')[1]
    data_series = data.get('series', {})
    series_to_remove = []
    for series_name, series_data in list(data_series.items()):  # Evita erro de modificação do dicionário
        seasons = series_data.get('temporadas', {})
        seasons_to_remove = []
        for season_name, episodes in list(seasons.items()):  # Evita erro de modificação do dicionário
            # Localizando o filename do episódio pelo ID antes de remover
            filename = None
            for ep_data in episodes:
                if ep_data[1] == episode_id:
                    filename = ep_data[0]  # Pega o nome do arquivo
                    break
            # Removendo episódio pelo ID
            seasons[season_name] = [ep for ep in episodes if ep[1] != episode_id]
            # Construindo o caminho completo do arquivo
            if filename:
                file_path = os.path.join(folder, 'watch_later', 'series', remove_symbols(series_name), remove_symbols(season_name), filename)
                # Removendo arquivo físico
                if os.path.exists(file_path):
                    try:
                        os.remove(file_path)
                        xbmcgui.Dialog().notification("[B]Sucesso[/B]", "[B]Arquivo '%s' removido![/B]"%filename, icon, 5000)
                    except Exception as e:
                        xbmcgui.Dialog().notification("[B]Erro[/B]", "Não foi possível remover o arquivo: %s"%filename, icon, 5000)
                        return
                else:
                    xbmcgui.Dialog().notification("[B]Aviso[/B]", "[B]Arquivo '%s' não encontrado![/B]"%filename, icon, 5000)
            # Se a temporada ficou vazia, marcá-la para remoção
            season_path = os.path.join(folder, 'watch_later', 'series', remove_symbols(series_name), remove_symbols(season_name))
            if not seasons[season_name]:  
                seasons_to_remove.append(season_name)
                # Verificar e remover a pasta da temporada
                if os.path.exists(season_path) and not os.listdir(season_path):
                    try:
                        os.rmdir(season_path)
                    except Exception as e:
                        pass
        # Removendo temporadas vazias fora do loop
        for season_name in seasons_to_remove:
            del seasons[season_name]
        # Se todas as temporadas forem removidas, marcar série para remoção
        if not seasons:
            series_to_remove.append(series_name)
    # Removendo séries vazias e suas pastas físicas
    for series_name in series_to_remove:
        del data_series[series_name]
        # Caminho da pasta da série
        series_path = os.path.join(folder, 'watch_later', 'series', remove_symbols(series_name))
        if os.path.exists(series_path):
            try:
                if not os.listdir(series_path):  # Verifica se realmente está vazia
                    os.rmdir(series_path)
            except Exception as e:
                pass
    # Salvar JSON atualizado
    with codecs.open(filepath, "w", encoding="utf-8") as file:
        json.dump(data, file, indent=4, sort_keys=True)
    xbmc.executebuiltin("Container.Refresh()")
    #xbmcgui.Dialog().notification("[B]Assistir mais tarde[/B]", "[B]Episódio removido![/B]", icon, 5000)

class helpers:
    @staticmethod
    def append_headers(headers):
        return '|%s' % '&'.join(['%s=%s' % (key, urllib.quote_plus(headers[key])) for key in headers])
    @staticmethod
    def get_packed_data(html):
        import jsunpack
        packed_data = ''
        for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
            r = match.group(1)
            t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
            if len(t) == 1:
                if jsunpack.detect(r):
                    packed_data += jsunpack.unpack(r)
            else:
                t = r.split('eval')
                t = ['eval' + x for x in t if x]
                for r in t:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
        return packed_data
    @staticmethod
    def get_hunter_data(html):
        import jsunhunt
        import binascii
        jsunhunt_data = ''
        for match in re.finditer(r'''(eval\s*\(function\(h,u,n,t,e,r.*?)</script>''', html, re.DOTALL | re.I):
            r = match.group(1)
            t = re.findall(r'(eval\s*\(function\(h,u,n,t,e,r)', r, re.DOTALL | re.IGNORECASE)
            if len(t) == 1:
                jsunhunt_data += jsunhunt.unhunt(html)
            else:
                t = r.split('eval')
                t = ['eval' + x for x in t if x]
                for r in t:
                    jsunhunt_data += jsunhunt.unhunt(html)
        if re.findall('\x62\x6c\x61\x7a\x65\x5c\x28\x22\x28\x2e\x2b\x3f\x29\x22\x5c\x29', jsunhunt_data.replace("'",'"'), re.DOTALL|re.I):
            jsunhunt_data = re.findall('\x62\x6c\x61\x7a\x65\x5c\x28\x22\x28\x2e\x2b\x3f\x29\x22\x5c\x29', jsunhunt_data.replace("'",'"'), re.DOTALL|re.I)[0]
            jsunhunt_data = base64.b64decode(jsunhunt_data).decode('utf-8')
            if six.PY3: s = base64._bytes_from_decode_data(jsunhunt_data.replace('%',''))
            if six.PY2: s = refresh.replace('%','')
            jsunhunt_data = binascii.unhexlify(s).decode('utf-8').replace('\n','').replace('\r','')
        return jsunhunt_data
    @staticmethod
    def get_redirect_url(url, headers={}, form_data=None):
        from six.moves import urllib_parse, urllib_request, urllib_error
        class NoRedirection(urllib_request.HTTPRedirectHandler):
            def redirect_request(self, req, fp, code, msg, headers, newurl):
                return None
        if form_data:
            if isinstance(form_data, dict):
                form_data = urllib_parse.urlencode(form_data)
            request = urllib_request.Request(url, six.b(form_data), headers=headers)
        else:
            request = urllib_request.Request(url, headers=headers)
        opener = urllib_request.build_opener(NoRedirection())
        try:
            response = opener.open(request, timeout=20)
        except urllib_error.HTTPError as e:
            response = e
        return response.headers.get('location') or url
    @staticmethod
    def girc(page_data, url, co=None):
        """
        Code adapted from https://github.com/vb6rocod/utils/
        Copyright (C) 2019 vb6rocod
        and https://github.com/addon-lab/addon-lab_resolver_Project
        Copyright (C) 2021 ADDON-LAB, KAR10S
        """
        from six.moves import urllib_parse, urllib_request, urllib_error
        def b64encode(b):
            return six.ensure_str(base64.b64encode(b if isinstance(b, bytes) else six.b(b)))
        hdrs = {'User-Agent': resolvers.useragent,
                'Referer': url}
        rurl = 'https://www.google.com/recaptcha/api.js'
        aurl = 'https://www.google.com/recaptcha/api2'
        key = re.search(r'(?:src="{0}\?.*?render|data-sitekey)="?([^"]+)'.format(rurl), page_data)
        if key:
            if co is None:
                co = b64encode((url[:-1] + ':443')).replace('=', '')
            key = key.group(1)
            rurl = '{0}?render={1}'.format(rurl, key)
            page_data1 = getMovieData(rurl, replace_headers=hdrs)
            v = re.findall('releases/([^/]+)', page_data1)[0]
            rdata = {'ar': 1,
                     'k': key,
                     'co': co,
                     'hl': 'en',
                     'v': v,
                     'size': 'invisible',
                     'cb': '123456789'}
            page_data2 = getMovieData('{0}/anchor?{1}'.format(aurl, urllib_parse.urlencode(rdata)), replace_headers=hdrs)
            rtoken = re.search('recaptcha-token.+?="([^"]+)', page_data2)
            if rtoken:
                rtoken = rtoken.group(1)
            else:
                return ''
            pdata = {'v': v,
                     'reason': 'q',
                     'k': key,
                     'c': rtoken,
                     'sa': '',
                     'co': co}
            hdrs.update({'Referer': aurl})
            page_data3 = getMovieData('{0}/reload?k={1}'.format(aurl, key), post=pdata, replace_headers=hdrs)
            gtoken = re.search('rresp","([^"]+)', page_data3)
            if gtoken:
                return gtoken.group(1)
        return ''
    @staticmethod
    def sort_sources_list(sources):
        if len(sources) > 1:
            try:
                sources.sort(key=lambda x: int(re.sub(r"\D", "", x[0])), reverse=True)
            except:
                try:
                    sources.sort(key=lambda x: re.sub("[^a-zA-Z]", "", x[0].lower()))
                except:
                    pass
        return sources
def tear_decode(data_file, data_seed):
    from ctypes import c_int32 as i32
    import re

    def replacer(match):
        chars = {
            '0': '5',
            '1': '6',
            '2': '7',
            '5': '0',
            '6': '1',
            '7': '2'
        }
        return chars[match.group(0)]

    def str2bytes(a16):
        a21 = []
        for i in a16:
            a21.append(ord(i))
        return a21

    def bytes2str(a10):
        a13 = 0
        a14 = len(a10)
        a15 = ''
        while True:
            if a13 >= a14:
                break
            a15 += chr(255 & a10[a13])
            a13 += 1
        return a15

    def digest_pad(a36):
        a41 = []
        a39 = 0
        a40 = len(a36)
        a43 = 15 - (a40 % 16)
        a41.append(a43)
        while a39 < a40:
            a41.append(a36[a39])
            a39 += 1
        a45 = a43
        while a45 > 0:
            a41.append(0)
            a45 -= 1
        return a41

    def blocks2bytes(a29):
        a34 = []
        a33 = 0
        a32 = len(a29)
        while a33 < a32:
            a34 += [255 & rshift(i32(a29[a33]).value, 24)]
            a34 += [255 & rshift(i32(a29[a33]).value, 16)]
            a34 += [255 & rshift(i32(a29[a33]).value, 8)]
            a34 += [255 & a29[a33]]
            a33 += 1
        return a34

    def bytes2blocks(a22):
        a27 = []
        a28 = 0
        a26 = 0
        a25 = len(a22)
        while True:
            a27.append(((255 & a22[a26]) << 24) & 0xFFFFFFFF)
            a26 += 1
            if a26 >= a25:
                break
            a27[a28] |= ((255 & a22[a26]) << 16 & 0xFFFFFFFF)
            a26 += 1
            if a26 >= a25:
                break
            a27[a28] |= ((255 & a22[a26]) << 8 & 0xFFFFFFFF)
            a26 += 1
            if a26 >= a25:
                break
            a27[a28] |= (255 & a22[a26])
            a26 += 1
            if a26 >= a25:
                break
            a28 += 1
        return a27

    def xor_blocks(a76, a77):
        return [a76[0] ^ a77[0], a76[1] ^ a77[1]]

    def unpad(a46):
        a49 = 0
        a52 = []
        a53 = (7 & a46[a49])
        a49 += 1
        a51 = (len(a46) - a53)
        while a49 < a51:
            a52 += [a46[a49]]
            a49 += 1
        return a52

    def rshift(a, b):
        return (a % 0x100000000) >> b

    def tea_code(a79, a80):
        a85 = a79[0]
        a83 = a79[1]
        a87 = 0

        for a86 in range(32):
            a85 += i32((((i32(a83).value << 4) ^ rshift(i32(a83).value, 5)) + a83) ^ (a87 + a80[(a87 & 3)])).value
            a85 = i32(a85 | 0).value
            a87 = i32(a87).value - i32(1640531527).value
            a83 += i32(
                (((i32(a85).value << 4) ^ rshift(i32(a85).value, 5)) + a85) ^ (a87 + a80[(rshift(a87, 11) & 3)])).value
            a83 = i32(a83 | 0).value
        return [a85, a83]

    def binarydigest(a55):
        a63 = [1633837924, 1650680933, 1667523942, 1684366951]
        a62 = [1633837924, 1650680933]
        a61 = a62
        a66 = [0, 0]
        a68 = [0, 0]
        a59 = bytes2blocks(digest_pad(str2bytes(a55)))
        a65 = 0
        a67 = len(a59)
        while a65 < a67:
            a66[0] = a59[a65]
            a65 += 1
            a66[1] = a59[a65]
            a65 += 1
            a68[0] = a59[a65]
            a65 += 1
            a68[1] = a59[a65]
            a65 += 1
            a62 = tea_code(xor_blocks(a66, a62), a63)
            a61 = tea_code(xor_blocks(a68, a61), a63)
            a64 = a62[0]
            a62[0] = a62[1]
            a62[1] = a61[0]
            a61[0] = a61[1]
            a61[1] = a64

        return [a62[0], a62[1], a61[0], a61[1]]

    def ascii2bytes(a99):
        a2b = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7, 'I': 8, 'J': 9, 'K': 10,
               'L': 11, 'M': 12, 'N': 13, 'O': 14, 'P': 15, 'Q': 16, 'R': 17, 'S': 18, 'T': 19, 'U': 20,
               'V': 21, 'W': 22, 'X': 23, 'Y': 24, 'Z': 25, 'a': 26, 'b': 27, 'c': 28, 'd': 29, 'e': 30,
               'f': 31, 'g': 32, 'h': 33, 'i': 34, 'j': 35, 'k': 36, 'l': 37, 'm': 38, 'n': 39, 'o': 40,
               'p': 41, 'q': 42, 'r': 43, 's': 44, 't': 45, 'u': 46, 'v': 47, 'w': 48, 'x': 49, 'y': 50,
               'z': 51, '0': 52, '1': 53, '2': 54, '3': 55, '4': 56, '5': 57, '6': 58, '7': 59, '8': 60,
               '9': 61, '-': 62, '_': 63}
        a6 = -1
        a7 = len(a99)
        a9 = 0
        a8 = []

        while True:
            while True:
                a6 += 1
                if a6 >= a7:
                    return a8
                if a99[a6] in a2b.keys():
                    break
            a8.insert(a9, i32(i32(a2b[a99[a6]]).value << 2).value)
            while True:
                a6 += 1
                if a6 >= a7:
                    return a8
                if a99[a6] in a2b.keys():
                    break
            a3 = a2b[a99[a6]]
            a8[a9] |= rshift(i32(a3).value, 4)
            a9 += 1
            a3 = (15 & a3)
            if (a3 == 0) and (a6 == (a7 - 1)):
                return a8
            a8.insert(a9, i32(a3).value << 4)
            while True:
                a6 += 1
                if a6 >= a7:
                    return a8
                if a99[a6] in a2b.keys():
                    break
            a3 = a2b[a99[a6]]
            a8[a9] |= rshift(i32(a3).value, 2)
            a9 += 1
            a3 = (3 & a3)
            if (a3 == 0) and (a6 == (a7 - 1)):
                return a8
            a8.insert(a9, i32(a3).value << 6)
            while True:
                a6 += 1
                if a6 >= a7:
                    return a8
                if a99[a6] in a2b.keys():
                    break
            a8[a9] |= a2b[a99[a6]]
            a9 += 1

        return a8

    def ascii2binary(a0):
        return bytes2blocks(ascii2bytes(a0))

    def tea_decode(a90, a91):
        a95 = a90[0]
        a96 = a90[1]
        a97 = i32(-957401312).value
        for a98 in range(32):
            a96 = i32(a96).value - ((((i32(a95).value << 4) ^ rshift(i32(a95).value, 5)) + a95) ^ (
                a97 + a91[(rshift(i32(a97).value, 11) & 3)]))
            a96 = i32(a96 | 0).value
            a97 = i32(a97).value + 1640531527
            a97 = i32(a97 | 0).value
            a95 = i32(a95).value - i32(
                (((i32(a96).value << 4) ^ rshift(i32(a96).value, 5)) + a96) ^ (a97 + a91[(a97 & 3)])).value
            a95 = i32(a95 | 0).value
        return [a95, a96]

    if data_seed is None or data_file is None:
        return ''

    data_seed = re.sub('[012567]', replacer, data_seed)
    new_data_seed = binarydigest(data_seed)
    new_data_file = ascii2binary(data_file)
    a69 = 0
    a70 = len(new_data_file)
    a71 = [1633837924, 1650680933]
    a73 = [0, 0]
    a74 = []
    while a69 < a70:
        a73[0] = new_data_file[a69]
        a69 += 1
        a73[1] = new_data_file[a69]
        a69 += 1
        a72 = xor_blocks(a71, tea_decode(a73, new_data_seed))
        a74 += a72
        a71[0] = a73[0]
        a71[1] = a73[1]
    return re.sub('[012567]', replacer, bytes2str(unpad(blocks2bytes(a74))))

class resolvers:
    useragent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36'
    @classmethod
    def blogger(self, web_url):
        html = getMovieData(web_url, custom_useragent=self.useragent)
        if '<div class="errorMessage">' in html:
            return 'not found'
        match = re.search(r'var\s+VIDEO_CONFIG\s*=\s*(\{.*?\})\s*</script>', html, re.DOTALL)
        if not match:
            return None
        try:
            video_config = json.loads(match.group(1))
            for stream in video_config.get("streams", []):
                if str(stream.get("format_id")) in ['22', '18']:
                    play_url = stream.get("play_url")
                    return "{}|User-Agent={}&Referer={}".format(play_url, self.useragent, play_url)
        except Exception:
            pass
        return 'not found'
    @classmethod
    def vinovo(self, host, media_id, subs=False):
        from six.moves import urllib_parse, urllib_request, urllib_error
        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': self.useragent, 'Referer': web_url}
        html = getMovieData(web_url, replace_headers=headers)
        t = re.search(r'name="token"\s*content="([^"]+)', html)
        s = re.search(r'<video.+?data-base="([^"]+)', html)
        if subs:
            subtitles = {}
            su = re.search(r'<track.+?src="([^"]+)"\s*srclang="([^"]+)', html)
            if su:
                subtitles.update({su.group(2): su.group(1)})
        if t and s:
            rurl = urllib_parse.urljoin(web_url, '/')
            recaptcha = helpers.girc(html, rurl)
            headers.update({
                'Origin': rurl[:-1],
                'Referer': rurl,
                'X-Requested-With': 'XMLHttpRequest'
            })
            payload = {
                'token': t.group(1),
                'recaptcha': recaptcha
            }
            api_url = 'https://vinovo.to/api/file/url/{0}'.format(media_id)
            resp = getMovieData(api_url, post=payload, replace_headers=headers)
            resp = json.loads(resp)
            if resp.get('status') == 'ok':
                headers.pop('X-Requested-With')
                vid_src = '{0}/stream/{1}'.format(s.group(1), resp.get('token')) + helpers.append_headers(headers)
                if subs:
                    return vid_src#, subtitles
                return vid_src
        return 'not found'
    @classmethod
    def doodstream(self, host, media_id, subs=False):
        from six.moves import urllib_parse
        def dood_decode(data):
            import string
            t = string.ascii_letters + string.digits
            return data + ''.join([random.choice(t) for _ in range(10)])
        if host not in ['doodstream.com', 'vidply.com', 'all3do.com', 'vide0.net', 'dsvplay.com']:
            host = 'dsvplay.com'
        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': self.useragent,
                   'Referer': 'https://{0}/'.format(host)}
        r = getMovieData(web_url, replace_headers=headers, getrequest=True)
        if r.url != web_url:
            host = re.findall(r'(?://|\.)([^/]+)', r.url)[0]
            web_url = self.get_url(host, media_id)
        headers.update({'Referer': web_url})
        r.encoding = 'utf-8'
        html = r.text
        match = re.search(r'<iframe\s*src="([^"]+)', html)
        if match:
            url = urllib_parse.urljoin(web_url, match.group(1))
            html = getMovieData(url, replace_headers=headers)
        else:
            url = web_url.replace('/d/', '/e/')
            html = getMovieData(url, replace_headers=headers)
        if subs:
            subtitles = {}
            matches = re.findall(r"""dsplayer\.addRemoteTextTrack\({src:'([^']+)',\s*label:'([^']*)',kind:'captions'""", html)
            if matches:
                matches = [(src, label) for src, label in matches if len(label) > 1]
                for src, label in matches:
                    subtitles[label] = 'https:' + src if src.startswith('//') else src
        match = re.search(r'''dsplayer\.hotkeys[^']+'([^']+).+?function\s*makePlay.+?return[^?]+([^"]+)''', html, re.DOTALL)
        if match:
            token = match.group(2)
            url = urllib_parse.urljoin(web_url, match.group(1))
            html = getMovieData(url, replace_headers=headers)
            if 'cloudflarestorage.' in html:
                vid_src = html.strip() + helpers.append_headers(headers)
            else:
                vid_src = dood_decode(html) + token + str(int(time.time() * 1000)) + helpers.append_headers(headers)
            if subs:
                return vid_src, subtitles
            return vid_src
        return 'not found'
    @classmethod
    def filemoon(self, host, media_id):
        from six.moves import urllib_parse
        if '$$' in media_id:
            media_id, referer = media_id.split('$$')
            referer = urllib_parse.urljoin(referer, '/')
        else:
            referer = False
        if '/' in media_id:
            media_id = media_id.split('/')[0]
        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': self.useragent,
                   'Cookie': '__ddg1_=PZYJSmASXDCQGP6auJU9; __ddg2_=hxAe1bBqtlYhVSik'}
        if referer:
            headers.update({'Referer': referer})
        html = getMovieData(web_url, replace_headers=headers)
        if '<h1>Page not found</h1>' in html or '<h1>This video cannot be watched under this domain</h1>' in html:
            web_url = web_url.replace('/e/', '/d/')
            html = getMovieData(web_url, replace_headers=headers)
        r = re.search(r'<iframe\s*src="([^"]+)', html, re.DOTALL)
        if r:
            headers.update({'accept-language': 'en-US,en;q=0.9',
                            'sec-fetch-dest': 'iframe',
                            'Referer': web_url})
            web_url = r.group(1)
            html = getMovieData(web_url, replace_headers=headers)
        html += helpers.get_packed_data(html)
        r = re.search(r'var\s*postData\s*=\s*(\{.+?\})', html, re.DOTALL)
        if r:
            r = r.group(1)
            pdata = {
                'b': re.findall(r"b:\s*'([^']+)", r)[0],
                'file_code': re.findall(r"file_code:\s*'([^']+)", r)[0],
                'hash': re.findall(r"hash:\s*'([^']+)", r)[0]
            }
            headers.update({
                'Referer': web_url,
                'Origin': urllib_parse.urljoin(web_url, '/')[:-1],
                'X-Requested-With': 'XMLHttpRequest'
            })
            edata = getMovieData(urllib_parse.urljoin(web_url, '/dl'), post=pdata, replace_headers=headers)
            edata = json.loads(edata)[0]
            surl = helpers.tear_decode(edata.get('file'), edata.get('seed'))
            if surl:
                headers.pop('X-Requested-With')
                headers.pop('Cookie')
                headers['verifypeer'] = 'false'
                #if 'master.m3u8' in surl and 'hls' in surl:
                #    surl = surl.replace('master.m3u8','index-v1-a1.m3u8')
                return surl + helpers.append_headers(headers)
        else:
            r = re.search(r'sources:\s*\[{\s*file:\s*"([^"]+)', html, re.DOTALL)
            if r:
                headers.pop('Cookie')
                headers.update({
                    'Referer': web_url,
                    'Origin': urllib_parse.urljoin(web_url, '/')[:-1],
                    'verifypeer': 'false'
                })
                return r.group(1) + helpers.append_headers(headers)
        return ''
    @classmethod
    def mixdrop(self, host, media_id):
        if host.endswith('.club'):
            host = host.replace('.club', '.nu')
        web_url = self.get_url(host, media_id)
        rurl = 'https://{}/'.format(host)
        headers = {'Origin': rurl[:-1],'Referer': rurl,'User-Agent': self.useragent}
        html = getMovieData(web_url, replace_headers=headers)
        if "We can't find the video you are looking for." in html:
            return 'not found'
        r = re.search(r'location\s*=\s*"([^"]+)', html)
        try:
            if r and not re.findall('\+\w\+',r.group(1)):
                web_url = 'https://{0}{1}'.format(host, r.group(1))
                html = getMovieData(web_url, replace_headers=headers)
        except:
            pass
        if '(p,a,c,k,e,d)' in html:
            html = helpers.get_packed_data(html)
        r = re.search(r'(?:vsr|wurl|surl)[^=]*=\s*"([^"]+)', html)
        if r:
            surl = r.group(1)
            if surl.startswith('//'):
                surl = 'https:' + surl
            headers.pop('Origin')
            headers.update({'Referer': web_url})
            return surl + helpers.append_headers(headers)
        return ''
    @classmethod
    def streamtape(self, host, media_id):
        web_url = self.get_url(host, media_id)
        headers = {'User-Agent': self.useragent,'Referer': 'https://{0}/'.format(host)}
        r = getMovieData(web_url, replace_headers=headers)
        if 'Video not found!' in r:
            return 'not found'
        src = re.findall(r'''ById\('.+?=\s*(["']//[^;<]+)''', r)
        if src:
            src_url = ''
            parts = src[-1].replace("'", '"').split('+')
            for part in parts:
                p1 = re.findall(r'"([^"]*)', part)[0]
                p2 = 0
                if 'substring' in part:
                    subs = re.findall(r'substring\((\d+)', part)
                    for sub in subs:
                        p2 += int(sub)
                src_url += p1[p2:]
            src_url += '&stream=1'
            src_url = 'https:' + src_url if src_url.startswith('//') else src_url
            return helpers.get_redirect_url(src_url, headers) + helpers.append_headers(headers)
        return ''
    @classmethod
    def ok_ru(self, host, media_id, subs=False):
        header = {'User-Agent': self.useragent}
        def __replaceQuality(qual):
            qual_map = {'ultra': '2160', 'quad': '1440', 'full': '1080', 'hd': '720', 'sd': '480', 'low': '360', 'lowest': '240', 'mobile': '144'}
            return qual_map.get(qual.lower(), '000')
        def __get_Embed(media_id):
            url = "http://www.ok.ru/videoembed/{0}".format(media_id)
            html = getMovieData(url, replace_headers=header, retry=False)
            if "notFound" not in html:
                match = re.search(r'<div\s*data-module="OKVideo"\s*data-movie-id="[^"]+"\s*data-options="({[^"]+)"', html)
                if match:
                    json_data = json.loads(match.group(1).replace('&quot;', '"').replace('&amp;', '&'))
                    metadata = json_data.get("flashvars", {}).get("metadata")
                    if metadata:
                        json_data = json.loads(metadata)
                        return json_data
            return {}
        def __get_Metadata(media_id, subs):
            url = "http://www.ok.ru/dk?cmd=videoPlayerMetadata"
            data = {'mid': media_id}
            html = getMovieData(url, post=data, replace_headers=header, retry=False)
            json_data = json.loads(html)
            if 'error' in json_data:
                if "notFound" in json_data['error']:
                    # special case when only the embed is available
                    json_data = __get_Embed(media_id)
                    if not json_data:
                        return 'not found',''
                else:
                    return 'not found',''
            subtitles = {}
            if subs and 'movie' in json_data and 'subtitleTracks' in json_data['movie']:
                for sub in json_data['movie']['subtitleTracks']:
                    if 'url' in sub and 'language' in sub:
                        suburl = 'https:' + sub['url'] if sub['url'].startswith('//') else sub['url']
                        subtitles[sub['language']] = suburl + helpers.append_headers(header)
            if len(json_data['videos']) > 0:
                info = dict()
                info['urls'] = []
                for entry in json_data['videos']:
                    info['urls'].append(entry)
            else:  # Live Stream
                headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"}
                html = getMovieData(url, post=data, replace_headers=headers, retry=False)
                json_data = json.loads(html)
                info = json_data['hlsMasterPlaylistUrl'] + helpers.append_headers(headers)
            return info, subtitles
        vids, subtitles = __get_Metadata(media_id, subs)
        if vids == 'not found':
            return vids,''
        if isinstance(vids, dict):
            sources = []
            for entry in vids['urls']:
                quality = __replaceQuality(entry['name'])
                sources.append((quality, entry['url']))
            try:
                sources.sort(key=lambda x: int(x[0]), reverse=True)
            except:
                pass
            source = sources[0][1]
            source = source.encode('utf-8') if six.PY2 else source
            source = source + helpers.append_headers(header)
        else:
            source = vids
        if subs:
            return source, subtitles
        return source,''
    @classmethod
    def dailymotion(self, host, media_id):
        web_url = 'https://www.dailymotion.com/player/metadata/video/{}'.format(media_id)
        headers = {'User-Agent': self.useragent,'Origin': 'https://www.dailymotion.com','Referer': 'https://www.dailymotion.com/'}
        js_result = json.loads(getMovieData(web_url, replace_headers=headers))
        if js_result.get('error'):
            return 'not found'
        quals = js_result.get('qualities')
        if quals:
            mbtext = getMovieData(quals.get('auto')[0].get('url'), replace_headers=headers)
            sources = re.findall('NAME="(?P<label>[^"]+)"(?:,PROGRESSIVE-URI="|\n)?(?P<url>[^#]+)', mbtext)
            return helpers.sort_sources_list(sources)[0][1] + helpers.append_headers(headers)
        return 'not found'
    @classmethod
    def vimeo(self, host, media_id):
        headers = {'User-Agent': 'pyvimeo 1.2.0; (http://developer.vimeo.com/api/docs)', 'Accept-Encoding': 'gzip, deflate', 'Accept': 'application/vnd.vimeo.*;version=3.4', 'Connection': 'keep-alive', 'Authorization': 'Bearer f8f5116eb6f4677367edfb8592d1805e'}
        if '$$' in media_id:
            media_id, referer = media_id.split('$$')
            referer = urllib_parse.urljoin(referer, '/')
            headers.update({'Referer': referer})
        else:
            media_id = media_id.split('/')[0]
            media_id = media_id.split('?')[0]
            referer = False
        params = {'per_page': 15, 'total': 15, 'fields': 'uri,resource_key,name,description,type,duration,created_time,location,bio,short_bio,stats,user,account,release_time,pictures,metadata,play,live.status,websites', 'password': None}
        params = '&'.join('%s=%s'%(x,y) for x,y in params.items())
        web_url = 'https://api.vimeo.com/videos/{}?{}'.format(media_id,params)
        html = getMovieData(web_url, replace_headers=headers)
        data = json.loads(html)
        sources = [(vid['height'], vid['link']) for vid in data.get('play', {}).get('progressive', {})]
        headers = {'User-Agent': self.useragent,'Origin': 'https://player.vimeo.com','Referer': 'https://player.vimeo.com/'}
        if sources:
            sources.sort(key=lambda x: x[0], reverse=True)
            return sources[0][1] + helpers.append_headers(headers)
        else:
            hls = data.get('play', {}).get('hls')
            if hls:
                src = hls.get('link', {})
                if src:
                    return src + helpers.append_headers(headers)
        return 'not found'
    @classmethod
    def brplayer(self, host, media_id):
        web_url = 'https://{}/watch?v={}'.format(host,media_id)
        headers = {'User-Agent': self.useragent}
        html = getMovieData(web_url, replace_headers=headers)
        r = re.search(r'sniff\("[^"]+","([^"]+)","([^"]+)".+?],([^,]+)', html)
        if r:
            source = "https://{0}/m3u8/{1}/{2}/master.txt?s=1&cache={3}".format(
                host, r.group(1), r.group(2), r.group(3)
            )
            headers.update({'Referer': web_url})
            return source + helpers.append_headers(headers)
        r = re.search(r'var\s+video\s*=\s*(\{.*?\});', html)
        if r:
            json_str = r.group(1)
            video = json.loads(json_str)
            source = "https://{0}/m3u8/{1}/{2}/master.txt?s=1&cache={3}".format(
                host, video.get('uid'), video.get('md5'), video.get('status')
            )
            headers.update({'Referer': web_url})
            return source + helpers.append_headers(headers)
        return 'not found'
    @staticmethod
    def get_url(host, media_id):
        return 'https://{}/e/{}'.format(host,media_id)
    @classmethod
    def detect(self, media):
        host,media_id = re.findall(r'(?:\/\/|\.)((?:.+)\.(?:.+))\/(?:e|d|download|videoembed|player|video)\/([0-9a-zA-Z$:\/.]+)',media)[0]
        if 'filemoon' in host:
            return self.filemoon(host,media_id)
        elif 'mixdrop' in host:
            return self.mixdrop(host,media_id)
        elif 'streamtape' in host:
            return self.streamtape(host,media_id)
        elif any(domain in host for domain in ['doodstream.com', 'vidply.com', 'all3do.com', 'vide0.net', 'dsvplay.com']):
            return self.doodstream(host,media_id)
        elif 'vinovo' in host:
            return self.vinovo(host,media_id)
        elif 'ok.ru' in host:
            return self.ok_ru(host,media_id,True)
        elif 'dailymotion' in host:
            pattern = r'(?://|\.)(dailymotion\.com|dai\.ly)(?:/(?:video|embed|sequence|swf|player)' \
                      r'(?:/video|/full)?)?/(?:[a-z0-9]+\.html\?video=)?([0-9a-zA-Z]+)'
            host,media_id = re.findall(pattern,media)[0]
            return self.dailymotion(host,media_id)
        elif 'vimeo' in host:
            return self.vimeo(host,media_id)
        return ''

epg_url = base64.b64decode('aHR0cHM6Ly9za3lyaXNrLmdpdGh1Yi5pby9icmF6dWNhcGxheS9sb2dvcy9lcGcvZXBnYnIueG1s').decode('utf-8')
epgEnabled = xbmcaddon.Addon().getSetting("epg")
epgLast = xbmcaddon.Addon().getSetting("epg_last")
epgDays = xbmcaddon.Addon().getSetting("epg_days")
base_search_rc = '\x61\x48\x52\x30\x63\x48\x4d\x36\x4c\x79\x39\x6e\x61\x58\x4e\x30\x4c\x6d\x64\x70\x64\x47\x68\x31\x59\x6e\x56\x7a\x5a\x58\x4a\x6a\x62\x32\x35\x30\x5a\x57\x35\x30\x4c\x6d\x4e\x76\x62\x53\x39\x7a\x61\x33\x6c\x79\x61\x58\x4e\x72\x4c\x7a\x56\x69\x4f\x44\x63\x33\x4f\x54\x63\x7a\x4d\x6a\x6c\x6a\x4e\x32\x49\x30\x4e\x6a\x51\x79\x4d\x6a\x55\x32\x4e\x57\x5a\x6d\x59\x6d\x46\x68\x59\x6a\x4e\x69\x5a\x54\x64\x6c\x4c\x33\x4a\x68\x64\x79\x39\x77\x59\x57\x64\x6c\x58\x79\x56\x7a\x4c\x6e\x68\x74\x62\x41\x3d\x3d'
base_search_rc = base64.b64decode(base_search_rc).decode('utf-8')

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r

def re_me(data, re_patten):
    match = ''
    m = re.search(re_patten, data)
    if m != None:
        match = m.group(1)
    else:
        match = ''
    return match

def getData(url,fanart,chlist=False):
    data = url
    if not chlist:
        data = getMovieData(url)
        if six.PY2: data = data.encode('utf8')
    if isinstance(data, (int, str, list)):
        channels = '<channels>' in data and '</channels>' in data
        channel = data
        if not isinstance(data, list):
            channel = re.compile('<channel>(.*?)</channel>',re.MULTILINE|re.DOTALL).findall(data)
        if isinstance(data, list):
            channels = True
        if channels:
            hashed_pw_verify = False
            if features_enable == 'true' and not features_pass == '':
                hashed_pw_verify = features_checker()
            for channel in channel:
                linkedUrl=''
                try:
                    linkedUrl = re.compile('<externallink>(.*?)</externallink>').findall(channel)[0]
                except:
                    pass
                name = re.compile('<name>(.*?)</name>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                try:
                    if hashed_pw_verify:
                        if '\x67\x69\x73\x74' in linkedUrl and '\x72\x61\x77\x2f\x6e\x6f\x76\x65\x6c\x61\x73\x2e\x78\x6d\x6c' in linkedUrl:
                            name = name.replace('[COLOR lime]','[COLOR gold]')
                            linkedUrl = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass
                        if linkedUrl.startswith('#novelas_menu'):
                            name = name.replace('[COLOR lime]','[COLOR gold]')
                        if '\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79' in linkedUrl and '\x2f\x68\x36\x2d\x73\x65\x72\x69\x65\x73\x2d\x62\x61\x73\x65\x2e\x78\x6d\x6c' in linkedUrl:
                            name = name.replace('[COLOR lime]','[COLOR gold]')
                        if (not linkedUrl.startswith('#series_pages=')) and '\x67\x69\x73\x74' in linkedUrl and '\x72\x61\x77\x2f\x53\x65\x72\x69\x65\x73\x42\x61\x73\x65' in linkedUrl:
                            name = '[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]TODAS SÉRIES[/COLOR][/B]'
                            linkedUrl = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'srs'
                        if '\x67\x69\x73\x74' in linkedUrl and '\x72\x61\x77\x2f\x44\x65\x73\x65\x6e\x68\x6f\x73\x42\x61\x73\x65' in linkedUrl:
                            name = name.replace('[COLOR lime]','[COLOR gold]')
                            linkedUrl = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'des'
                        if '\x67\x69\x74' in linkedUrl and '\x4d\x65\x6e\x75\x25\x32\x30\x2d\x25\x32\x30\x43\x61\x74\x65\x67\x6f\x72\x69\x61\x2e\x78\x6d\x6c' in linkedUrl and not features_pass + 'mvmenunew' in url:
                            name = name.replace('[COLOR lime]','[COLOR gold]')
                            linkedUrl = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'mvmenunew'
                        if '#menu_canais' in linkedUrl:
                            name = name.replace('[COLOR lime]','[COLOR gold]')
                except:
                    pass
                try:
                    thumbnail = re.compile('<thumbnail>(.*?)</thumbnail>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                except:
                    thumbnail = ''
                try:
                    fanArt = re.compile('<fanart>(.*?)</fanart>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                except:
                    fanArt = ''

                if not fanArt or fanArt == 'here':
                    if addon.getSetting('use_thumb') == "true":
                        fanArt = thumbnail
                    else:
                        fanArt = fanart
                if fanArt == None:
                    #raise
                    fanArt = ''
                
                try:
                    desc = re.compile('<info>(.*?)</info>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if desc == None:
                        #raise
                        desc = ''
                except:
                    desc = ''

                try:
                    genre = re.compile('<genre>(.*?)</genre>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if genre == None:
                        #raise
                        genre = ''
                except:
                    genre = ''

                try:
                    date = re.compile('<date>(.*?)</date>',re.MULTILINE|re.DOTALL).findall(channel)[0]
                    if date == None:
                        #raise
                        date = ''
                except:
                    date = ''
                try:
                    if thumbnail.startswith('serie='):
                        myid = base64.b64decode(thumbnail.split('serie=')[1]).decode('utf-8')
                        thumbnail = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x70\x6f\x73\x74\x65\x72\x50\x74\x2f\x33\x34\x32\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                        fanArt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2f\x31\x32\x38\x30\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                except:
                    pass
                try:
                    if fanArt.startswith('serie='):
                        myid = base64.b64decode(fanArt.split('serie=')[1]).decode('utf-8')
                        fanArt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2f\x31\x32\x38\x30\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                except:
                    pass
                try:
                    if thumbnail.startswith('movie=') and '.mp4' in thumbnail:
                        mvid = thumbnail.split('movie=')[1].replace('.mp4','')
                        thumbnail = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x6d\x6f\x76\x69\x65\x73\x2f\x70\x6f\x73\x74\x65\x72\x50\x74\x2f\x33\x34\x32\x2f\x25\x73\x2e\x77\x65\x62\x70'%mvid
                        fanArt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x6d\x6f\x76\x69\x65\x73\x2f\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2f\x31\x32\x38\x30\x2f\x25\x73\x2e\x77\x65\x62\x70'%mvid
                except:
                    pass
                try:
                    if linkedUrl=='':
                        pass
                    else:
                        if canais_adultos == 'false' and name.find("CANAIS") >= 0 and name.find("+18") >= 0:
                            pass
                        elif '#menu_canais_adults' in linkedUrl:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,21,thumbnail,fanArt,desc,genre,date)
                        elif '#menu_canais' in linkedUrl:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,21,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#novelas_menu'):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,25,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#desenhos_menu'):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,28,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#doramas_menu'):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,31,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#doramas_list='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,31,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#animes_menu'):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,22,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#series_list='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            if '\x77\x61\x74\x63\x68\x75\x67\x2e\x77\x61\x74\x63\x68' in thumbnail:
                                thumbnail = thumbnail + ''
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,27,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#animes_list='):
                            if not desc:
                                desc = '[B][COLOR white]OS MELHORES ANIMES EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            try:
                                fanArt = base64.b64decode(fanArt).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,22,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#novelas_list='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES NOVELAS EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,27,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#movies_pages='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,27,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#series_pages='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,27,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('#trilogias_list'):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,3,thumbnail,fanArt,desc,genre,date)
                        elif 'rede=' in linkedUrl:
                            linkedUrl = linkedUrl.replace('rede=','')
                            linkedUrl = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x65\x64\x65\x63\x61\x6e\x61\x69\x73\x2e\x63\x78\x2f\x62\x72\x6f\x77\x73\x65\x2d' + linkedUrl + '\x2d\x76\x69\x64\x65\x6f\x73\x2d\x31\x2d\x64\x61\x74\x65\x2e\x68\x74\x6d\x6c'
                            if not desc:
                                desc = '[B][COLOR white]OS MELHORES CONTEÚDOS DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,7,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('serie='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                linkedUrl = base64.b64decode(linkedUrl.split('serie=')[1]).decode('utf-8')
                                linkedUrl = 'serie=' + linkedUrl
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,23,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('serie2='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,26,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('serie3='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,26,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('seriecdn='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,26,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('sfserie='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                linkedUrl = base64.b64decode(linkedUrl.split('sfserie=')[1]).decode('utf-8')
                                linkedUrl = 'sfserie=' + linkedUrl
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,29,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('wvmob='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                linkedUrl = base64.b64decode(linkedUrl.split('wvmob=')[1]).decode('utf-8')
                                linkedUrl = 'wvmob=' + linkedUrl
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,30,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('resolver1_tvshows='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,31,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('resolver2_tvshows='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,31,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('resolver3_tvshows='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,31,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('resolver4_tvshows='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,31,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('onedrive='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,31,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('doramas_resolver1='):
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,31,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('animes') and '=' in linkedUrl:
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            try:
                                fanArt = base64.b64decode(fanArt).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,22,thumbnail,fanArt,desc,genre,date)
                        elif 'tseries=' in linkedUrl:
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,24,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('desenhos='):
                            if not desc:
                                desc = '[B][COLOR white]OS MELHORES DESENHOS DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,28,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('desenhos2='):
                            desc = '[B][COLOR white]OS MELHORES DESENHOS DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8') + '\x7c\x63\x6f\x6f\x6b\x69\x65\x3d\x5f\x5f\x64\x64\x67\x69\x64\x5f\x3d\x72\x41\x63\x62\x33\x68\x32\x6b\x66\x70\x41\x73\x45\x58\x72\x68\x3b\x20\x5f\x5f\x64\x64\x67\x32\x5f\x3d\x65\x59\x38\x4c\x52\x4f\x30\x59\x66\x4a\x34\x34\x4d\x56\x55\x31\x3b\x20\x5f\x5f\x64\x64\x67\x31\x5f\x3d\x50\x68\x73\x4c\x35\x37\x72\x58\x50\x57\x6a\x59\x53\x4c\x65\x49\x56\x50\x35\x31'
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,28,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('novelas='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES NOVELAS EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,25,thumbnail,fanArt,desc,genre,date)
                        elif linkedUrl.startswith('novelas2='):
                            if not desc:
                                desc = '[B][COLOR white]AS MELHORES NOVELAS EM UM SÓ LUGAR[/COLOR][/B]'
                            try:
                                thumbnail = base64.b64decode(thumbnail).decode('utf-8')
                            except:
                                pass
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,25,thumbnail,fanArt,desc,genre,date)
                        elif '#hub_categorias' in linkedUrl:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,2,thumbnail,fanArt,desc,genre,date)
                        elif '#search_hub' in linkedUrl:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,2,thumbnail,fanArt,desc,genre,date)
                        elif '#pesquisar_series' in linkedUrl:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,20,thumbnail,fanArt,desc,genre,date)
                        elif 'pornhub=' in linkedUrl:
                            linkedUrl = linkedUrl.replace('pornhub=','')
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,2,thumbnail,fanArt,desc,genre,date)
                        elif '#home=search_movies#' in linkedUrl or '#home=search_plusmovies#' in linkedUrl:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,6,thumbnail,fanArt,desc,genre,date)
                            global pesquisa_desativar
                            global search
                            pesquisa_desativar = 'false'
                            search = ''
                        else:
                            addDir(name.encode('utf-8', 'ignore'),linkedUrl,1,thumbnail,fanArt,desc,genre,date)
                except:
                    notify('[COLOR red]Erro ao Carregar os dados![/COLOR]')
        else:
            item = re.compile('<item>(.*?)</item>',re.MULTILINE|re.DOTALL).findall(data)
            getItems(item,fanart)
    else:
        notify('[COLOR red]Erro ao Carregar os dados![/COLOR]')

def getItems(items,fanart,pesquisa=False):
    if epgEnabled == "true":
        epg_search = items
        try:
            for item in epg_search:
                if 'epg_active' in item:
                    epg_search = 'true'
                    break
                else:
                    break
        except:
            epg_search = 'false'
        if epg_search == 'true':
            epginfo = epgParseData()
    total = len(items)
    for item in items:
        isXMLSource=False
        isJsonrpc = False
        try:
            name = re.compile('<title>(.*?)</title>',re.MULTILINE|re.DOTALL).findall(item)[0].replace(';','')
            if name is None:
                name = 'unknown?'
        except:
            name = ''
        try:
            jsonrpc = re.compile('<jsonrpc>(.*?)</jsonrpc>',re.MULTILINE|re.DOTALL).findall(item)
            externallink = re.compile('<externallink>(.*?)</externallink>',re.MULTILINE|re.DOTALL).findall(item)
            link = re.compile('<link>(.*?)</link>',re.MULTILINE|re.DOTALL).findall(item)
            if len(jsonrpc)>0:
                url = jsonrpc[0]
                url2 = ''
            elif len(externallink)>0:
                url = externallink[0]
                url2 = ''
            elif len(link)>0:
                try:
                    url = link[0]
                    mylinks = []
                    for link in link:
                        mylinks.append('<link>'+link+'</link>')
                    #url2 = link
                    url2 = mylinks
                except:
                    url = link[0]
                    url2 = ''
            else:
                url = ''
                url2 = ''
        except:
            url = ''
            url2 = ''
        if epgEnabled == "true":
            if url == 'here' and 'CANAIS ABERTOS' in name or 'CANAIS ABERTOS' in name or 'DOCUMENTÁRIOS' in name or 'ESPORTES' in name or 'FILMES & SÉRIES' in name or 'INFATIL' in name or 'MÚSICAS & VARIEDADES' in name or 'NOTÍCIAS' in name:
                name = name + ' [COLOR blue]●[/COLOR] [B]ATUALIZAR EPG[/B]'
        try:
            thumbnail = re.compile('<thumbnail>(.*?)</thumbnail>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if thumbnail == None:
                #raise
                thumbnail = ''
        except:
            thumbnail = ''
        if not thumbnail:
            thumbnail = iconimage
        try:
            fanArt = re.compile('<fanart>(.*?)</fanart>',re.MULTILINE|re.DOTALL).findall(item)[0]
        except:
            fanArt = ''

        if not fanArt or fanArt == 'here':
            if addon.getSetting('use_thumb') == "true":
                fanArt = thumbnail
            else:
                fanArt = fanart
        if fanArt == None:
            #raise
            fanArt = ''
        try:
            desc = re.compile('<info>(.*?)</info>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if desc == None:
                #raise
                desc = ''
        except:
            desc = ''
        try:
            if epgEnabled == "true":
                if not '.mp4' in url:
                    if 'epgid' in item:
                        EPG_Get = getID_EPG(name)
                        if EPG_Get == '':
                            pass
                        else:
                            epg, desc_epg = getEPG(epginfo,EPG_Get)
                            name = name + epg
                            desc = desc_epg
        except:
            pass
        try:
            genre = re.compile('<genre>(.*?)</genre>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if genre == None:
                #raise
                genre = ''
        except:
            genre = ''
        try:
            date = re.compile('<date>(.*?)</date>',re.MULTILINE|re.DOTALL).findall(item)[0]
            if date == None:
                date = ''
        except:
            date = ''
        try:
            if thumbnail.startswith('movie=') and '.mp4' in thumbnail:
                mvid = thumbnail.split('movie=')[1].replace('.mp4','')
                thumbnail = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x6d\x6f\x76\x69\x65\x73\x2f\x70\x6f\x73\x74\x65\x72\x50\x74\x2f\x33\x34\x32\x2f\x25\x73\x2e\x77\x65\x62\x70'%mvid
                fanArt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x6d\x6f\x76\x69\x65\x73\x2f\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2f\x31\x32\x38\x30\x2f\x25\x73\x2e\x77\x65\x62\x70'%mvid
        except:
            pass
        try:
            if url == '' or url == None:
                pass
            elif len(externallink)>0:
                if url.startswith('#movies_pages='):
                    addDir(name.encode('utf-8', 'ignore'),url,27,thumbnail,fanArt,desc,genre,date)
                else:
                    addDir(name.encode('utf-8', 'ignore'),url,1,thumbnail,fanArt,desc,genre,date)
            elif len(url2) >1:
                name_resolve = name + '[B][COLOR gold][B] (' + str(len(url2)) + ' OPÇÕES )[/COLOR][/B]'
                addLink(name_resolve.encode('utf-8', 'ignore'),''.join(url2).replace(',','||').replace('$$'+playlist_command+'','#'+playlist_command+''),11,thumbnail,fanArt,desc,genre,date)
            else:
                addLink(name.encode('utf-8', 'ignore'),url,16,thumbnail,fanArt,desc,genre,date)
        except:
            notify('[COLOR red]Ocorreu um problema ao carregar os items![/COLOR]')

def adult():
    arquivo = os.path.join(profile, "pass.txt")
    exists = os.path.isfile(arquivo)
    keyboard = xbmcaddon.Addon().getSetting("keyboard")
    if exists == False:
        parental_password()
        xbmc.sleep(10)
        p_file = open(arquivo,'r+', encoding='utf-8')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if not ps == p_file_b64_decode:
            notify('[B]Senha invalida![/B]')
            exit()
    else:
        p_file = open(arquivo,'r+', encoding='utf-8')
        p_file_read = p_file.read()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        dialog = xbmcgui.Dialog()
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if not ps == p_file_b64_decode:
            notify('[B]Senha invalida![/B]')
            exit()

def playlist(name, url, iconimage, description):
    CheckUpdate()
    playlist_command1 = playlist_command
    dialog = xbmcgui.Dialog()
    check_player()
    channel_mode = False
    channel_proxy = ''
    #links = re.compile('<link>([\s\S]*?)#'+playlist_command1+'', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
    #if len(links) < 1:
    links = re.compile('<link>([\s\S]*?)</link>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
    links_name = re.compile('<link>([\s\S]*?)</link>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
    name_change = re.compile('.(\(.+\))', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(name)[0]
    total = len(links)
    names = []
    name = name.replace(name_change,'')
    for teste in range(0,total):
        if '#lsname=' in str(links[teste]):
            name_new = re.compile('#lsname=(.+)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(links_name[teste])[0]
            names.append(name_new)
        else:
            names.append(name)
    names2 = []
    iloop=0
    for name in names:
        iloop = iloop + 1
        myname = name.replace('+', ' ')
        myname = myname + ' - OPÇÃO ' + str(iloop)
        names2.append(myname)
    if links !=[] and names2 !=[]:
        index = dialog.select('ESCOLHA UMA OPÇÃO', names2)
        playname = ''
        if index >= 0:
            try:
                playname=names2[index]
            except:
                playname = ''
            try:
                playlink=links[index]
            except:
                playlink = ''
            if '#lsname=' in playlink:
                playlink = re.sub('#lsname=.+', '', playlink)
            if not playlink == '' or not playlink == None:
                if 'ffmpeg_off' in playlink:
                    ffmpeg_input = 'true'
                    playlink = playlink.replace('?ffmpeg_off','')
                else:
                    ffmpeg_input = 'false'
                if playlink.startswith('plus_channel='):
                    url = plus_channels(playlink)
                    url = url.replace(';','')
                    channel_mode = True
                elif playlink.startswith('chresolver1='):
                    if '#' in playlink:
                        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x63\x68\x61\x6e\x6e\x65\x6c\x73\x2e\x78\x6d\x6c'
                        html = getMovieData(link)
                        find_id = playlink.split('#')[1]
                        find_hostname = re.findall('\x3c\x68\x6f\x73\x74\x6e\x61\x6d\x65\x5f\x25\x73\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x68\x6f\x73\x74\x6e\x61\x6d\x65\x5f\x25\x73\x3e'%(find_id,find_id), html)
                        find_users = re.findall('\x3c\x75\x73\x65\x72\x73\x5f\x25\x73\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x75\x73\x65\x72\x73\x5f\x25\x73\x3e'%(find_id,find_id), html)
                        host,accounts='',[]
                        if find_hostname and find_users:
                            host = base64.b64decode(find_hostname[0]).decode('utf-8')
                            accounts = base64.b64decode(find_users[0]).decode('utf-8').split('|')
                        dialog = xbmcgui.Dialog()
                        channel_proxy = False #M3U8_Proxy(host)
                        accounts = M3U8_Verify(host,channel_proxy,accounts)
                        if accounts:
                            channel = playlink.split('chresolver1=')[1].split('#')[0]
                            url = host%(accounts,channel)
                            if not valide_v2(url,custom_useragent='XC-IPTV',get_mode=True):
                                url = 'stop'
                                xbmcgui.Dialog().ok('Aviso: Verificação falhou!', '[B]O acesso pode estar sendo bloqueado pela sua internet.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore[/COLOR][CR][COLOR grey]Fazemos verificações diárias nos canais para garantir o funcionamento.[/COLOR][/B]')
                            else:
                                channel_mode = True
                                if url and not '|' in url:
                                    url = '\x25\x73\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x58\x43\x2d\x49\x50\x54\x56'%url
                        else:
                            xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, updateListing=False, cacheToDisc=False)
                    else:
                        url = '\x68\x74\x74\x70\x3a\x2f\x2f\x73\x2e\x61\x70\x6b\x77\x75\x76\x2e\x78\x79\x7a\x2f\x6c\x69\x76\x65\x2f\x64\x65\x6d\x6f\x70\x61\x64\x65\x78\x63\x68\x61\x6e\x67\x65\x2f\x64\x65\x6d\x6f\x70\x61\x64\x2f\x25\x73\x2e\x6d\x33\x75\x38\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x44\x61\x6c\x76\x69\x6b\x2f\x32\x2e\x31\x2e\x30\x20\x28\x4c\x69\x6e\x75\x78\x3b\x20\x55\x3b\x20\x41\x6e\x64\x72\x6f\x69\x64\x20\x39\x3b\x20\x53\x4d\x2d\x53\x39\x30\x38\x45\x20\x42\x75\x69\x6c\x64\x2f\x54\x50\x31\x41\x2e\x32\x32\x30\x36\x32\x34\x2e\x30\x31\x34\x29'%playlink.split('chresolver1=')[1]
                        channel_mode = True
                    url = url.replace(';','')
                elif playlink.startswith('chresolver2='):
                    url = chresolver2(playlink)
                    url = url.replace(';','')
                    channel_mode = True
                else:
                    url = playlink
        if not url == '' or not url == None:
            li = xbmcgui.ListItem(playname, path=url)
            li.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
            li.setProperty('http-reconnect','true')
            li.setProperty('ForceResolvePlugin', 'true')
            if int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0]) > 19:
                info = li.getVideoInfoTag()
                info.setTitle(playname)
                info.setMediaType('video')
                info.setPlot(description)
            else:
                li.setInfo(type="Video", infoLabels={"Title": playname, 'mediatype': 'video', "Plot": description})
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            playlist.clear()
            try:
                if channel_mode:
                    host = urlparse(url.split('|')[0]).netloc
                    if ':' in host and any(c.isalpha() for c in host):
                        host_check = ''
                        if '|' in url:
                            host_check = url.split('|')[0]
                        elif '%7C' in url:
                            host_check = url.split('%7C')[0]
                        req = get_headers(url)
                        checker = Check_M3U8(host_check,req,channel_proxy)
                        if checker:
                            url = checker
                        #elif channel_proxy:
                        #    if url.startswith('http://'):
                        #        url += '&Proxy=%s&Proxy_Host=%s'%(channel_proxy,'http://%s'%host)
                        #    else:
                        #        url += '&Proxy=%s&Proxy_Host=%s'%(channel_proxy,'https://%s'%host)
                    import codec
                    url = codec.URL_PROXY + string_encoder(url)
                    li.setPath(url)
                    codec.code().init()
                    playlist.add(url, li)
                    xbmc.Player().play(playlist)
                    xbmc.executebuiltin('PlayerControl(RepeatOne)')
                elif ffmpeg_opt == "false" and ffmpeg_input == "false":
                    #TESTES
                    li.setContentLookup(True)
                    #li.setMimeType('application/vnd.apple.mpegurl')
                    li.setProperty('inputstream', 'inputstream.ffmpegdirect')
                    li.setProperty('inputstream.ffmpegdirect.stream_mode', 'catchup')
                    li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
                    li.setProperty('inputstream.ffmpegdirect.is_catchup_stream', 'catchup')
                    li.setProperty('inputstream.ffmpegdirect.catchup_granularity', '60')
                    li.setProperty('inputstream.ffmpegdirect.catchup_terminates', 'true')            
                    #li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
                    #li.setProperty('inputstream.ffmpegdirect.manifest_type','hls')           
                    li.setProperty('inputstream.ffmpegdirect.default_url',url)
                    li.setProperty('inputstream.ffmpegdirect.catchup_url_format_string',url)
                    li.setProperty('inputstream.ffmpegdirect.programme_start_time','1')
                    li.setProperty('inputstream.ffmpegdirect.programme_end_time','19')
                    li.setProperty('inputstream.ffmpegdirect.catchup_buffer_start_time','1')
                    li.setProperty('inputstream.ffmpegdirect.catchup_buffer_offset','1') 
                    li.setProperty('inputstream.ffmpegdirect.default_programme_duration','19')
                    #TESTES
                    playlist.add(url, li)
                    xbmc.Player().play(playlist)
                    if repeat_opt == 'false':
                        xbmc.executebuiltin('PlayerControl(RepeatOne)')
                    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
                else:
                    playlist.add(url, li)
                    xbmc.Player().play(playlist)
                    if repeat_opt == 'false':
                        xbmc.executebuiltin('PlayerControl(RepeatOne)')
            except:
                exit()
        else:
            custom_error_log = ['\x23\x6d\x6f\x76\x69\x65\x73\x5f\x6c\x69\x73\x74\x3d','\x6d\x6f\x76\x69\x65\x32\x3d','\x6d\x6f\x76\x69\x65\x63\x64\x6e\x3d','\x73\x65\x72\x69\x65\x3d','\x73\x65\x72\x69\x65\x63\x64\x6e\x3d', '\x75\x72\x6c\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d']
            if not any(playlink.startswith(x) for x in custom_error_log):
                SendErrorLog(playlink)
            exit()
    else:
        exit()

def PrivateSource():
    arquivo = 'c3BlY2lhbDovL2hvbWUvdXNlcmRhdGEvcGxheWVyY29yZWZhY3RvcnkueG1s'
    arquivo = base64.b64decode(arquivo).decode('utf-8')
    arquivo = xbmc.translatePath(os.path.join(arquivo))
    exists = os.path.isfile(arquivo)
    try:
        os.remove(arquivo)
    except:
        pass
    #if exists == True:
    #    xbmcgui.Dialog().ok(addon_name, "[B][COLOR gold]Player[/COLOR] alternativo indisponível.[CR][CR]Tente remover o [COLOR gold]playercorefactory.xml[/COLOR] e reiniciar o Kodi.[/B]")
    #    exit()
    if xbmc.getCondVisibility('system.platform.windows'):
        fiddler = os.getenv("AppData")
        fiddler = fiddler.replace('Roaming','Local\Programs\Fiddler')
        arquivo = xbmc.translatePath(os.path.join(fiddler))
        exists = os.path.exists(arquivo)
        if exists == True:
            xbmcgui.Dialog().ok(addon_name, "[B][COLOR gold]Problema na rede![/COLOR][CR][CR]Desinstale sua [COLOR gold]VPN[/COLOR] antes de continuar.[/B]")
            exit()

def valide(rcs_url,refer,user=False):
    try:
        import ssl
        if '|' in rcs_url:
            rcs_url = rcs_url.split('|')[0]
        req = urllib2.Request(rcs_url)
        if user:
            req.add_header('User-Agent', user)
        else:
            req.add_header('User-Agent', useragent)
        if refer:
            req.add_header('Referer', refer)
        response = urllib2.urlopen(req, context=ssl._create_unverified_context())
        return True
    except:
        return False

def valide_v2(url,referer=False,origin=False,custom_useragent=False,post=False,head=False,cookies=False,getcookies=False,replace_headers=False,get_mode=False,proxy=False,timeout=15):
    try:
        request_headers = replace_headers if replace_headers else {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'sec-ch-ua': sec_ch_ua,
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': custom_useragent or useragent
        }
        if referer:
            request_headers = update_dict(request_headers, 3, 'Referer', referer)
        if origin:
            request_headers = update_dict(request_headers, 3, 'Origin', origin)
        if 'mp4' in url:
            request_headers.update({'Range':'bytes=0-100'})
        #if proxy:
        #    if isinstance(proxy, bool):
        #        proxy = resolve_dns(url)
        #    if proxy and not isinstance(proxy, bool):
        #        base_dns(url, proxy)
        s = create_retry_session()
        if get_mode:
            request = s.get(url, headers=request_headers, timeout=timeout)
        else:
            request = s.head(url, headers=request_headers, timeout=timeout)
        if request:
            return True
        return False
    except:
        return False

def get_headers(url):
    headers_default = {'User-Agent': 'XC-IPTV'}
    headers = {}
    if 'User-Agent' in url:
        try:
            user_agent = url.split('User-Agent=')[1]
            try:
                user_agent = user_agent.split('&')[0]
            except:
                pass
            try:
                user_agent = urllib.unquote_plus(user_agent)
            except:
                pass
            try:
                user_agent = urllib.unquote(user_agent)
            except:
                pass
            headers['User-Agent'] = user_agent
        except:
            pass
    if 'Referer' in url:
        try:
            referer = url.split('Referer=')[1]
            try:
                referer = referer.split('&')[0]
            except:
                pass
            try:
                referer = urllib.unquote_plus(referer)
            except:
                pass
            try:
                referer = urllib.unquote(referer)
            except:
                pass
            headers['Referer'] = referer
        except:
            pass
    if 'Origin' in url:
        try:
            origin = url.split('Origin=')[1]
            try:
                origin = origin.split('&')[0]
            except:
                pass
            try:
                origin = urllib.unquote_plus(origin)
            except:
                pass
            try:
                origin = urllib.unquote(origin)
            except:
                pass
            headers['Origin'] = origin
        except:
            pass
    HEADERS = headers if headers else headers_default
    return HEADERS

def encode(key, clear):
    enc = []
    for i in range(len(clear)):
        key_c = key[i % len(key)]
        enc_c = chr((ord(clear[i]) + ord(key_c)) % 256)
        enc.append(enc_c)
    return base64.urlsafe_b64encode("".join(enc).encode()).decode()

def decode(key, enc):
    dec = []
    enc = base64.urlsafe_b64decode(enc).decode()
    for i in range(len(enc)):
        key_c = key[i % len(key)]
        dec_c = chr((256 + ord(enc[i]) - ord(key_c)) % 256)
        dec.append(dec_c)
    return "".join(dec)

def string_encoder(url):
  result = ""
  for character in url:
    result = result + "%" + hex(ord(character))[2:]
  return result

def natural_sort(list, key=lambda s:s):
    def get_alphanum_key_func(key):
        convert = lambda text: int(text) if text.isdigit() else text 
        return lambda s: [convert(c) for c in re.split('([0-9]+)', key(s))]
    sort_key = get_alphanum_key_func(key)
    list.sort(key=sort_key)

def resolver_rc(url):
    try:
        link = getMovieData(url)
        ur = re.compile('iframe.*?src="(.*?)"').findall(link)[0]
        if not 'player3' in ur or not 'server' in ur:
            ur = re.compile('iframe.*?src="(.*?)"').findall(link)[1]
        url = server_rc(ur)
        return url
    except:
        return url
        notify('Houve um problema, por favor reporte!')
        exit()

def remount_url(url):
    try:
        link = getMovieData(decode(features_pass, 'w4rDpsOkw5zDlMKzwp_CocORwqTCkcKswqjDhcOTw6DDmMOCw7LCnsOYw57CpMKlwp_CmMOLw6TDn8Ofwo_DnMOfw5_CnsKaYWRmwo_DpcOVw57Dl8Oew6LDpMOS'))
        server = str(re.compile('(.*)=', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0])
        video = str(re.compile(server+'=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]).replace('.mp4','')
        resolver = re.compile(server+'="(.*?)"',re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link)[0] + video
        return resolver
    except:
        notify('Houve um problema, por favor reporte!')
        return ''

def server_rc(url):
    try:
        if not '&' in url:
            vid = re.compile('vid=(.+)').findall(url)[0]
        else:
            vid = re.compile('vid=(.+?)&').findall(url)[0]
    except:
        vid = re.compile('vid=(.+)').findall(url)[0]
    server = re.compile('server(.*?).php').findall(url)[0].replace('http2','').replace('http','').replace('hlb','')
    if re.compile('\D').findall(server):
        char = re.compile('\D+').findall(server)[0]
        try:
            dig = re.compile('\d+').findall(server)[0]
        except:
            dig = 1
        url = 'rc%s%s=%s.mp4'%(char,dig,vid)
        return url
    else:
        if int(server) < 10:
            url = 'rc%s=%s.mp4'%(server,vid)
            return url
        else:
            url = 'rc%s=%s.mp4'%(server,vid)
            return url

def server_rc_erro(url):
    vid = re.compile('(.*)=').findall(url)[0]
    if 'rcf' in vid:
        vid = vid.replace('rcf','')
        vid = 'Servidor ' + vid.upper()
        return vid
    elif 'rc' in vid and not 'f' in vid:
        vid = vid.replace('rc','')
        vid = 'Servidor ' + vid.upper()
        return vid

def server_alternative(url):
    try:
        if not '&' in url:
            vid = re.compile('vid=(.+)').findall(url)[0]
        else:
            vid = re.compile('vid=(.+?)&').findall(url)[0]
    except:
        vid = re.compile('vid=(.+)').findall(url)[0]
    server = re.compile('server(.*?).php').findall(url)[0].replace('http2','').replace('http','').replace('hlb','')
    if re.compile('\D').findall(server):
        char = re.compile('\D+').findall(server)[0]
        try:
            dig = re.compile('\d+').findall(server)[0]
        except:
            dig = 1
        url = 'RC%sServer%s'%(char.upper(),dig)
        return url
    else:
        if int(server) < 10:
            url = 'RCServer0%s'%(server)
            return url
        else:
            url = 'RCServer%s'%(server)
            return url

def StringCharCode(unpack):
    try:
        filtro = re.compile('\x53\x74\x72\x69\x6e\x67\x2e\x66\x72\x6f\x6d\x43\x68\x61\x72\x43\x6f\x64\x65\x5c\x28\x28\x2e\x2b\x3f\x29\x5c\x29', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(unpack)
        for delete in filtro:
            novo = chr(int(delete) & 0xffff)
            unpack = unpack.replace('String.fromCharCode('+delete+')',"'"+novo+"'")
        filtro = re.compile("(\\\\u0.+?)'", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(unpack)
        for delete in filtro:
            if six.PY3: novo = str.encode(delete).decode('unicode_escape')
            if six.PY2: novo = novo = delete.decode('unicode_escape')
            unpack = unpack.replace(delete,novo)
        unpack = 'https:' + unpack.replace("+",'').replace("'",'')
        return unpack
    except:
        return ''

def plus_channels(channel):
    try:
        channel,host_resolver = channel.split('plus_channel=')[1].split('#')
        try:
            if six.PY3: import hashlib
            if six.PY3: from hmac import compare_digest
            if six.PY2: import hashlib
            if six.PY2: from hmac import compare_digest
            if six.PY2: import binascii
            hashed_pw = features_checker()
            decrypt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw + features_pass + 'chlist'
        except:
            pass
        host = getMovieData(decrypt)
        host = re.compile('\x3c\x68\x6f\x73\x74\x5f\x72\x65\x73\x6f\x6c\x76\x65\x72\x25\x73\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x68\x6f\x73\x74\x5f\x72\x65\x73\x6f\x6c\x76\x65\x72\x25\x73\x3e'%(host_resolver,host_resolver)).findall(host)[0]
        stream = decode(features_pass,str(host))
        if host_resolver == '2':
            stream, refer = stream.split('|')
            stream = plus_channels_resolver1(stream%channel, refer)
            if not stream:
                return 'stop'
        elif 'User-Agent=%s' in stream:
            stream = stream%(channel,useragent)
        else:
            stream = stream%channel
        return stream
    except:
        notify('[B]Canal indisponível![/B]')
        return 'stop'

def plus_channels_resolver1(url, refer):
    res = getMovieData(url)
    if not '\x69\x6e\x64\x65\x78\x2e\x6d\x33\x75\x38' in res:
        res = custom_proxy(url,cache={'format':'hours','limit':1})
    match = re.findall('\x73\x6f\x75\x72\x63\x65\x3a\x2e\x2a\x22\x28\x2e\x2a\x3f\x29\x22',res)
    match2 = re.findall('\x72\x65\x74\x75\x72\x6e\x20\x6e\x75\x6c\x6c\x3d\x3d\x63\x5c\x3f\x22\x28\x2e\x2a\x3f\x29\x22',res)
    match3 = re.findall('\x71\x5c\x28\x27\x73\x72\x63\x27\x2c\x5c\x73\x2a\x27\x28\x5b\x5e\x27\x5d\x2b\x29\x27\x5c\x29',res)
    if match2:
        match = match2
    if match3:
        match = match3
    if match:
        stream = match[0].replace('\x2f\x69\x6e\x64\x65\x78\x2e\x6d\x33\x75\x38','\x2f\x74\x72\x61\x63\x6b\x73\x2d\x76\x31\x61\x31\x2f\x6d\x6f\x6e\x6f\x2e\x74\x73\x2e\x6d\x33\x75\x38') + '|User-Agent=%s&Referer=%s'%(useragent, refer)
        return stream
    return None

def movies_resolver(movie):
    try:
        if 'serie=' in movie:
            movie = str(re.compile('serie=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(movie)[0]).replace('.mp4','')
            params = {'\x67\x65\x74\x45\x70\x69\x73\x6f\x64\x65\x44\x61\x74\x61':movie}
        else:
            movie = str(re.compile('movie=(.*)', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(movie)[0]).replace('.mp4','')
            params = {'\x77\x61\x74\x63\x68\x4d\x6f\x76\x69\x65':movie}
        host_url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x74\x76\x2e\x69\x6e\x2f\x69\x6e\x63\x6c\x75\x64\x65\x73\x2f\x61\x6a\x61\x78\x2f\x70\x75\x62\x6c\x69\x63\x46\x75\x6e\x63\x74\x69\x6f\x6e\x73\x2e\x70\x68\x70'
        refer_stream = '%s://%s'%(urlparse(host_url).scheme,urlparse(host_url).netloc)
        url = getMovieData(host_url, refer_stream, post=params)
        if url == '':
            return '',''
        language = []
        langjson = json.loads(url)
        languages = langjson.get('\x6c\x69\x73\x74')
        for vrz in languages:
            mvid = languages.get(vrz).get('\x69\x64')
            lang = languages.get(vrz).get('\x6c\x61\x6e\x67')
            sources = languages.get(vrz).get('players')
            if lang == '1':
                language.append(('Legendado',mvid,sources))
            elif lang == '2':
                language.append(('Dublado',mvid,sources))
            elif 'Dublado' in lang:
                language.append(('Dublado',mvid,sources))
            else:
                language.append(('Legendado',mvid,sources))
        if len(language) > 1:
            if 'Legendado' in language[0]:
                language.reverse()
        if len(language) > 1:
            dialog = xbmcgui.Dialog()
            idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
            index = dialog.select('ESCOLHA O IDIOMA', idm)
            if index >= 0:
                if index == 0:
                    language.pop(1)
                else:
                    language.pop(0)
            else:
                notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                return 'stop',''
        for vrz, mvid, source in language:
            import ast
            player = ast.literal_eval(source)
            wovie = player.get('\x77\x61\x72\x65\x7a\x63\x64\x6e', 0) == 3
            mixdrop = player.get('\x6d\x69\x78\x64\x72\x6f\x70', 0) == 3
            streamtape = player.get('\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65', 0) == 3
            player_select = ''
            player_switch = []
            player_name = []
            if wovie:
                player_select = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x70\x6c\x61\x79\x65\x72\x2f\x70\x6c\x61\x79\x65\x72\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73'%str(mvid)
                player_name.append('[B]CDN - RÁPIDO[/B]')
                player_switch.append(player_select)
            if mixdrop:
                player_select = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x74\x76\x2e\x69\x6e\x2f\x65\x6d\x62\x65\x64\x2f\x67\x65\x74\x50\x6c\x61\x79\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x6d\x69\x78\x64\x72\x6f\x70'%str(mvid)
                player_name.append('[B]MIXDROP - RÁPIDO[/B]')
                player_switch.append(player_select)
            if streamtape:
                player_select = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x74\x76\x2e\x69\x6e\x2f\x65\x6d\x62\x65\x64\x2f\x67\x65\x74\x50\x6c\x61\x79\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65'%str(mvid)
                player_name.append('[B]STREAMTAPE - INDICADO PARA INTERNET LENTA[/B]')
                player_switch.append(player_select)
            if not player_switch:
                notify('[B]FILME INDISPONIVEL![/B]')
                return 'stop',''
            player_select = ''
            if len(player_switch) > 1:
                dialog = xbmcgui.Dialog()
                index = dialog.select('ESCOLHA O SERVIDOR', player_name)
                if index >= 0:
                    player_select = player_switch[index]
                else:
                    notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                    return 'stop',''
            else:
                player_select = player_switch[0]
            link = player_select
            sub = ''
            if '\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b' in link:
                player,sub = wovie_resolver(link)
                return player,sub
            url = getMovieData(link, refer_stream)
            player = re.compile('\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x22').findall(url)
            player = player[0] if player else ''
            if player !='':
                sub = player.split('\x68\x74\x74\x70')[2] if len(player.split('\x68\x74\x74\x70')) >= 3 else ""
                if sub:
                    sub = '\x68\x74\x74\x70\x25\x73'%sub
                    if '\x26' in sub:
                        sub = sub.split('\x26')[0]
                if '\x3f' in player:
                    player = player.split('\x3f')[0]
                if '\x23' in player:
                    player = player.split('\x23')[0]
            if '\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b' in sub:
                sub = sub.replace('\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b', '\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b')
        return player,sub
    except:
        return '',''

def movies2_resolver(url):
    try:
        base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x2f\x25\x73\x2f\x3f\x61\x72\x65\x61\x3d\x6f\x6e\x6c\x69\x6e\x65'%(OVERFLIXTV_HOST,url.split('movie2=')[1])).replace('\n','').replace('\r','').replace("'",'"')
        if not '\x22\x6f\x6e\x63\x6c\x69\x63\x6b\x22\x2c\x22\x47\x65\x74\x49\x66\x72\x61\x6d\x65' in base:
            base = custom_proxy('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x2f\x25\x73\x2f\x3f\x61\x72\x65\x61\x3d\x6f\x6e\x6c\x69\x6e\x65'%(OVERFLIXTV_HOST,url.split('movie2=')[1]),cache={'format':'days','limit':4}).replace('\n','').replace('\r','').replace("'",'"')
        embed = ''
        if re.findall('\x23\x76\x69\x64\x65\x6f\x5f\x65\x6d\x62\x65\x64\x2e\x2a\x3f\x3c\x69\x66\x72\x61\x6d\x65\x20\x73\x72\x63\x3d\x22\x28\x2e\x2a\x3f\x29\x67\x65\x74\x65\x6d\x62\x65\x64\x2e\x70\x68\x70',base):
            embed = re.findall('\x23\x76\x69\x64\x65\x6f\x5f\x65\x6d\x62\x65\x64\x2e\x2a\x3f\x3c\x69\x66\x72\x61\x6d\x65\x20\x73\x72\x63\x3d\x22\x28\x2e\x2a\x3f\x29\x67\x65\x74\x65\x6d\x62\x65\x64\x2e\x70\x68\x70',base)[-1]
        elif re.findall('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x72\x65\x64\x69\x72\x65\x63\x74\x2e\x70\x68\x70',base):
            embed = re.findall('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x72\x65\x64\x69\x72\x65\x63\x74\x2e\x70\x68\x70',base)[-1]
        if embed.startswith('/'):
            embed = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x25\x73'%(OVERFLIXTV_HOST,embed)
        language = re.compile('\x5c\x28\x22\x23\x6d\x69\x78\x64\x72\x6f\x70\x22\x5c\x29\x2e\x61\x74\x74\x72\x5c\x28\x22\x6f\x6e\x63\x6c\x69\x63\x6b\x22\x2c\x22\x47\x65\x74\x49\x66\x72\x61\x6d\x65\x5c\x28\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x22\x6d\x69\x78\x64\x72\x6f\x70\x22\x2e\x2b\x3f\x5c\x28\x22\x23\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65\x22\x5c\x29\x2e\x61\x74\x74\x72\x5c\x28\x22\x6f\x6e\x63\x6c\x69\x63\x6b\x22\x2c\x22\x47\x65\x74\x49\x66\x72\x61\x6d\x65\x5c\x28\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x22\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65\x22\x2e\x2b\x3f\x5c\x28\x22\x23\x66\x69\x6c\x65\x6d\x6f\x6f\x6e\x22\x5c\x29\x2e\x61\x74\x74\x72\x5c\x28\x22\x6f\x6e\x63\x6c\x69\x63\x6b\x22\x2c\x22\x47\x65\x74\x49\x66\x72\x61\x6d\x65\x5c\x28\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x22\x66\x69\x6c\x65\x6d\x6f\x6f\x6e\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
        lang_select = 0
        if len(language) > 1:
            dialog = xbmcgui.Dialog()
            idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
            index = dialog.select('ESCOLHA O IDIOMA', idm)
            if index >= 0:
                if index == 0:
                    language.pop(1)
                else:
                    language.pop(0)
                    lang_select = 1
            else:
                notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                return 'stop'
        dialog = xbmcgui.Dialog()
        idm = ['[B]MIXDROP - RÁPIDO[/B]','[B]STREAMTAPE - INDICADO PARA INTERNET LENTA[/B]','[B]FILEMOON - A ÚLTIMA ESPERANÇA[/B]', '[B]DOODSTREAM - INDICADO PARA INTERNET LENTA[/B]']
        index = dialog.select('ESCOLHA O SERVIDOR', idm)
        def stream_choose(choose,lang_select):
            server = '\x6d\x69\x78\x64\x72\x6f\x70'
            if choose == 1:
                server = '\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65'
            elif choose == 2:
                server = '\x66\x69\x6c\x65\x6d\x6f\x6f\x6e'
            elif choose == 3:
                server = '\x64\x6f\x6f\x64\x73\x74\x72\x65\x61\x6d'
            redir = '\x25\x73\x67\x65\x74\x70\x6c\x61\x79\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x25\x73'%(embed,language[0],server)
            html = getMovieData(redir,redir,head=True).headers.get('location')
            if not html:
                html = custom_proxy(redir,redir,head=True,cache={'format':'days','limit':4}).get('location')
            stream_select = re.compile('\x68\x74\x74\x70\x73\x2e\x2b\x5c\x2f\x28\x2e\x2b\x29').findall(html)[0]
            return stream_select
        if index >= 0:
            language = language[0]
            stream_select = stream_choose(index,lang_select)
            if index == 0:
                return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6d\x69\x78\x64\x72\x6f\x70\x2e\x70\x73\x2f\x65\x2f\x25\x73'%stream_select
            elif index == 1:
                return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65\x2e\x63\x6f\x6d\x2f\x65\x2f\x25\x73'%stream_select
            elif index == 2:
                return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x65\x6d\x6f\x6f\x6e\x2e\x73\x78\x2f\x65\x2f\x25\x73'%stream_select
            elif index == 3:
                return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x64\x70\x6c\x79\x2e\x63\x6f\x6d\x2f\x65\x2f\x25\x73'%stream_select
        else:
            notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
            return 'stop'
        return ''
    except:
        return ''

def moviecdn_resolver(url):
    try:
        import json
        base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x66\x69\x6c\x6d\x65\x2f\x25\x73'%url.split('moviecdn=')[1]).replace("'",'"')
        base = re.compile('let data = "(.*)";').findall(base)[0] or ''
        language = json.loads(base)
        if not language:
            xbmcgui.Dialog().ok("Aviso:", "[B]Tente outra opção![CR][COLOR gold]Este filme não está disponível.[/COLOR][/B]")
            return 'stop',''
        player_select = 0
        lang = 0
        sub = ''
        if len(language) > 1:
            dialog = xbmcgui.Dialog()
            index = dialog.select('ESCOLHA O IDIOMA', ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]'])
            if index == 0:
                lang = 1
            elif index == 1:
                lang = 0
            else:
                return 'stop',''
        language = language[lang]
        langs = language.get('id')
        players = []
        player_switch = []
        if '\x77\x61\x72\x65\x7a\x63\x64\x6e' in language.get('servers'):
            player_switch.append('[B]CDN - RÁPIDO[/B]')
            players.append((langs,'\x77\x61\x72\x65\x7a\x63\x64\x6e'))
        if '\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65' in language.get('servers'):
            player_switch.append('[B]STREAMTAPE - INDICADO PARA INTERNET LENTA[/B]')
            players.append((langs,'\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65'))
        if '\x6d\x69\x78\x64\x72\x6f\x70' in language.get('servers'):
            player_switch.append('[B]MIXDROP - RÁPIDO[/B]')
            players.append((langs,'\x6d\x69\x78\x64\x72\x6f\x70'))
        if not players:
            xbmcgui.Dialog().ok("Aviso: Não há links!", "[B][COLOR gold]No momento essa opção não tem links disponíveis.[/COLOR][/B]")
            return 'stop',''
        if len(player_switch) > 1:
            dialog = xbmcgui.Dialog()
            index = dialog.select('ESCOLHA O SERVIDOR', player_switch)
            if index >= 0:
                player_select = index
            else:
                return 'stop',''
        if 'cdn' in players[player_select][1]:
            url,sub = wovie_resolver('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x45\x6d\x62\x65\x64\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x77\x61\x72\x65\x7a\x63\x64\x6e\x26\x6c\x61\x6e\x67\x3d\x25\x73'%(players[player_select][0],int(lang)+1))
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Tente outra opção![CR][COLOR gold]No momento essa opção se encontra offline.[/COLOR][/B]")
            return url,sub
        else:
            html,cookies = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x45\x6d\x62\x65\x64\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x25\x73\x26\x6c\x61\x6e\x67\x3d\x25\x73'%(players[player_select][0],players[player_select][1],int(lang)+1),'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x66\x69\x6c\x6d\x65\x2f\x25\x73'%url, getcookies=True)
            html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x50\x6c\x61\x79\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x25\x73'%(players[player_select][0],players[player_select][1]),'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x45\x6d\x62\x65\x64\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x25\x73\x26\x6c\x61\x6e\x67\x3d\x25\x73'%(players[player_select][0],players[player_select][1],int(lang)+1), cookies=cookies)
            player = re.compile('\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x20\x3d\x20\x22\x28\x2e\x2a\x3f\x29\x22').findall(html)[0] or ''
            sub = player.split('sub=')[1] if 'sub=' in player else ''
            sub = player.split('sub1=')[1] if 'sub1=' in player else sub
            if not sub:
                sub = player.split('file=')[1].split('&')[0] if 'file=' in player and '&' in player else ''
            if '\x26\x63\x31\x5f\x6c\x61\x62\x65\x6c\x3d' in sub:
                sub = sub.split('\x26\x63\x31\x5f\x6c\x61\x62\x65\x6c\x3d')[0]
            if '\x26\x73\x75\x62\x31\x5f\x6c\x61\x62\x65\x6c\x3d' in sub:
                sub = sub.split('\x26\x73\x75\x62\x31\x5f\x6c\x61\x62\x65\x6c\x3d')[0]
            if '\x3f\x73\x75\x62\x3d' in player:
                player = player.split('\x3f\x73\x75\x62\x3d')[0]
            if '\x3f\x73\x75\x62\x31\x3d' in player:
                player = player.split('\x3f\x73\x75\x62\x31\x3d')[0]
            url = resolvers.detect(player)
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            return url,sub
        raise
    except:
        return '',''

def seriecdn_resolver(url):
    try:
        import json
        base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x63\x6f\x72\x65\x2f\x61\x6a\x61\x78\x2e\x70\x68\x70\x3f\x61\x75\x64\x69\x6f\x73\x3d\x25\x73'%url.split('#')[0], url.split('#')[1])
        language = json.loads(json.loads(base))
        player_select = 0
        lang = 0
        sub = ''
        if len(language) > 1:
            dialog = xbmcgui.Dialog()
            index = dialog.select('ESCOLHA O IDIOMA', ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]'])
            if index == 0:
                lang = 1
            elif index == 1:
                lang = 0
            else:
                return 'stop',''
        language = language[lang]
        langs = language.get('id')
        players = []
        player_switch = []
        if '\x77\x61\x72\x65\x7a\x63\x64\x6e' in language.get('servers'):
            player_switch.append('[B]CDN - RÁPIDO[/B]')
            players.append((langs,'\x77\x61\x72\x65\x7a\x63\x64\x6e'))
        if '\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65' in language.get('servers'):
            player_switch.append('[B]STREAMTAPE - INDICADO PARA INTERNET LENTA[/B]')
            players.append((langs,'\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65'))
        if '\x6d\x69\x78\x64\x72\x6f\x70' in language.get('servers'):
            player_switch.append('[B]MIXDROP - RÁPIDO[/B]')
            players.append((langs,'\x6d\x69\x78\x64\x72\x6f\x70'))
        if not players:
            xbmcgui.Dialog().ok("Aviso: Não há links!", "[B][COLOR gold]No momento essa opção não tem links disponíveis.[/COLOR][/B]")
            return 'stop',''
        if len(player_switch) > 1:
            dialog = xbmcgui.Dialog()
            index = dialog.select('ESCOLHA O SERVIDOR', player_switch)
            if index >= 0:
                player_select = index
            else:
                return 'stop',''
        if 'cdn' in players[player_select][1]:
            url,sub = wovie_resolver('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x45\x6d\x62\x65\x64\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x77\x61\x72\x65\x7a\x63\x64\x6e\x26\x6c\x61\x6e\x67\x3d\x25\x73'%(players[player_select][0],int(lang)+1))
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Tente outra opção![CR][COLOR gold]No momento essa opção se encontra offline.[/COLOR][/B]")
            return url,sub
        else:
            html,cookies = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x45\x6d\x62\x65\x64\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x25\x73\x26\x6c\x61\x6e\x67\x3d\x25\x73'%(players[player_select][0],players[player_select][1],int(lang)+1),url.split('#')[1], getcookies=True)
            html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x50\x6c\x61\x79\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x25\x73'%(players[player_select][0],players[player_select][1]),'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x45\x6d\x62\x65\x64\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x25\x73\x26\x6c\x61\x6e\x67\x3d\x25\x73'%(players[player_select][0],players[player_select][1],int(lang)+1), cookies=cookies)
            player = re.compile('\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x20\x3d\x20\x22\x28\x2e\x2a\x3f\x29\x22').findall(html)[0] or ''
            sub = player.split('sub=')[1] if 'sub=' in player else ''
            sub = player.split('sub1=')[1] if 'sub1=' in player else sub
            if not sub:
                sub = player.split('file=')[1].split('&')[0] if 'file=' in player and '&' in player else ''
            if '\x26\x63\x31\x5f\x6c\x61\x62\x65\x6c\x3d' in sub:
                sub = sub.split('\x26\x63\x31\x5f\x6c\x61\x62\x65\x6c\x3d')[0]
            if '\x26\x73\x75\x62\x31\x5f\x6c\x61\x62\x65\x6c\x3d' in sub:
                sub = sub.split('\x26\x73\x75\x62\x31\x5f\x6c\x61\x62\x65\x6c\x3d')[0]
            if '\x3f\x73\x75\x62\x3d' in player:
                player = player.split('\x3f\x73\x75\x62\x3d')[0]
            if '\x3f\x73\x75\x62\x31\x3d' in player:
                player = player.split('\x3f\x73\x75\x62\x31\x3d')[0]
            url = resolvers.detect(player)
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            return url,sub
        raise
    except:
        return '',''

def wovie_resolver(player):
    try:
        #xbmcgui.Dialog().ok("Aviso:", "[B]Tente outra opção![CR][COLOR gold]No momento essa opção está em manutenção.[/COLOR][/B]")
        #return 'stop',''
        #player = player.replace('\x63\x64\x6e\x2e\x63\x6f\x6d','\x63\x64\x6e\x2e\x6e\x65\x74')
        refer_stream = '%s://%s'%(urlparse(player).scheme,urlparse(player).netloc)
        html,cookies = getMovieData(player, refer_stream, getcookies=True)
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x67\x65\x74\x50\x6c\x61\x79\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x77\x61\x72\x65\x7a\x63\x64\x6e'%(player.split('?id=')[1].split('&')[0]), player, cookies=cookies)
        player = re.compile('\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x20\x3d\x20\x22\x28\x2e\x2a\x3f\x29\x22').findall(html)[0] or ''
        sub = ''
        try:
            sub = player.split('sub=')[1]
        except:
            pass
        try:
            sub = sub.split('&subtitle=')[0]
        except:
            pass
        try:
            sub = player.split('sub1=')[1]
        except:
            pass
        if not sub:
            try:
                sub = player.split('file=')[1].split('&')[0]
            except:
                pass
        if '\x26\x63\x31\x5f\x6c\x61\x62\x65\x6c\x3d' in sub:
            sub = sub.split('\x26\x63\x31\x5f\x6c\x61\x62\x65\x6c\x3d')[0]
        if '\x26\x73\x75\x62\x31\x5f\x6c\x61\x62\x65\x6c\x3d' in sub:
            sub = sub.split('\x26\x73\x75\x62\x31\x5f\x6c\x61\x62\x65\x6c\x3d')[0]
        if '\x3f\x73\x75\x62\x3d' in player:
            player = player.split('\x3f\x73\x75\x62\x3d')[0]
        if '\x3f\x73\x75\x62\x31\x3d' in player:
            player = player.split('\x3f\x73\x75\x62\x31\x3d')[0]
        html,cookies = getMovieData(player, refer_stream, getcookies=True)
        html = helpers.get_packed_data(html)
        key = re.compile('\x46\x69\x72\x65\x50\x6c\x61\x79\x65\x72\x5c\x28\x22\x28\x2e\x2a\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)[0]
        host = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x2f\x70\x6c\x61\x79\x65\x72\x2f\x69\x6e\x64\x65\x78\x2e\x70\x68\x70\x3f\x64\x61\x74\x61\x3d\x25\x73\x26\x64\x6f\x3d\x67\x65\x74\x56\x69\x64\x65\x6f'%(urlparse(player).netloc,key)
        params = {'\x68\x61\x73\x68':key,'\x72':refer_stream + '/'}
        request_headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'Origin': 'https://%s'%urlparse(player).netloc,
            'sec-ch-ua': sec_ch_ua,
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': useragent,
            'X-Requested-With': 'XMLHttpRequest'
        }
        url = getMovieData(host, post=params, cookies=cookies, replace_headers=request_headers)
        import json
        json_base = json.loads(url)
        json_base = json_base.get('\x76\x69\x64\x65\x6f\x53\x6f\x75\x72\x63\x65') if json_base.get('\x76\x69\x64\x65\x6f\x53\x6f\x75\x72\x63\x65') else json_base.get('\x73\x65\x63\x75\x72\x65\x64\x4c\x69\x6e\x6b')
        if not valide_v2(json_base,refer_stream):
            return 'not found',''
        # Regex para encontrar os links e adicionar os cabeçalhos como query string
        def add_headers(match):
            url = match.group(0)
            return "{0}?|User-Agent={1}&Referer={2}".format(url,string_encoder(useragent),string_encoder(refer_stream))
        def make_m3u(url, refer_stream):
            try:
                res = getMovieData(url, replace_headers={"User-Agent":useragent,"Referer":refer_stream})
                pattern = "\x23\x45\x58\x54\x2d\x58\x2d\x53\x54\x52\x45\x41\x4d\x2d\x49\x4e\x46\x2e\x2a\x5c\x6e\x28\x68\x74\x74\x70\x73\x3f\x3a\x2f\x2f\x5b\x5e\x5c\x73\x5d\x2b\x29"
                links = re.findall(pattern, res)
                res = re.sub("\x68\x74\x74\x70\x73\x3f\x3a\x2f\x2f\x5b\x5e\x5c\x73\x5d\x2b", add_headers, res)
                py = os.path.join(home, "Playlist.m3u8")
                file = open(py, "w", encoding="utf-8")
                file.write(res)
                file.close()
                return links[0]
            except:
                pass
            return None
        json_base = make_m3u(json_base, refer_stream)
        if not json_base:
            return 'not found',''
        error = True if getMovieData(json_base, refer_stream) == "security error" else False
        if error:
            return 'not found',''
        if six.PY3: return home + 'Playlist.m3u8',sub
        if six.PY2: return home + '\Playlist.m3u8',sub
    except:
        return '',''

def wovie_embed_resolver(player):
    try:
        wrz_base = getMovieData(player,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
        wrz = re.compile('\x5c\x5b\x64\x61\x74\x61\x2d\x6c\x6f\x61\x64\x2d\x65\x70\x69\x73\x6f\x64\x65\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x5c\x5d', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(wrz_base)[0]
        params = {'\x67\x65\x74\x41\x75\x64\x69\x6f\x73':wrz}
        wrz_base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x73\x65\x72\x69\x65\x41\x6a\x61\x78\x2e\x70\x68\x70',wrz,post=params)
        wrz_id = json.loads(wrz_base).get('list').get('0').get('id')
        if wrz_id:
            return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x70\x6c\x61\x79\x65\x72\x2f\x70\x6c\x61\x79\x65\x72\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73'%wrz_id
        else:
            return '#megaerror'
    except:
        return '#megaerror'

def doramas_resolver1(url):
    try:
        error_msg = 1
        link = url.split('doramas_resolver1=')[1]
        html = getMovieData(link).replace("'",'"').replace('="//','="https://')
        if not '\x69\x66\x72\x61\x6d\x65' in html and not '\x73\x72\x63\x3d\x22' in html:
            html = custom_proxy(link,cache={'format':'days','limit':4}).replace("'",'"').replace('="//','="https://')
        stream = ''
        status_error = False
        hosts = re.compile('\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x73\x6f\x75\x72\x63\x65\x2d\x70\x6c\x61\x79\x65\x72\x5b\x5e\x22\x5d\x2a\x22\x5b\x5e\x3e\x5d\x2a\x3e\x2e\x2a\x3f\x28\x3f\x3a\x3c\x69\x66\x72\x61\x6d\x65\x5b\x5e\x3e\x5d\x2a\x73\x72\x63\x3d\x22\x7c\x3c\x61\x5b\x5e\x3e\x5d\x2a\x68\x72\x65\x66\x3d\x22\x29\x28\x5b\x5e\x22\x5d\x2b\x29\x2e\x2a\x3f\x3c\x2f\x64\x69\x76\x3e',re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(html)
        if not hosts:
            hosts_alter = re.compile('\x73\x6f\x75\x72\x63\x65\x2d\x70\x6c\x61\x79\x65\x72\x2d\x5c\x64\x2e\x2b\x3f\x22\x70\x66\x72\x61\x6d\x65\x22\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x64\x69\x76\x3e',re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(html)
            hosts = [host for host in hosts_alter if host.startswith('http')]
        for player in hosts:
            if 'org/go.php?auth=' in player:
                import json
                player = player.split('go.php?auth=')[1]
                player = base64.b64decode(player).decode('utf-8')
                player = json.loads(player).get('url')
                player = urllib.unquote(player)
            if '/aviso/?url=' in player:
                player = player.split('url=')[1]
                player = urllib.unquote(player)
            if '/daycdn/' in player:
                player = 'https://www.dailymotion.com/embed/video/%s'%player.split('key=')[1]
            if player.startswith('https://rumble.com'):
                status_error = True
                continue
            elif 'mega.nz' in player:
                status_error = True
                continue
            elif player.startswith('https://q1n.net/off/?url='):
                status_error = True
                continue
            elif player.startswith('https://doramas.upns.ink'):
                status_error = True
                continue
            elif player.startswith('https://csst.online'):
                html = getMovieData(player, '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x6f\x72\x61\x6d\x61\x73\x6f\x6e\x6c\x69\x6e\x65\x2e\x6f\x72\x67\x2f')
                pattern = 'file:"\[.*?\].*,'
                if not re.findall(pattern,html):
                    pattern = 'file:"(.*?)"'
                    if re.findall(pattern,html):
                        stream = re.findall(pattern,html)[-1].replace('"','')
                        refer = 'https://%s'%urlparse(stream).netloc
                        if valide_v2(stream,refer):
                            return '%s|User-Agent=%s&Referer=%s'%(stream,useragent,refer),''
                if re.findall(pattern,html):
                    stream_links = re.findall(pattern,html)[-1]
                    pattern = '\[.*?\](.*?),'
                    if re.findall(pattern,stream_links):
                        stream = re.findall(pattern,stream_links)[-1].replace('"','')
                        refer = 'https://%s'%urlparse(stream).netloc
                        if valide_v2(stream,refer):
                            return '%s|User-Agent=%s&Referer=%s'%(stream,useragent,refer),''
            elif player.startswith('https://embedrise.com'):
                html = getMovieData(player)
                if '\x3c\x74\x69\x74\x6c\x65\x3e\x4e\x6f\x74\x20\x46\x6f\x75\x6e\x64\x3c\x2f\x74\x69\x74\x6c\x65\x3e' in html:
                    continue
                stream = re.findall('\x73\x6f\x75\x72\x63\x65\x2e\x73\x72\x63\x3d\x22\x28\x2e\x2a\x3f\x29\x22',html)
                host = urlparse(player).netloc
                refer,origin = 'https://%s/'%host,'https://%s'%host
                if stream:
                    stream = stream[-1]
                    if valide_v2(stream,refer,origin):
                        return '%s|Origin=%s&Referer=%s&User-Agent=%s'%(stream,origin,refer,useragent),''
            elif player.startswith('https://rogeriobetin.com'):
                html = getMovieData(player, '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x6f\x72\x61\x6d\x61\x73\x6f\x6e\x6c\x69\x6e\x65\x2e\x6f\x72\x67\x2f', remove_forcelist=[500])
                pattern = '\x22\x66\x69\x6c\x65\x22\x2e\x2a\x3f\x3a\x2e\x2a\x3f\x22\x28\x2e\x2a\x3f\x29\x22'
                if re.findall(pattern,html):
                    stream = re.findall(pattern,html)[-1]
                    stream = stream.replace('\\/', '/')
                    refer = 'https://rogeriobetin.com/'
                    if ('.m3u8' in stream) and (valide_v2(stream,refer) or valide_v2(stream,refer,get_mode=True)):
                        # Adiciona proxy + parâmetros ao final de cada link
                        stream_m3u = getMovieData(stream,refer)
                        stream_m3u = re.sub(
                            r'^(https?://[^\s]+)',
                            lambda m: "http://127.0.0.1:55333/?url={}&Referer={}&User-Agent={}".format(
                                string_encoder(m.group(1)), string_encoder(refer), string_encoder(useragent)
                            ),
                            stream_m3u,
                            flags=re.MULTILINE
                        )
                        py = os.path.join(home, "Playlist.m3u8")
                        file = open(py, "w", encoding="utf-8")
                        file.write(stream_m3u)
                        file.close()
                        if six.PY3: return home + 'Playlist.m3u8',''
                        if six.PY2: return home + '\Playlist.m3u8',''
                    elif ('.mp4' in stream) and (valide_v2(stream,refer) or valide_v2(stream,refer,get_mode=True)):
                        return '%s|User-Agent=%s&Referer=%s'%(stream,useragent,refer),''
            elif 'doramasonline' in player and 'odacdn' in player:
                refer = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x6f\x72\x61\x6d\x61\x73\x6f\x6e\x6c\x69\x6e\x65\x2e\x6f\x72\x67\x2f'
                html = getMovieData(player, refer)
                file_video = '\x22\x66\x69\x6c\x65\x22\x5c\x73\x2a\x3a\x5c\x73\x2a\x22\x28\x2e\x2a\x3f\x29\x22'
                get_link = re.search(file_video, html)
                stream = get_link.group(1) if get_link else None
                if stream:
                    if 'cdn_stream.m3u8' in stream:
                        if not valide_v2(stream,refer) or not valide_v2(stream,refer,get_mode=True):
                            continue
                        stream_m3u = getMovieData(stream, refer)
                        stream_m3u = re.sub(
                            r'^(https?://[^\s]+)',
                            lambda m: "http://127.0.0.1:55333/?url={}&Referer={}&User-Agent={}".format(
                                string_encoder(m.group(1)), string_encoder(refer), string_encoder(useragent)
                            ),
                            stream_m3u,
                            flags=re.MULTILINE
                        )
                        py = os.path.join(home, "Playlist.m3u8")
                        file = open(py, "w", encoding="utf-8")
                        file.write(stream_m3u)
                        file.close()
                        if six.PY3: return home + 'Playlist.m3u8',''
                        if six.PY2: return home + '\Playlist.m3u8',''
                    if valide_v2(stream,refer) or valide_v2(stream,refer,get_mode=True):
                        return '%s|User-Agent=%s&Referer=%s'%(stream,useragent,refer),''
            elif 'watch.brplayer' in player:
                player = player.replace('.site','.cc')
                host = urlparse(player).netloc
                media_id = player.split('=')[1]
                stream = resolvers.brplayer(host,media_id)
                if not stream == 'not found':
                    return stream,''
            elif player.startswith('https://play.vidyard.com'):
                if not '/player/' in player:
                    player = player.replace('https://play.vidyard.com/','https://play.vidyard.com/player/').replace('?','.json?')
                html = getMovieData(player)
                if not 'Video Not Found' in html:
                    import json
                    source = json.loads(html).get('payload').get('chapters')[0].get('sources').get('mp4')[0].get('url')
                    if source:
                        return '%s|User-Agent=%s&Origin=https://play.vidyard.com&Referer=%s'%(source,useragent,player),''
                status_error = True
            elif player.startswith('https://player.jmvstream.com'):
                html = getMovieData(player)
                if not 'Transmissão não disponível' in html:
                    try:
                        stream = re.findall('\x70\x6c\x61\x79\x65\x72\x2e\x2a\x3f\x73\x72\x63\x22\x3a\x22\x28\x2e\x2a\x3f\x29\x22',html)[0]
                        if stream:
                            return '%s|User-Agent=%s&Referer=https://player.jmvstream.com/'%(stream,useragent),''
                    except:
                        pass
            elif player.startswith('https://ok.ru'):
                stream,sub = resolvers.detect(player)
                if stream and not stream == 'not found':
                    return stream,sub
                status_error = True
            elif 'dailymotion.com' in player or 'vimeo.com' in player:
                stream = resolvers.detect(player)
                if stream and not stream == 'not found':
                    return stream,''
                status_error = True
            elif 'video.wixstatic' in player and player[-4:] == '.mp4':
                if valide_v2(player):
                    return '%s|User-Agent=%s'%(player,useragent),''
            elif player.endswith('.mp4'):
                if valide_v2(player):
                    return '%s|User-Agent=%s'%(player,useragent),''
            else:
                status_error = False
                if '/anicx.link/' in player:
                    player = player.replace('/anicx.link/','/anicx.links6/') + '&playvideo'
                if '/ACX3/oncx.php' in player:
                    player = player.replace('/ACX3/oncx.php','/acx/oncx6.php')
                if '/playerscx/pla.php?id=' in player:
                    player = player.replace('/playerscx/pla.php?id=','/playcxs1/pla.php?id=') + '&playvideo'
                error_msg = 2
                html = getMovieData(player,link).replace("'",'"')
                file_video = '\x22\x66\x69\x6c\x65\x22\x5c\x73\x2a\x3a\x5c\x73\x2a\x22\x28\x2e\x2a\x3f\x29\x22'
                if 'drive.google.com/file' in html:
                    html = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(html)[0]
                    media_id = re.findall('(?:\/\/|\.)((?:.+)\.(?:.+))\/(?:d)\/(.+)\/',html)[0][1]
                    html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x72\x69\x76\x65\x2e\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x67\x6f\x6f\x67\x6c\x65\x2e\x63\x6f\x6d\x2f\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x3f\x69\x64\x3d\x25\x73\x26\x65\x78\x70\x6f\x72\x74\x3d\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x26\x61\x75\x74\x68\x75\x73\x65\x72\x3d\x30'%media_id)
                    uuid_stream = re.findall('\x6e\x61\x6d\x65\x3d\x22\x75\x75\x69\x64\x22\x20\x76\x61\x6c\x75\x65\x3d\x22\x28\x2e\x2a\x3f\x29\x22',html)
                    if uuid_stream:
                        stream_ = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x72\x69\x76\x65\x2e\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x67\x6f\x6f\x67\x6c\x65\x2e\x63\x6f\x6d\x2f\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x3f\x69\x64\x3d\x25\x73\x26\x65\x78\x70\x6f\x72\x74\x3d\x64\x6f\x77\x6e\x6c\x6f\x61\x64\x26\x63\x6f\x6e\x66\x69\x72\x6d\x3d\x74\x26\x75\x75\x69\x64\x3d\x25\x73'%(media_id,uuid_stream[0])
                        return '%s|User-Agent=%s'%(stream_,useragent),''
                    status_error = True
                    continue
                if 'vimeo.com' in html:
                    html = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(html)[0]
                    stream = resolvers.detect(html)
                    if stream and not stream == 'not found':
                        return stream,''
                    status_error = True
                    continue
                if 'drm:' in html and 'clearKeys:' in html:
                    status_error = True
                    continue
                if not re.search(file_video, html) or not '\x74\x68\x69\x73\x2e\x73\x72\x63\x28\x5b\x7b\x73\x72\x63\x3a\x22' in html:
                    html = custom_proxy(player,link,cache={'format':'days','limit':4}).replace("'",'"')
                if 'drm:' in html and 'clearKeys:' in html:
                    status_error = True
                    continue
                status_error = False
                if '\x74\x68\x69\x73\x2e\x73\x72\x63\x28\x5b\x7b\x73\x72\x63\x3a\x22' in html:
                    pattern = '\x74\x68\x69\x73\x5c\x2e\x73\x72\x63\x5c\x28\x5c\x5b\x5c\x7b\x73\x72\x63\x3a\x22\x28\x2e\x2a\x3f\x29\x22'
                    matches = re.findall(pattern, html)
                    stream = matches[0] if matches else ''
                elif re.search(file_video, html):
                    stream = re.compile(file_video,re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(html)[0].replace('\/','/')
                else:
                    stream = ''
                sub = ''
                try:
                    sub = re.compile('\x66\x69\x6c\x65\x3a\x20\x22\x28\x2e\x2a\x3f\x29\x22',re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(html)[0]
                except:
                    pass
                if valide_v2(stream,link):
                    if sub:
                        sub = '%s|User-Agent=%s&Referer=%s'%(sub,useragent,link)
                    if 'googleusercontent.com' in stream:
                        return '%s|User-Agent=%s'%(stream,useragent),sub
                    return '%s|User-Agent=%s&Referer=%s'%(stream,useragent,link),sub
                status_error = True
        if len(hosts) == 1:
            status_error = True
        if status_error:
            return 'not found',''
        return '',''
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Doramas Resolver 1 - Código: %s[/COLOR][/B]'%error_msg)
        return '',''

def animes1_resolver(url):
    try:
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais.[/B]")
        return 'stop'
        import json
        error_msg = 1
        html = getMovieData(url,'').replace("'",'"')
        if not re.findall('\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x70\x6c\x61\x79\x65\x72\x6f\x70\x74\x69\x6f\x6e\x73\x22\x2e\x2b\x3f\x3c\x5c\x2f\x64\x69\x76\x3e',html):
            html = custom_proxy(url).replace("'",'"')
        player = re.compile('\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x70\x6c\x61\x79\x65\x72\x6f\x70\x74\x69\x6f\x6e\x73\x22\x2e\x2b\x3f\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.DOTALL).findall(html)[0]
        players = re.compile('\x3c\x6c\x69\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x74\x79\x70\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x70\x6f\x73\x74\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x6e\x75\x6d\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x22\x74\x69\x74\x6c\x65\x22\x3e\x28\x2e\x2b\x3f\x29\x3c',re.MULTILINE|re.DOTALL).findall(player)
        players.sort(key=lambda str: str[3])
        data_type, data_post, data_nume, data_name = players[0]
        if len(players) > 1 and re.search("\x50\x6c\x61\x79\x65\x72\x20\x31",data_name,re.IGNORECASE):
            data_type, data_post, data_nume, data_name = players[1]
        selected = data_name
        params = {'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type}
        error_msg = 2
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65\x2e\x74\x6f\x70\x2f\x77\x70\x2d\x61\x64\x6d\x69\x6e\x2f\x61\x64\x6d\x69\x6e\x2d\x61\x6a\x61\x78\x2e\x70\x68\x70',url,post=params)
        if not re.findall('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',html):
            html = custom_proxy('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65\x2e\x74\x6f\x70\x2f\x77\x70\x2d\x61\x64\x6d\x69\x6e\x2f\x61\x64\x6d\x69\x6e\x2d\x61\x6a\x61\x78\x2e\x70\x68\x70',url,post=params)
        episode = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22').findall(html.replace("'",'"'))[0]
        stream = ''
        if len(players) == 1 and 'vanfem.com' in episode:
            xbmcgui.Dialog().ok('Aviso:', '[B]Episódio indisponível.[CR][COLOR gold]Animes Resolver 1 - Código: %s[/COLOR][/B]'%404)
            return 'stop'
        if '\x2f\x72\x65\x64\x70\x6c\x61\x79\x2f' in episode:
            error_msg = 3
            html = getMovieData(episode,url)
            try:
                html = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22').findall(html)[0]
            except:
                pass
            if '\x6c\x69\x6e\x6b\x73\x68\x72\x74\x2e\x6f\x72\x67' in html and len(players) > 1:
                select_another = [play for play in players if not play[3] == selected]
                data_type, data_post, data_nume, data_name = select_another[0]
                params = {'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type}
                base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65\x2e\x74\x6f\x70\x2f\x77\x70\x2d\x61\x64\x6d\x69\x6e\x2f\x61\x64\x6d\x69\x6e\x2d\x61\x6a\x61\x78\x2e\x70\x68\x70',url,post=params)
                episode = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22').findall(base.replace("'",'"'))[0]
                html = getMovieData(episode,url)
                stream = re.compile('\x66\x69\x6c\x65\x3a\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22').findall(html.replace("'",'"'))[0]
                stream = episode.split('\x65\x6d\x62\x65\x64\x2e\x70\x68\x70')[0] + stream
            elif '\x6c\x69\x6e\x6b\x73\x68\x72\x74\x2e\x6f\x72\x67' in html:
                xbmcgui.Dialog().ok('Aviso:', '[B]Episódio indisponível.[CR][COLOR gold]Animes Resolver 1 - Código: %s[/COLOR][/B]'%403)
                return 'stop'
            else:
                # Primeiro
                refer = html
                web_link,params = animes1_tools(html,refer,False,'Get')
                # Segundo
                refer = web_link
                web_link,params = animes1_tools(web_link,refer,params,'Post')
                # Terceiro
                refer = web_link
                web_link,params = animes1_tools(web_link,refer,params,'Post')
                # Quarto
                episode = animes1_tools(web_link,refer,params,'Res')
        if '\x2f\x6d\x70\x34\x64\x6f\x6f\x2f' in episode or '\x64\x6f\x6f\x6d\x70\x34' in episode:
            error_msg = 4
            html = getMovieData(episode, '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65\x2e\x74\x6f\x70\x2f')
            html = re.compile('\x28\x65\x76\x61\x6c\x5c\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e',re.MULTILINE|re.DOTALL).findall(html)[0]
            import jsunpack
            html = jsunpack.unpack(html)
            html = re.compile('\x73\x6f\x75\x72\x63\x65\x73\x3a\x28\x2e\x2b\x29\x2c\x74\x79\x70\x65',re.MULTILINE|re.DOTALL).findall(html.replace("'",'"'))[0]
            import json
            stream = json.loads(html).get('file')
            refer_stream = '%s://%s'%(urlparse(stream).scheme,urlparse(stream).netloc) + '/'
            error_msg = 5
            if stream.endswith('.mp4'):
                return stream + '\x7c\x73\x65\x63\x2d\x63\x68\x2d\x75\x61\x3d\x22\x47\x6f\x6f\x67\x6c\x65\x20\x43\x68\x72\x6f\x6d\x65\x22\x3b\x76\x3d\x22\x31\x31\x31\x22\x2c\x20\x22\x4e\x6f\x74\x28\x41\x3a\x42\x72\x61\x6e\x64\x22\x3b\x76\x3d\x22\x38\x22\x2c\x20\x22\x43\x68\x72\x6f\x6d\x69\x75\x6d\x22\x3b\x76\x3d\x22\x31\x31\x31\x22\x26\x73\x65\x63\x2d\x63\x68\x2d\x75\x61\x2d\x6d\x6f\x62\x69\x6c\x65\x3d\x3f\x31\x26\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73\x26\x73\x65\x63\x2d\x63\x68\x2d\x75\x61\x2d\x70\x6c\x61\x74\x66\x6f\x72\x6d\x3d\x22\x41\x6e\x64\x72\x6f\x69\x64\x22\x26\x41\x63\x63\x65\x70\x74\x3d\x2a\x2f\x2a\x53\x65\x63\x2d\x46\x65\x74\x63\x68\x2d\x53\x69\x74\x65\x3d\x73\x61\x6d\x65\x2d\x6f\x72\x69\x67\x69\x6e\x26\x53\x65\x63\x2d\x46\x65\x74\x63\x68\x2d\x4d\x6f\x64\x65\x3d\x6e\x6f\x2d\x63\x6f\x72\x73\x26\x53\x65\x63\x2d\x46\x65\x74\x63\x68\x2d\x44\x65\x73\x74\x3d\x76\x69\x64\x65\x6f\x26\x52\x65\x66\x65\x72\x65\x72\x3d\x25\x73\x26\x41\x63\x63\x65\x70\x74\x2d\x4c\x61\x6e\x67\x75\x61\x67\x65\x3d\x70\x74\x2d\x42\x52\x2c\x70\x74\x3b\x71\x3d\x30\x2e\x39\x2c\x65\x6e\x2d\x55\x53\x3b\x71\x3d\x30\x2e\x38\x2c\x65\x6e\x3b\x71\x3d\x30\x2e\x37\x26\x41\x63\x63\x65\x70\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67\x3d\x69\x64\x65\x6e\x74\x69\x74\x79'%(useragent,refer_stream)
            html = getMovieData(stream, episode)
            if '\x3c\x68\x31\x3e\x45\x72\x72\x6f\x72\x20\x34\x30\x33\x20\x41\x63\x63\x65\x73\x73\x20\x44\x65\x6e\x69\x65\x64\x20\x32\x3c\x2f\x68\x31\x3e' in html:
                xbmcgui.Dialog().ok('Aviso:', '[B]Episódio indisponível.[CR][COLOR gold]Animes Resolver 1 - Código: %s[/COLOR][/B]'%403)
                return 'stop'
            html = re.compile('(.+?).m3u8').findall(html)
            stream_url = re.compile('http.*\/.+?\/').findall(stream)[0]
            stream = stream_url + html[len(html)-1] + '.m3u8'
            error_msg = 6
            html = getMovieData(stream, stream)
            if '\x2e\x77\x65\x62\x70' in html:
                stream = html
                stream_rep = re.compile('.+?.webp').findall(stream)
                for rep in stream_rep:
                    stream = stream.replace(rep,'http://127.0.0.1:55333/?url=%s'%urllib.quote_plus(stream_url + rep))
                if '\x77\x77\x77\x2d\x6f\x70\x65\x6e\x73\x6f\x63\x69\x61\x6c' in stream:
                    stream = stream.replace('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2d\x6f\x70\x65\x6e\x73\x6f\x63\x69\x61\x6c','\x68\x74\x74\x70\x3a\x2f\x2f\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x3a\x35\x35\x33\x33\x33\x2f\x3f\x75\x72\x6c\x3d\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2d\x6f\x70\x65\x6e\x73\x6f\x63\x69\x61\x6c')
                stream = stream.replace('.webp','.webp&Referer=%s'%urllib.quote_plus(refer_stream))
                py = os.path.join(home, "PlaylistTemp.m3u8")
                file = open(py, "w", encoding="utf-8")
                file.write(stream)
                file.close()
                if six.PY3: return home + 'PlaylistTemp.m3u8'
                if six.PY2: return home + '\PlaylistTemp.m3u8'
        elif 'gpxy.ga' in episode:
            html = getMovieData(episode,episode)
            html = re.compile('\x28\x65\x76\x61\x6c\x5c\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e',re.MULTILINE|re.DOTALL).findall(html)[1]
            import jsunpack
            html = jsunpack.unpack(html).replace("'",'"')
            html = re.compile('player\("(.+?)"',re.MULTILINE|re.DOTALL).findall(html)[0].replace(' ','\n')
            html = getMovieData(html,episode)
            html = re.compile('https.+.m3u8').findall(html)[0]
            html = getMovieData(html,episode).replace(' ','\n')
            if '\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65\x2e\x6e\x65\x74' in html:
                html = re.sub('\x68\x74\x74\x70\x73\x2e\x2b\x3f\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65\x2e\x6e\x65\x74\x2f','',html)
            py = os.path.join(home, "PlaylistTemp.m3u8")
            file = open(py, "w", encoding="utf-8")
            file.write(html)
            file.close()
            if six.PY3: return home + 'PlaylistTemp.m3u8'
            if six.PY2: return home + '\PlaylistTemp.m3u8'
        else:
            error_msg = 7
            if '\x63\x6c\x70\x2d\x6e\x65\x77\x2e\x72\x65\x69\x67\x6e\x2d\x61\x68\x2e\x6f\x6e\x6c\x69\x6e\x65' in html and len(players) > 1:
                select_another = [play for play in players if not play[3] == selected]
                data_type, data_post, data_nume, data_name = select_another[0]
                params = {'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type}
                base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65\x2e\x74\x6f\x70\x2f\x77\x70\x2d\x61\x64\x6d\x69\x6e\x2f\x61\x64\x6d\x69\x6e\x2d\x61\x6a\x61\x78\x2e\x70\x68\x70',url,post=params)
                episode = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22').findall(base.replace("'",'"'))[0]
            html = getMovieData(episode,episode)
            if not '\x66\x69\x6c\x65\x22\x3a\x22' in html and not '\x2f\x6d\x70\x34\x2f\x65\x6d\x62\x65\x64\x2e\x70\x68\x70' in episode:
                import jsunpack
                html = re.compile('\x28\x65\x76\x61\x6c\x5c\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e',re.MULTILINE|re.DOTALL).findall(html)[0]
                html = jsunpack.unpack(html).replace("'",'"')
                stream = re.compile('\x66\x69\x6c\x65\x22\x3a\x22\x28\x2e\x2b\x3f\x29\x22').findall(html.replace("'",'"'))[0]
            else:
                stream = re.compile('\x66\x69\x6c\x65\x3a\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22').findall(html.replace("'",'"'))[0]
                stream = episode.split('\x65\x6d\x62\x65\x64\x2e\x70\x68\x70')[0] + stream
            return stream + '\x7c\x73\x65\x63\x2d\x63\x68\x2d\x75\x61\x3d\x22\x47\x6f\x6f\x67\x6c\x65\x20\x43\x68\x72\x6f\x6d\x65\x22\x3b\x76\x3d\x22\x31\x31\x31\x22\x2c\x20\x22\x4e\x6f\x74\x28\x41\x3a\x42\x72\x61\x6e\x64\x22\x3b\x76\x3d\x22\x38\x22\x2c\x20\x22\x43\x68\x72\x6f\x6d\x69\x75\x6d\x22\x3b\x76\x3d\x22\x31\x31\x31\x22\x26\x73\x65\x63\x2d\x63\x68\x2d\x75\x61\x2d\x6d\x6f\x62\x69\x6c\x65\x3d\x3f\x31\x26\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73\x26\x73\x65\x63\x2d\x63\x68\x2d\x75\x61\x2d\x70\x6c\x61\x74\x66\x6f\x72\x6d\x3d\x22\x41\x6e\x64\x72\x6f\x69\x64\x22\x26\x41\x63\x63\x65\x70\x74\x3d\x2a\x2f\x2a\x53\x65\x63\x2d\x46\x65\x74\x63\x68\x2d\x53\x69\x74\x65\x3d\x73\x61\x6d\x65\x2d\x6f\x72\x69\x67\x69\x6e\x26\x53\x65\x63\x2d\x46\x65\x74\x63\x68\x2d\x4d\x6f\x64\x65\x3d\x6e\x6f\x2d\x63\x6f\x72\x73\x26\x53\x65\x63\x2d\x46\x65\x74\x63\x68\x2d\x44\x65\x73\x74\x3d\x76\x69\x64\x65\x6f\x26\x52\x65\x66\x65\x72\x65\x72\x3d\x25\x73\x26\x41\x63\x63\x65\x70\x74\x2d\x4c\x61\x6e\x67\x75\x61\x67\x65\x3d\x70\x74\x2d\x42\x52\x2c\x70\x74\x3b\x71\x3d\x30\x2e\x39\x2c\x65\x6e\x2d\x55\x53\x3b\x71\x3d\x30\x2e\x38\x2c\x65\x6e\x3b\x71\x3d\x30\x2e\x37\x26\x41\x63\x63\x65\x70\x74\x2d\x45\x6e\x63\x6f\x64\x69\x6e\x67\x3d\x69\x64\x65\x6e\x74\x69\x74\x79'%(useragent,episode)
        return stream + '|User-Agent=%s'%useragent
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 1 - Código: %s[/COLOR][/B]'%error_msg)
        return ''

def animes1_tools(web_link,refer=False,params_send=False,Method='Get'):
    try:
        import binascii
        if not refer:
            refer = web_link
        if Method == 'GetNew':
            url = getMovieData(web_link,refer)
            refresh = re.compile('atob\("(.+?)"\)').findall(url)[0]
            if six.PY3: s = base64._bytes_from_decode_data(refresh.replace('\\x',''))
            if six.PY2: s = refresh.replace('\\x','')
            data = binascii.unhexlify(s)
            data = base64.b64decode(data).decode('utf-8')
            return data
        elif Method == 'Get':
            url = getMovieData(web_link,refer)
            refresh = re.compile('atob\("(.+?)"\)').findall(url)[0]
            if six.PY3: s = base64._bytes_from_decode_data(refresh.replace('\\x',''))
            if six.PY2: s = refresh.replace('\\x','')
            data = binascii.unhexlify(s)
            data = base64.b64decode(data).decode('utf-8')
            params_read = re.compile('name="(.+?)" value="(.+?)"').findall(data)
            params = {}
            for name,value in params_read:
                params.update({name:value})
            data = re.compile('action="(.+?)"').findall(data)[0]
            return data,params
        elif Method == 'Res':
            html = getMovieData(web_link,refer,False,params_send)
            if 'atob(' in html:
                refresh = re.compile('atob\("(.+?)"\)').findall(html)[0]
                if six.PY3: s = base64._bytes_from_decode_data(refresh.replace('\\x',''))
                if six.PY2: s = refresh.replace('\\x','')
                data = binascii.unhexlify(s)
                data = base64.b64decode(data).decode('utf-8')
                return data
            else:
                data = re.compile('\x3c\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22').findall(html)[0]
                return data
        else:
            url = getMovieData(web_link,refer,False,params_send)
            refresh = re.compile('atob\("(.+?)"\)').findall(url)[0]
            if six.PY3: s = base64._bytes_from_decode_data(refresh.replace('\\x',''))
            if six.PY2: s = refresh.replace('\\x','')
            data = binascii.unhexlify(s)
            data = base64.b64decode(data).decode('utf-8')
            params_read = re.compile('name="(.+?)" value="(.+?)"').findall(data)
            params = {}
            for name,value in params_read:
                params.update({name:value})
            data = re.compile('action="(.+?)"').findall(data)[0]
            return data,params
    except:
        return '',[]

def animes2_resolver(url):
    try:
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais.[/B]")
        return 'stop'
        import json
        error_msg = 1
        html = getMovieData(url,'').replace("'",'"')
        if '\x61\x6e\x69\x6d\x65\x5f\x5f\x76\x69\x64\x65\x6f\x5f\x5f\x70\x6c\x61\x79\x65\x72' in html and not '\x70\x6c\x61\x79\x65\x72\x6f\x70\x74\x69\x6f\x6e\x73' in html:
            xbmcgui.Dialog().ok("Aviso:", "[B]Episódio não encontrado![/B]")
            return 'stop'
        player = re.compile('<div id="playeroptions".+?<\/div>',re.MULTILINE|re.DOTALL).findall(html)[0]
        data_type, data_post, data_nume = re.compile('<li.+?data-type="(.+?)".+?data-post="(.+?)".+?data-nume="(.+?)"',re.MULTILINE|re.DOTALL).findall(player)[0]
        params = {'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type}
        error_msg = 2
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x6e\x69\x6d\x65\x73\x7a\x6f\x6e\x65\x2e\x6e\x65\x74\x2f\x77\x70\x2d\x61\x64\x6d\x69\x6e\x2f\x61\x64\x6d\x69\x6e\x2d\x61\x6a\x61\x78\x2e\x70\x68\x70',url,post=params)
        episode = json.loads(html).get('embed_url')
        error_msg = 3
        html = getMovieData(episode,url)
        stream = ''
        if '\x62\x6c\x6f\x67\x67\x65\x72' in episode:
            error_msg = 4
            player_iframe = re.compile('\x70\x6c\x61\x79\x5f\x75\x72\x6c\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22\x2c\x22\x66\x6f\x72\x6d\x61\x74\x5f\x69\x64\x22\x3a\x28\x2e\x2b\x3f\x29\x7d', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
            for play, quality in player_iframe:
                if quality == '22':
                    play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                    return play + '|User-Agent=' + useragent + '&Referer=' + play
            for play, quality in player_iframe:
                if quality == '18':
                    play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                    return play + '|User-Agent=' + useragent + '&Referer=' + play
        elif '\x65\x6d\x62\x65\x64\x2e\x70\x68\x70' in episode:
            if 'File not found.' in html:
                xbmcgui.Dialog().ok('Aviso:', '[B]Episódio ou Temporada não disponível.[/B]')
                return 'stop'
            stream = re.compile('\x7b\x66\x69\x6c\x65\x3a\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
        else:
            error_msg = 5
            if re.findall('\x28\x65\x76\x61\x6c\x5c\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e',html):
                html = re.compile('\x28\x65\x76\x61\x6c\x5c\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e',re.MULTILINE|re.DOTALL).findall(html)[0]
                import jsunhunt
                html = jsunhunt.unhunt(html).replace("'",'"')
            stream = ''
            if not '\x66\x69\x6c\x65\x3a\x20\x22' in html:
                stream = re.compile('\x66\x69\x6c\x65\x3a\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
            else:
                stream = re.compile('\x66\x69\x6c\x65\x3a\x20\x22\x28\x5c\x77\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
            if '\x67\x6f\x6a\x6f\x61\x6e\x69\x6d\x65\x73' in stream:
                error_msg = 6
                stream = getMovieData(stream,stream)
                if '\x77\x77\x77\x2d\x6f\x70\x65\x6e\x73\x6f\x63\x69\x61\x6c' in stream:
                    stream = stream.replace('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2d\x6f\x70\x65\x6e\x73\x6f\x63\x69\x61\x6c','\x68\x74\x74\x70\x3a\x2f\x2f\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x3a\x35\x35\x33\x33\x33\x2f\x3f\x75\x72\x6c\x3d\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2d\x6f\x70\x65\x6e\x73\x6f\x63\x69\x61\x6c')
                stream = stream.replace('.webp','.webp&')
                py = os.path.join(home, "PlaylistTemp.m3u8")
                file = open(py, "w", encoding="utf-8")
                file.write(stream)
                file.close()
                if six.PY3: return home + 'PlaylistTemp.m3u8'
                if six.PY2: return home + '\PlaylistTemp.m3u8'
            elif re.findall('(?:\/\/|\.)((?:.+filemate.+)\.(?:.+))\/(?:media|playlist)\/(playlist)',stream):
                stream = getMovieData(stream,stream).replace('\x68\x74\x74\x70\x3a\x2f\x2f','\x68\x74\x74\x70\x73\x3a\x2f\x2f')
                stream = stream.replace('\x68\x74\x74\x70\x73\x3a\x2f\x2f','\x68\x74\x74\x70\x3a\x2f\x2f\x31\x32\x37\x2e\x30\x2e\x30\x2e\x31\x3a\x35\x35\x33\x33\x33\x2f\x3f\x75\x72\x6c\x3d\x68\x74\x74\x70\x73\x3a\x2f\x2f')
                py = os.path.join(home, "PlaylistTemp.m3u8")
                file = open(py, "w", encoding="utf-8")
                file.write(stream)
                file.close()
                if six.PY3: return home + 'PlaylistTemp.m3u8'
                if six.PY2: return home + '\PlaylistTemp.m3u8'
        return stream + '|User-Agent=%s'%useragent
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 2 - Código: %s[/COLOR][/B]'%error_msg)
        return ''

def animes3_resolver(url):
    def clean_html(html):
        return html.replace(
            '\x63\x6c\x61\x73\x73\x3d\x22\x69\x63\x6f\x6e\x2d\x70\x6c\x61\x79\x5f\x61\x72\x72\x6f\x77\x22\x3e\x3c\x2f\x62\x3e\x20',
            '\x63\x6c\x61\x73\x73\x3d\x22\x69\x63\x6f\x6e\x2d\x70\x6c\x61\x79\x5f\x61\x72\x72\x6f\x77\x22\x3e\x3c\x2f\x62\x3e'
        ).replace(
            '\x20\x3c\x2f\x61\x3e\x3c\x2f\x6c\x69\x3e',
            '\x3c\x2f\x61\x3e\x3c\x2f\x6c\x69\x3e'
        )
    def extract_links_and_languages(html):
        link_pattern = re.compile(
            '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x6f\x70\x74\x69\x6f\x6e\x2d\x2e\x2a\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x2e\x2a\x3f\x3c\x2f\x64\x69\x76\x3e',
            re.MULTILINE | re.DOTALL | re.IGNORECASE
        )
        lang_pattern = re.compile(
            '\x3c\x6c\x69\x3e\x3c\x61\x20\x63\x6c\x61\x73\x73\x3d\x22\x6f\x70\x74\x69\x6f\x6e\x73\x2e\x2a\x3f\x3c\x62\x20\x63\x6c\x61\x73\x73\x3d\x22\x69\x63\x6f\x6e\x2d\x70\x6c\x61\x79\x5f\x61\x72\x72\x6f\x77\x22\x3e\x3c\x2f\x62\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x61\x3e\x3c\x2f\x6c\x69\x3e',
            re.MULTILINE | re.DOTALL | re.IGNORECASE
        )
        return link_pattern.findall(html), lang_pattern.findall(html)
    def prompt_language_selection():
        dialog = xbmcgui.Dialog()
        return dialog.select('ESCOLHA O IDIOMA', ['[B]ASSISTIR DUBLADO[/B]', '[B]ASSISTIR LEGENDADO[/B]'])
    try:
        error_msg = 1
        html = clean_html(getMovieData(url))
        if not re.search('\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x6f\x70\x74\x69\x6f\x6e\x2d\x2e\x2a\x3f\x73\x72\x63\x3d\x22\x2e\x2a\x3f\x22\x2e\x2a\x3f\x3c\x2f\x64\x69\x76\x3e', html, re.MULTILINE | re.DOTALL | re.IGNORECASE):
            html = clean_html(custom_proxy(url, cache={'format': 'days', 'limit': 4}))
        error_msg = 2
        links, languages = extract_links_and_languages(html)
        if len(languages) > 1:
            for i in range(min(2, len(languages))):
                if re.search('FullHD', languages[i], re.IGNORECASE):
                    languages.pop(i)
                    links.pop(i)
                    break
        if len(links) > 1 and 'Legendado' in languages[0]:
            links.reverse()
            languages.reverse()
        selected = None
        if len(links) > 1:
            index = prompt_language_selection()
            if index < 0:
                notify('REPRODUÇÃO CANCELADA!')
                return 'stop'
            error_msg = 3
            selected = links[index]
        elif links:
            error_msg = 4
            selected = links[0]
        else:
            return ''
        if 'blogger' in selected:
            resolved = resolvers.blogger(selected)
            return resolved if resolved else selected
        else:
            return selected
    except Exception:
        xbmcgui.Dialog().ok('Aviso:','[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 3 - Código: {}[/COLOR][/B]'.format(error_msg))
        return ''

def animes4_resolver(url):
    try:
        import json
        error_msg = 1
        html = getMovieData(url,'')
        if '\x6e\x6f\x74\x66\x6f\x75\x6e\x64\x2e\x77\x65\x62\x70' in html:
            xbmcgui.Dialog().ok("Aviso:", "[B]Episódio não encontrado![/B]")
            return 'stop'
        player = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
        if '\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x70\x72\x6f\x74\x6f\x63\x6f\x6c' in player:
            player = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[1]
        html = getMovieData(player,'')
        refer = player
        error_msg = 2
        player = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
        if '\x62\x6c\x6f\x67\x67\x65\x72' in player:
            error_msg = 3
            html = getMovieData(player,'')
            if '\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x65\x72\x72\x6f\x72\x4d\x65\x73\x73\x61\x67\x65\x22\x3e' in html:
                xbmcgui.Dialog().ok("Aviso:", "[B]Episódio não encontrado![/B]")
                return 'stop'
            player_iframe = re.compile('\x70\x6c\x61\x79\x5f\x75\x72\x6c\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22\x2c\x22\x66\x6f\x72\x6d\x61\x74\x5f\x69\x64\x22\x3a\x28\x2e\x2b\x3f\x29\x7d', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
            for play, quality in player_iframe:
                if quality == '22':
                    play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                    return play + '|User-Agent=' + useragent + '&Referer=' + play
            for play, quality in player_iframe:
                if quality == '18':
                    play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                    return play + '|User-Agent=' + useragent + '&Referer=' + play
        else:
            error_msg = 4
            return player.replace('\x76\x69\x64\x65\x6f\x2e\x73\x65\x72\x76\x65\x72\x74\x76\x30\x30\x31\x2e\x63\x6f\x6d','\x76\x69\x64\x65\x6f\x2e\x73\x65\x72\x76\x65\x72\x6e\x69\x6d\x61\x63\x2e\x63\x6f\x6d') + '|User-Agent=' + useragent + '&Referer=' + refer
        raise
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 4 - Código: %s[/COLOR][/B]'%error_msg)
        return ''

def animes5_resolver(url):
    try:
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais ou está em manutenção.[/B]")
        return 'stop'
        import json
        error_msg = 1
        cookie_auth = {}
        html,cookie_auth = getMovieData(url, getcookies=True)
        set_quality = re.compile('\x71\x75\x61\x6c\x69\x74\x79\x53\x74\x72\x69\x6e\x67\x5c\x5b\x22\x28\x2e\x2a\x3f\x29\x22\x5c\x5d\x2e\x2b\x3f\x22\x28\x2e\x2a\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)
        set_quality = sorted(set_quality, key=lambda item: item[0])
        error_msg = 2
        token = re.compile('\x5f\x74\x6f\x6b\x65\x6e\x3a\x22\x28\x2e\x2a\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
        params = {'\x5f\x74\x6f\x6b\x65\x6e': token, '\x69\x6e\x66\x6f': set_quality[0][1]}
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x65\x74\x74\x65\x72\x61\x6e\x69\x6d\x65\x2e\x6e\x65\x74\x2f\x63\x68\x61\x6e\x67\x65\x50\x6c\x61\x79\x65\x72', url, cookies=cookie_auth, post=params)
        error_msg = 3
        import json
        player = json.loads(html).get('\x66\x72\x61\x6d\x65\x4c\x69\x6e\x6b')
        html = getMovieData(player, url, cookies=cookie_auth)
        error_msg = 4
        match = re.search('\x73\x6f\x75\x72\x63\x65\x73\x3a\x5c\x73\x2a\x28\x5c\x7b\x2e\x2a\x3f\x5c\x7d\x29', html, re.DOTALL)
        if match:
            stream_json = json.loads(match.group(1)).get('\x66\x69\x6c\x65')
            return stream_json + '\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73\x26\x52\x65\x66\x65\x72\x65\x72\x3d\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x65\x74\x74\x65\x72\x61\x6e\x69\x6d\x65\x2e\x6e\x65\x74\x2f'%useragent
        raise
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 5 - Código: %s[/COLOR][/B]'%error_msg)
        return ''

def animes6_resolver(url):
    try:
        import ast,json
        error_msg = 1
        url, cookie = url.split('\x78\x70\x61\x6e\x69\x6d\x65\x73\x3d')[1].split('|')
        try:
            cookie = ast.literal_eval(cookie)
        except:
            cookie = {}
        html,cookies = getMovieData(url, url, cookies=cookie, getcookies=True)
        if not re.findall('\x61\x63\x74\x69\x6f\x6e\x3d\x22\x28\x2e\x2b\x3f\x29\x22',html):
            html,cookies = custom_proxy(url, url),{}
        error_msg = 2
        set_player_link = re.compile('\x61\x63\x74\x69\x6f\x6e\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
        send1,send2,send3 = re.compile('\x3c\x69\x6e\x70\x75\x74\x2e\x2b\x3f\x6e\x61\x6d\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x76\x61\x6c\x75\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)
        params = {send1[0]:send1[1], send2[0]:send2[1], send3[0]:send3[1]}
        if set_player_link.startswith('//'):
            set_player_link = 'https:' + set_player_link
        error_msg = 3
        html,cookies = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x74\x72\x75\x65\x6c\x69\x6b\x65\x74\x6f\x70\x2e\x6f\x72\x67\x2f\x72\x61\x6e\x64\x6f\x6d\x2f\x72\x61\x6e\x64\x6f\x6d\x70\x6f\x73\x74\x2e\x70\x68\x70', url, cookies=cookies, getcookies=True, post=params)
        set_player_link = re.compile('\x61\x63\x74\x69\x6f\x6e\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
        if set_player_link.startswith('//'):
            set_player_link = 'https:' + set_player_link
        error_msg = 4
        for number in range(10):
            html = getMovieData(set_player_link, url, cookies=cookies, post={})
            if '\x3c\x69\x66\x72\x61\x6d\x65' in html:
                verify = re.compile('\x22\x63\x6f\x6e\x74\x65\x75\x64\x6f\x22\x3e\x2e\x2b\x3f\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
                if not verify[-1:] == '?':
                    break
        if '\x3c\x69\x66\x72\x61\x6d\x65' in html:
            error_msg = 5
            set_player_link = re.compile('\x22\x63\x6f\x6e\x74\x65\x75\x64\x6f\x22\x3e\x2e\x2b\x3f\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
            for number in range(10):
                html = getMovieData(set_player_link)
                if '\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x3d' in html:
                    break
            if '\x62\x6c\x6f\x67\x67\x65\x72' in set_player_link:
                error_msg = 6
                one_player = False
                frame_count = 0
                try:
                    frame_count = re.compile('\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x3d\x27\x28\x2e\x2b\x3f\x29\x27', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
                    frame_count = len(frame_count)
                except:
                    pass
                if re.search('\x47\x4c\x50\x6c\x61\x79\x65\x72',html,re.IGNORECASE):
                    player_frame = re.compile('\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x3d\x27\x28\x2e\x2b\x3f\x29\x27', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)[0]
                    html = getMovieData(player_frame, url)
                    stream = re.compile('\x66\x69\x6c\x65\x5c\x3a\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)[0]
                    return stream + '|User-Agent=' + useragent + '&Referer=' + stream,''
                if frame_count == 1 and re.search('\x50\x72\x69\x6e\x63\x69\x70\x61\x6c',html,re.IGNORECASE):
                    player_frame = re.compile('\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x3d\x27\x28\x2e\x2b\x3f\x29\x27', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)[0]
                    html = getMovieData(player_frame, url)
                    player_frame = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
                    if '\x62\x6c\x6f\x67\x67\x65\x72' in player_frame:
                        html = getMovieData(player_frame)
                        player_iframe = re.compile('\x70\x6c\x61\x79\x5f\x75\x72\x6c\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22\x2c\x22\x66\x6f\x72\x6d\x61\x74\x5f\x69\x64\x22\x3a\x28\x2e\x2b\x3f\x29\x7d', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
                        for play, quality in player_iframe:
                            if quality == '22':
                                play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                                return play + '|User-Agent=' + useragent + '&Referer=' + play,''
                        for play, quality in player_iframe:
                            if quality == '18':
                                play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                                return play + '|User-Agent=' + useragent + '&Referer=' + play,''
                    else:
                        return '',error_msg
                if ((frame_count == 4 or frame_count == 2) and re.search('\x50\x72\x69\x6e\x63\x69\x70\x61\x6c',html,re.IGNORECASE)):
                    player_frame = re.compile('\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x3d\x27\x28\x2e\x2b\x3f\x29\x27', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)[0]
                    if '\x73\x65\x72\x76\x65\x72\x6a\x77\x2e\x70\x68\x70' in player_frame:
                        player_frame = player_frame.replace('\x73\x65\x72\x76\x65\x72\x6a\x77\x2e\x70\x68\x70\x3f\x66','\x7a\x65\x6f\x74\x61\x6a\x77\x2e\x70\x68\x70\x3f\x7a')
                    html = getMovieData(player_frame, url)
                    stream = re.compile('\x66\x69\x6c\x65\x5c\x3a\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)[0]
                    if '\x2e\x70\x68\x70\x3f' in stream:
                        return stream + '|User-Agent=' + useragent + '&Referer=' + set_player_link,''
                    return stream + '|User-Agent=' + useragent + '&Referer=' + stream,''
                player_frame = re.compile('\x5c\x2d\x5c\x2d\x5c\x3e\x2e\x2b\x3f\x77\x69\x6e\x64\x6f\x77\x2e\x6c\x6f\x63\x61\x74\x69\x6f\x6e\x2e\x68\x72\x65\x66\x3d\x27\x28\x2e\x2b\x3f\x29\x27', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)[0]
                html = getMovieData(player_frame)
                player_frame = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
                html = getMovieData(player_frame)
                if '\x62\x6c\x6f\x67\x67\x65\x72' in player_frame and '\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x65\x72\x72\x6f\x72\x4d\x65\x73\x73\x61\x67\x65\x22\x3e' in html:
                    return 'not found',404
                player_iframe = re.compile('\x70\x6c\x61\x79\x5f\x75\x72\x6c\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22\x2c\x22\x66\x6f\x72\x6d\x61\x74\x5f\x69\x64\x22\x3a\x28\x2e\x2b\x3f\x29\x7d', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
                for play, quality in player_iframe:
                    if quality == '22':
                        play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                        return play + '|User-Agent=' + useragent + '&Referer=' + play,''
                for play, quality in player_iframe:
                    if quality == '18':
                        play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                        return play + '|User-Agent=' + useragent + '&Referer=' + play,''
            else:
                error_msg = 7
                return '',error_msg
        else:
            error_msg = 8
            set_player_link = re.compile('\x73\x6f\x75\x72\x63\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
            return '\x25\x73\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73\x26\x52\x65\x66\x65\x72\x65\x72\x3d\x25\x73'%(set_player_link,useragent,url),''
        raise
    except:
        return '',error_msg

def series_resolver(url):
    try:
        base = getMovieData(url).replace("'",'"')
        language = re.compile('class="source-box"><a href="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
        if len(language) > 1:
            dialog = xbmcgui.Dialog()
            idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
            index = dialog.select('ESCOLHA O IDIOMA', idm)
            if index >= 0:
                if index == 0:
                    language.pop(1)
                else:
                    language.pop(0)
            else:
                notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                return 'stop',''
        url = language[0]
        url = json.loads(base64.b64decode(url.split('auth=')[1])).get('url')
        base = getMovieData(url)
        ids = re.compile('idS="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        params = {'idS': ids}
        base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x70\x6c\x61\x79\x2e\x6d\x69\x64\x69\x61\x66\x6c\x69\x78\x68\x64\x2e\x63\x6f\x6d\x2f\x43\x61\x6c\x6c\x45\x70\x69',post=params)
        import binascii
        if six.PY3: s = base64._bytes_from_decode_data(base.replace('\\x',''))
        if six.PY2: s = base.replace('\\x','')
        data = binascii.unhexlify(s)
        if '"iframe"' in str(data):
            data = json.loads(data).get('url')
            b1 = base64.b64decode(data.split('!')[1]).decode('utf-8')
            b2 = base64.b64decode(data.split('!')[2]).decode('utf-8')
            b3 = base64.b64decode(data.split('!')[3]).decode('utf-8')
            base = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x70\x69\x2e\x78\x6e\x2d\x2d\x66\x64\x61\x2e\x6c\x69\x6e\x6b\x2f\x61\x70\x69\x2f\x65\x70\x69\x73\x6f\x64\x69\x6f\x2f\x3f\x6e\x3d\x25\x73\x2d\x25\x73\x2d\x25\x73'%(b1,b2,b3)
            base = getMovieData(base,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x6a\x73\x61\x7a\x75\x6c\x2e\x62\x6c\x75\x65\x2f')
            base = json.loads(base).get('online')[0]
            for lang in base:
                link = base.get(lang)[0].get('link')
                referer = link
                break
            return link,'true'
        else:
            data = json.loads(data).get('video')[0].get('file')
        refer = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x70\x6c\x61\x79\x2e\x6d\x69\x64\x69\x61\x66\x6c\x69\x78\x68\x64\x2e\x63\x6f\x6d\x2f'
        stream = data + '|User-Agent='+useragent+'&Referer='+refer
        return stream,''
    except:
        return '',''

def series2_resolver(url):
    try:
        base = getMovieData(url.replace('#megaerror0','').replace('#megaerror1','').replace('#megaerror','').replace('#sd_only','')).replace('"',"'")
        mega_lang = 0
        language = re.compile("\x3c\x6c\x69\x20\x64\x61\x74\x61\x2d\x74\x61\x62\x3d\x27\x28\x2e\x2b\x3f\x29\x27\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x6c\x69\x3e", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
        if len(language) == 0:
            notify('[B]Não há links disponíveis.[/B]')
            return 'stop'
        idioma = []
        lang_select = 0
        filters = "\x63\x6c\x61\x73\x73\x3d\x27\x73\x6f\x75\x72\x63\x65\x2d\x62\x6f\x78\x27\x3e\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x6c\x61\x7a\x79\x2d\x73\x72\x63\x3d\x27\x28\x2e\x2b\x3f\x29\x27"
        checker = ''
        try:
            checker = re.compile(filters, re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        except:
            pass
        if '\x77\x70\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x74\x68\x65\x6d\x65\x73\x2f\x64\x6f\x6f\x70\x6c\x61\x79' in checker or 'image.tmdb.org' in checker or len(checker) == 0:
            checker = re.compile("\x63\x6c\x61\x73\x73\x3d\x27\x73\x6f\x75\x72\x63\x65\x2d\x62\x6f\x78\x27\x3e\x2e\x2b\x3f\x73\x72\x63\x3d\x27\x28\x2e\x2b\x3f\x29\x27", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
            filters = "\x63\x6c\x61\x73\x73\x3d\x27\x73\x6f\x75\x72\x63\x65\x2d\x62\x6f\x78\x27\x3e\x2e\x2b\x3f\x73\x72\x63\x3d\x27\x28\x2e\x2b\x3f\x29\x27"
        if '#megaerror' in url:
            checker = '\x66\x6c\x69\x78\x2e\x61\x72\x74\x2f'
        if '#megaerror0' in url:
            mega_lang = 1
        elif '#megaerror1' in url:
            mega_lang = 2
        if '#sd_only' in url:
            for number,lang in language:
                if six.PY3:
                    if re.fullmatch('PLAYER ALTERNATIVO', lang, re.IGNORECASE):
                        idioma.append(number.replace('source-player-',''))
                else:
                    if re.match("(?:" + 'PLAYER ALTERNATIVO' + r")\Z", lang, re.IGNORECASE):
                        idioma.append(number.replace('source-player-',''))
            if len(idioma) == 0:
                return ''
            retry = re.compile(filters, re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[int(idioma[0])-1]
            refer = retry
            url = getMovieData(retry,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
            retry_items = re.compile('\x63\x6c\x61\x73\x73\x3d\x22\x69\x66\x72\x61\x6d\x65\x2d\x6c\x69\x6e\x6b\x22\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
            idioma = []
            retry = ''
            for lang in retry_items:
                if '\x70\x6c\x61\x79\x65\x72\x32' in lang and '\x2f\x64\x75\x62' in lang:
                    idioma.append(('Dublado',lang))
                elif '\x70\x6c\x61\x79\x65\x72\x32' in lang and '\x2f\x6c\x65\x67' in lang:
                    idioma.append(('Legendado',lang))
            if len(idioma) > 1:
                if 'Legendado' in idioma[0]:
                    idioma.reverse()
                else:
                    dialog = xbmcgui.Dialog()
                    idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
                    index = dialog.select('ESCOLHA O IDIOMA', idm)
                    if index >= 0:
                        if index == 0:
                            idioma.pop(1)
                        else:
                            idioma.pop(0)
                    else:
                        notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                        return 'stop'
            retry = idioma[0][1]
            if not retry.startswith('http'):
                retry = 'https:' + retry
            url = getMovieData(retry,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
            retry = re.compile('\x69\x66\x72\x61\x6d\x65\x20\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
            if not retry.startswith('http'):
                retry = 'https:' + retry
            url = getMovieData(retry).replace("'",'"')
            ids = re.compile('\x69\x64\x53\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
            params = {'idS': ids}
            base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x70\x6c\x61\x79\x2e\x6d\x69\x64\x69\x61\x66\x6c\x69\x78\x68\x64\x2e\x63\x6f\x6d\x2f\x2f\x43\x61\x6c\x6c\x45\x70\x69',post=params)
            import binascii
            player = binascii.unhexlify(base)
            stream = json.loads(player).get('video')[0].get('file')
            if stream:
                return stream + '|User-Agent='+useragent+'&Referer=\x68\x74\x74\x70\x73\x3a\x2f\x2f\x70\x6c\x61\x79\x2e\x6d\x69\x64\x69\x61\x66\x6c\x69\x78\x68\x64\x2e\x63\x6f\x6d\x2f'
            else:
                return ''
        if '\x66\x6c\x69\x78\x2e\x61\x72\x74\x2f' in checker or '\x66\x6c\x69\x78\x2e\x62\x65\x73\x74\x2f' in checker or '\x66\x6c\x69\x78\x2e\x63\x63\x2f' in checker or '\x73\x66\x61\x70\x69\x2e\x78\x79\x7a\x2f' in checker or '\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d' in checker:
            if not '#megaerror' in url:
                refer = checker
                url = getMovieData(checker,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
                if not '\x63\x6c\x61\x73\x73\x3d\x22\x65\x70\x69\x73\x6f\x64\x65\x4f\x70\x74\x69\x6f\x6e' in url:
                    try:
                        wrz = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                        wrz_base = getMovieData(wrz,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
                        wrz = re.compile('\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(wrz_base)[0]
                        if '\x77\x61\x72\x65\x7a\x63\x64\x6e' in wrz:
                            return wrz
                    except:
                        pass
            else:
                url = ''
            if not '\x63\x6c\x61\x73\x73\x3d\x22\x65\x70\x69\x73\x6f\x64\x65\x4f\x70\x74\x69\x6f\x6e' in url:
                for number,lang in language:
                    if six.PY3:
                        if re.fullmatch('PLAYER ALTERNATIVO', lang, re.IGNORECASE):
                            idioma.append(number.replace('source-player-',''))
                    else:
                        if re.match("(?:" + 'PLAYER ALTERNATIVO' + r")\Z", lang, re.IGNORECASE):
                            idioma.append(number.replace('source-player-',''))
                retry = re.compile(filters, re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[int(idioma[0])-1]
                refer = retry
                url = getMovieData(retry,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
                retry_items = re.compile('\x63\x6c\x61\x73\x73\x3d\x22\x69\x66\x72\x61\x6d\x65\x2d\x6c\x69\x6e\x6b\x22\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
                idioma = []
                retry = ''
                for lang in retry_items:
                    if '\x70\x6c\x61\x79\x65\x72\x31' in lang and '\x2f\x64\x75\x62' in lang:
                        idioma.append(('Dublado',lang))
                    elif '\x70\x6c\x61\x79\x65\x72\x31' in lang and '\x2f\x6c\x65\x67' in lang:
                        idioma.append(('Legendado',lang))
                if len(idioma) == 0:
                    return '#sd_only'
                if len(idioma) > 1:
                    if 'Legendado' in idioma[0]:
                        idioma.reverse()
                    if mega_lang == 1:
                        idioma.pop(1)
                    elif mega_lang == 2:
                        idioma.pop(0)
                    else:
                        dialog = xbmcgui.Dialog()
                        idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
                        index = dialog.select('ESCOLHA O IDIOMA', idm)
                        if index >= 0:
                            if index == 0:
                                idioma.pop(1)
                            else:
                                idioma.pop(0)
                        else:
                            notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                            return 'stop'
                retry = idioma[0][1]
                if not retry.startswith('http'):
                    retry = 'https:' + retry
                url = getMovieData(retry,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
                retry = re.compile('\x69\x66\x72\x61\x6d\x65\x20\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                if not retry.startswith('http'):
                    retry = 'https:' + retry
                if not '\x65\x6d\x62\x65\x64\x70\x6c\x61\x79\x65\x72\x2e\x73\x69\x74\x65' in retry: return ''
                url = getMovieData(retry,retry).replace("'",'"')
                ids = re.compile('\x69\x64\x53\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                params = {'idS': ids}
                base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x75\x61\x75\x66\x6c\x69\x78\x2e\x6f\x6e\x6c\x69\x6e\x65\x2f\x2f\x43\x61\x6c\x6c\x45\x70\x69',post=params)
                import binascii
                if six.PY3: s = base64._bytes_from_decode_data(base.replace('\\x',''))
                if six.PY2: s = base.replace('\\x','')
                data = binascii.unhexlify(s)
                if '\x22\x69\x66\x72\x61\x6d\x65\x22' in str(data):
                    data = json.loads(data).get('url')
                    link = getMovieData(data)
                    link = re.compile('\x22\x66\x69\x6c\x65\x22\x3a\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link)[0]
                    quality = getMovieData(link,data)
                    quality = re.compile('\x45\x58\x54\x2d\x58\x2d\x53\x54\x52\x45\x41\x4d\x2d\x49\x4e\x46\x2e\x2b\x0a\x28\x2e\x2b\x29', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(quality)[0]
                    link = getMovieData(link.replace('\x2f\x76\x69\x64\x65\x6f\x2e\x6d\x33\x75\x38','/'+quality),data).replace('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2d\x6f\x70\x65\x6e\x73\x6f\x63\x69\x61\x6c\x2e\x67\x6f\x6f\x67\x6c\x65\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x67\x61\x64\x67\x65\x74\x73\x2f\x70\x72\x6f\x78\x79\x3f\x63\x6f\x6e\x74\x61\x69\x6e\x65\x72\x3d\x66\x6f\x63\x75\x73\x26\x72\x65\x66\x72\x65\x73\x68\x3d\x33\x31\x35\x33\x36\x30\x30\x30\x26\x75\x72\x6c\x3d','')
                    if '#EXTM3U' in link:
                        isalive = re.compile('EXTINF.+\n(.+)', re.MULTILINE|re.IGNORECASE).findall(link)[0]
                        if valide_v2(isalive) == False:
                            return ''
                        if int(player_opt) == 0:
                            link = link.replace('https://','http://127.0.0.1:55333/?url=https://')
                        link = link.replace('.webp','.webp&')
                        py = os.path.join(home, "PlaylistTemp.m3u8")
                        file = open(py, "w", encoding="utf-8")
                        file.write(link)
                        file.close()
                        return '#EXTM3U'
                    return ''
                else:
                    data = json.loads(data).get('video')[0].get('file')
                if '\x67\x6f\x6f\x67\x6c\x65\x76\x69\x64\x65\x6f\x2e\x63\x6f\x6d' in data:
                    refer = data
                else:
                    refer = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x75\x61\x75\x66\x6c\x69\x78\x2e\x6f\x6e\x6c\x69\x6e\x65\x2f'
                if valide_v2(data,refer) == False:
                    return ''
                stream = data + '|User-Agent='+useragent+'&Referer='+refer
                return stream
            else:
                episode = re.compile('\x63\x6c\x61\x73\x73\x3d\x22\x65\x70\x69\x73\x6f\x64\x65\x4f\x70\x74\x69\x6f\x6e\x20\x61\x63\x74\x69\x76\x65\x22\x20\x64\x61\x74\x61\x2d\x63\x6f\x6e\x74\x65\x6e\x74\x69\x64\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                url = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f\x61\x70\x69',refer,'',{'action':'getOptions','contentid':episode})
                episode = json.loads(url)
                lang = 0
                if episode.get('errors') == '1':
                    if len(language) == 1:
                        notify('[B]Não há links disponíveis.[/B]')
                        return 'stop'
                    return '#megaerror' + str(lang_select)
                if len(episode.get('data').get('options')) > 1:
                    dialog = xbmcgui.Dialog()
                    idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
                    index = dialog.select('ESCOLHA O IDIOMA', idm)
                    if index >= 0:
                        lang = index
                    else:
                        notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                        return 'stop'
                else:
                    lang = 0
                lang_select = lang
            episode = episode.get('data').get('options')[lang].get('ID')
            url = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f\x61\x70\x69',refer,'',{'action':'getPlayer','video_id':episode})
            episode = json.loads(url)
            episode = episode.get('data').get('video_url')
            alternative = getMovieData(episode,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
            alternative = re.compile('id="alternative" value="(.+?)"', re.DOTALL|re.IGNORECASE).findall(alternative)[0]
            episode = re.compile('vid=(.*)', re.DOTALL|re.IGNORECASE).findall(episode)[0]
            params = {'vid':episode,'alternative':alternative,'ord':'0'}
            base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x2e\x6c\x6f\x6c\x2f\x61\x6a\x61\x78\x5f\x73\x6f\x75\x72\x63\x65\x73\x2e\x70\x68\x70','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f',post=params)
            base = json.loads(base)
            streamtape_fix = True
            for stream in language:
                if six.PY3:
                    if re.fullmatch('PLAYER DUBLADO #2', stream[1], re.IGNORECASE) or re.fullmatch('PLAYER LEGENDADO #2', stream[1], re.IGNORECASE):
                        streamtape_fix = False
                        break
                else:
                    if re.match("(?:" + 'PLAYER DUBLADO #2' + r")\Z", stream[1], re.IGNORECASE) or re.match("(?:" + 'PLAYER LEGENDADO #2' + r")\Z", stream[1], re.IGNORECASE):
                        streamtape_fix = False
                        break
            if '\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65\x2e\x63\x6f\x6d' in str(base.get('iframe')) and not '&aid=' in str(base.get('iframe')):
                if streamtape_fix == True:
                    redir = urllib.unquote(base.get('iframe'))
                    redir = re.compile('id=(.+?)&', re.DOTALL|re.IGNORECASE).findall(redir)[0]
                    return redir
                else:
                    return '#megaerror' + str(lang_select)
            if base.get('iframe') and '\x2f\x65\x6d\x62\x65\x64\x32\x2f' in str(base.get('iframe')):
                redir = getRedirect(base.get('iframe'))
                redir = getMovieData(redir,'')
                redir = re.compile('url: "(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(redir)[0]
                redir = getMovieData(redir,'')
                redir = json.loads(redir).get('sources')[0].get('file')
                if not redir.startswith('http'):
                    redir = 'https:' + str(redir)
                if valide_v2(redir) == False:
                    return '#megaerror' + str(lang_select)
                return redir + '|User-Agent='+useragent+'?disable_hls'
            elif base.get('iframe') and str(base.get('iframe')).startswith('\x2f\x70\x61\x6e\x64\x61\x2f\x3f\x69\x64\x3d') or 'panda' in str(base.get('iframe')):
                panda = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x2e\x6c\x6f\x6c\x2f\x25\x73'%base.get('iframe')
                base = getMovieData(panda,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f','')
                if '\x76\x61\x72\x20\x73\x75\x61\x6d\x75\x6c\x61' in base:
                    return re.compile('\x76\x61\x72\x20\x73\x75\x61\x6d\x75\x6c\x61\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE).findall(base)[0] + '|User-Agent=' + useragent
                base = re.compile("\x5c\x29\x2e\x73\x72\x63\x2e\x2a\x3f\x27\x28\x2e\x2a\x3f\x29\x27", re.DOTALL|re.IGNORECASE).findall(base)[0]
                if not base.startswith('https:') or not base.startswith('http:'):
                    base = 'https:%s'%base
                base = getMovieData(base,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f','')
                stream = re.compile('\x66\x69\x6c\x65\x3a\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.IGNORECASE).findall(base)[0]
                if stream:
                    return stream + '\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73\x26\x52\x65\x66\x65\x72\x65\x72\x3d\x68\x74\x74\x70\x73\x3a\x2f\x2f\x70\x61\x6e\x64\x61\x66\x69\x6c\x65\x73\x2e\x63\x6f\x6d'%useragent
                if len(language) == 1:
                    notify('[B]Não há links disponíveis.[/B]')
                    return 'stop'
                return '#megaerror' + str(lang_select)
            data = base.get('source')[0].get('file')
            if valide_v2(data) == False:
                return '#megaerror' + str(lang_select)
            stream = data + '|User-Agent=' + useragent
            return stream
        elif '\x76\x69\x7a\x65\x72\x2e\x6c\x6f\x6c' in checker:
            dual_lang = False
            if six.PY3:
                if re.fullmatch('PLAYER DUBLADO', language[0][1], re.IGNORECASE) or re.fullmatch('PLAYER LEGENDADO', language[0][1], re.IGNORECASE):
                    dual_lang = True
            else:
                if re.match("(?:" + 'PLAYER DUBLADO' + r")\Z", language[0][1], re.IGNORECASE) or re.match("(?:" + 'PLAYER LEGENDADO' + r")\Z", language[0][1], re.IGNORECASE):
                    dual_lang = True
            if dual_lang == True:
                for number,lang in language:
                    if six.PY3:
                        if re.fullmatch('PLAYER DUBLADO', lang, re.IGNORECASE):
                            idioma.append(('Dublado',number))
                        elif re.fullmatch('PLAYER LEGENDADO', lang, re.IGNORECASE):
                            idioma.append(('Legendado',number))
                    else:
                        if re.match("(?:" + 'PLAYER DUBLADO' + r")\Z", lang, re.IGNORECASE):
                            idioma.append(('Dublado',number))
                        elif re.match("(?:" + 'PLAYER LEGENDADO' + r")\Z", lang, re.IGNORECASE):
                            idioma.append(('Legendado',number))
                if len(idioma) > 1:
                    if 'Legendado' in idioma[0]:
                        idioma.reverse()
                    dialog = xbmcgui.Dialog()
                    idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
                    index = dialog.select('ESCOLHA O IDIOMA', idm)
                    if index >= 0:
                        if index == 0:
                            lang_select = 0
                            idioma.pop(1)
                        else:
                            lang_select = 1
                            idioma.pop(0)
                    else:
                        notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                        return 'stop'
                    checker = re.compile(filters, re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[int(idioma[0][1].replace('source-player-',''))-1]
            url = getMovieData(checker,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
            if not 'id="alternative"' in url:
                return '#megaerror' + str(lang_select)
            alternative = re.compile('id="alternative" value="(.+?)"', re.DOTALL|re.IGNORECASE).findall(url)[0]
            episode = re.compile('vid=(.*)', re.DOTALL|re.IGNORECASE).findall(checker)[0]
            params = {'vid':episode,'alternative':alternative,'ord':'0'}
            base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x2e\x6c\x6f\x6c\x2f\x61\x6a\x61\x78\x5f\x73\x6f\x75\x72\x63\x65\x73\x2e\x70\x68\x70','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f',post=params)
            base = json.loads(base)
            streamtape_fix = True
            for stream in language:
                if six.PY3:
                    if re.fullmatch('PLAYER DUBLADO #2', stream[1], re.IGNORECASE) or re.fullmatch('PLAYER LEGENDADO #2', stream[1], re.IGNORECASE):
                        streamtape_fix = False
                        break
                else:
                    if re.match("(?:" + 'PLAYER DUBLADO #2' + r")\Z", stream[1], re.IGNORECASE) or re.match("(?:" + 'PLAYER LEGENDADO #2' + r")\Z", stream[1], re.IGNORECASE):
                        streamtape_fix = False
                        break
            if '\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65\x2e\x63\x6f\x6d' in str(base.get('iframe')) and not '&aid=' in str(base.get('iframe')):
                if streamtape_fix == True:
                    redir = urllib.unquote(base.get('iframe'))
                    redir = re.compile('id=(.+?)&', re.DOTALL|re.IGNORECASE).findall(redir)[0]
                    return redir
                else:
                    return '#megaerror' + str(lang_select)
            if base.get('iframe') and '\x2f\x65\x6d\x62\x65\x64\x32\x2f' in str(base.get('iframe')):
                redir = urllib.unquote(base.get('iframe'))
                if '&aid=' in redir:
                    redir1 = re.compile('id=(.+?)&', re.DOTALL|re.IGNORECASE).findall(redir)[0]
                    redir2 = re.compile('aid=(.+?)&', re.DOTALL|re.IGNORECASE).findall(redir)[0]
                    if valide_v2(redir1) == True:
                        redir = redir1
                    elif valide_v2(redir2) == True:
                        redir = redir2
                    else:
                        return ''
                    return redir + '|User-Agent='+useragent+'?disable_hls'
                else:
                    redir = re.compile('id=(.+?)&', re.DOTALL|re.IGNORECASE).findall(redir)[0]
                    return redir + '|User-Agent='+useragent+'?disable_hls'
            elif base.get('iframe') and str(base.get('iframe')).startswith('\x2f\x70\x61\x6e\x64\x61\x2f\x3f\x69\x64\x3d') or 'panda' in str(base.get('iframe')):
                panda = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x2e\x6c\x6f\x6c\x2f\x25\x73'%base.get('iframe')
                base = getMovieData(panda,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f','')
                if '\x76\x61\x72\x20\x73\x75\x61\x6d\x75\x6c\x61' in base:
                    return re.compile('\x76\x61\x72\x20\x73\x75\x61\x6d\x75\x6c\x61\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE).findall(base)[0] + '|User-Agent=' + useragent
                base = re.compile("\x5c\x29\x2e\x73\x72\x63\x2e\x2a\x3f\x27\x28\x2e\x2a\x3f\x29\x27", re.DOTALL|re.IGNORECASE).findall(base)[0]
                if not base.startswith('https:') or not base.startswith('http:'):
                    base = 'https:%s'%base
                base = getMovieData(base,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f','')
                stream = re.compile('\x66\x69\x6c\x65\x3a\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.IGNORECASE).findall(base)[0]
                if stream:
                    return stream + '\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73\x26\x52\x65\x66\x65\x72\x65\x72\x3d\x68\x74\x74\x70\x73\x3a\x2f\x2f\x70\x61\x6e\x64\x61\x66\x69\x6c\x65\x73\x2e\x63\x6f\x6d'%useragent
                if len(language) == 1:
                    notify('[B]Não há links disponíveis.[/B]')
                    return 'stop'
                return '#megaerror' + str(lang_select)
            data = base.get('source')[0].get('file')
            if valide_v2(data) == False:
                if len(language) == 1:
                    notify('[B]Não há links disponíveis.[/B]')
                    return 'stop'
                return '#megaerror' + str(lang_select)
            try:
                checker = getMovieData(data,'','','',True)
                if checker.headers['location']:
                    checker = checker.headers['location']
                    if valide_v2(checker) == False:
                        if len(language) == 1:
                            notify('[B]Não há links disponíveis.[/B]')
                            return 'stop'
                        return '#megaerror' + str(lang_select)
            except:
                pass
            stream = data + '|User-Agent=' + useragent
            return stream
        for number,lang in language:
            if six.PY3:
                if re.fullmatch('PLAYER DUBLADO', lang, re.IGNORECASE):
                    idioma.append(('Dublado',number))
                elif re.fullmatch('PLAYER NACIONAL', lang, re.IGNORECASE):
                    idioma.append(('Dublado',number))
                elif re.fullmatch('PLAYER LEGENDADO', lang, re.IGNORECASE):
                    idioma.append(('Legendado',number))
            else:
                if re.match("(?:" + 'PLAYER DUBLADO' + r")\Z", lang, re.IGNORECASE):
                    idioma.append(('Dublado',number))
                elif re.match("(?:" + 'PLAYER NACIONAL' + r")\Z", lang, re.IGNORECASE):
                    idioma.append(('Dublado',number))
                elif re.match("(?:" + 'PLAYER LEGENDADO' + r")\Z", lang, re.IGNORECASE):
                    idioma.append(('Legendado',number))
        if len(idioma) > 1:
            if 'Legendado' in idioma[0]:
                idioma.reverse()
        if len(idioma) > 1:
            dialog = xbmcgui.Dialog()
            idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
            index = dialog.select('ESCOLHA O IDIOMA', idm)
            if index >= 0:
                if index == 0:
                    lang_select = 0
                    idioma.pop(1)
                else:
                    lang_select = 1
                    idioma.pop(0)
            else:
                notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                return 'stop'
        url = re.compile("\x63\x6c\x61\x73\x73\x3d\x27\x73\x6f\x75\x72\x63\x65\x2d\x62\x6f\x78\x27\x3e\x2e\x2b\x3f\x61\x73\x79\x6e\x63\x20\x73\x72\x63\x3d\x27\x28\x2e\x2b\x3f\x29\x27", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[int(idioma[0][1])-1]
        url = getMovieData(url,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f')
        alternative = re.compile('id="alternative" value="(.+?)"', re.DOTALL|re.IGNORECASE).findall(url)[0]
        base = re.compile("\x76\x61\x72\x20\x68\x61\x73\x68\x20\x3d\x20\x27\x28\x2e\x2b\x3f\x29\x27", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
        params = {'vid':base,'alternative':alternative,'ord':'0'}
        base = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x2e\x6c\x6f\x6c\x2f\x61\x6a\x61\x78\x5f\x73\x6f\x75\x72\x63\x65\x73\x2e\x70\x68\x70','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x66\x6c\x69\x78\x61\x70\x69\x2e\x63\x6f\x6d\x2f',post=params)
        base = json.loads(base)
        data = base.get('source')[0].get('file')
        if valide_v2(data) == False:
            return '#megaerror' + str(lang_select)
        stream = data + '|User-Agent=' + useragent
        return stream
    except:
        return ''

def series3_resolver(url):
    try:
        base = getMovieData(url).replace('\n','').replace('\r','').replace("'",'"')
        if not '\x22\x6f\x6e\x63\x6c\x69\x63\x6b\x22\x2c\x22\x47\x65\x74\x49\x66\x72\x61\x6d\x65' in base:
            base = custom_proxy(url,cache={'format':'days','limit':4}).replace('\n','').replace('\r','').replace("'",'"')
        embed = ''
        if re.findall('\x23\x76\x69\x64\x65\x6f\x5f\x65\x6d\x62\x65\x64\x2e\x2a\x3f\x3c\x69\x66\x72\x61\x6d\x65\x20\x73\x72\x63\x3d\x22\x28\x2e\x2a\x3f\x29\x67\x65\x74\x65\x6d\x62\x65\x64\x2e\x70\x68\x70',base):
            embed = re.findall('\x23\x76\x69\x64\x65\x6f\x5f\x65\x6d\x62\x65\x64\x2e\x2a\x3f\x3c\x69\x66\x72\x61\x6d\x65\x20\x73\x72\x63\x3d\x22\x28\x2e\x2a\x3f\x29\x67\x65\x74\x65\x6d\x62\x65\x64\x2e\x70\x68\x70',base)[-1]
        elif re.findall('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x72\x65\x64\x69\x72\x65\x63\x74\x2e\x70\x68\x70',base):
            embed = re.findall('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x72\x65\x64\x69\x72\x65\x63\x74\x2e\x70\x68\x70',base)[-1]
        if embed.startswith('/'):
            embed = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x25\x73'%(OVERFLIXTV_HOST,embed)
        language = re.compile('\x5c\x28\x22\x23\x6d\x69\x78\x64\x72\x6f\x70\x22\x5c\x29\x2e\x61\x74\x74\x72\x5c\x28\x22\x6f\x6e\x63\x6c\x69\x63\x6b\x22\x2c\x22\x47\x65\x74\x49\x66\x72\x61\x6d\x65\x5c\x28\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x22\x6d\x69\x78\x64\x72\x6f\x70\x22\x2e\x2b\x3f\x5c\x28\x22\x23\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65\x22\x5c\x29\x2e\x61\x74\x74\x72\x5c\x28\x22\x6f\x6e\x63\x6c\x69\x63\x6b\x22\x2c\x22\x47\x65\x74\x49\x66\x72\x61\x6d\x65\x5c\x28\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x22\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65\x22\x2e\x2b\x3f\x5c\x28\x22\x23\x66\x69\x6c\x65\x6d\x6f\x6f\x6e\x22\x5c\x29\x2e\x61\x74\x74\x72\x5c\x28\x22\x6f\x6e\x63\x6c\x69\x63\x6b\x22\x2c\x22\x47\x65\x74\x49\x66\x72\x61\x6d\x65\x5c\x28\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x22\x66\x69\x6c\x65\x6d\x6f\x6f\x6e\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
        lang_select = 0
        if '\x69\x64\x3d\x22\x6c\x65\x67\x65\x6e\x64\x61\x64\x6f\x22\x20\x63\x6c\x61\x73\x73\x3d\x22\x61\x75\x64\x69\x6f\x20\x61\x63\x74\x69\x76\x65\x22' in base:
            language.reverse()
        if len(language) > 1:
            dialog = xbmcgui.Dialog()
            idm = ['[B]ASSISTIR DUBLADO[/B]','[B]ASSISTIR LEGENDADO[/B]']
            index = dialog.select('ESCOLHA O IDIOMA', idm)
            if index >= 0:
                if index == 0:
                    language.pop(1)
                else:
                    language.pop(0)
                    lang_select = 1
            else:
                notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                return 'stop'
        dialog = xbmcgui.Dialog()
        idm = ['[B]MIXDROP - RÁPIDO[/B]','[B]STREAMTAPE - INDICADO PARA INTERNET LENTA[/B]','[B]FILEMOON - A ÚLTIMA ESPERANÇA[/B]', '[B]DOODSTREAM - INDICADO PARA INTERNET LENTA[/B]']
        index = dialog.select('ESCOLHA O SERVIDOR', idm)
        def stream_choose(choose,lang_select):
            server = '\x6d\x69\x78\x64\x72\x6f\x70'
            if choose == 1:
                server = '\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65'
            elif choose == 2:
                server = '\x66\x69\x6c\x65\x6d\x6f\x6f\x6e'
            elif choose == 3:
                server = '\x64\x6f\x6f\x64\x73\x74\x72\x65\x61\x6d'
            redir = '\x25\x73\x67\x65\x74\x70\x6c\x61\x79\x2e\x70\x68\x70\x3f\x69\x64\x3d\x25\x73\x26\x73\x76\x3d\x25\x73'%(embed,language[0],server)
            html = getMovieData(redir,redir,head=True).headers.get('location')
            if not html:
                html = custom_proxy(redir,redir,head=True,cache={'format':'days','limit':4}).get('location')
            stream_select = re.compile('\x68\x74\x74\x70\x73\x2e\x2b\x5c\x2f\x28\x2e\x2b\x29').findall(html)[0]
            return stream_select
        if index >= 0:
            language = language[0]
            stream_select = stream_choose(index,lang_select)
            if index == 0:
                return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6d\x69\x78\x64\x72\x6f\x70\x2e\x70\x73\x2f\x65\x2f\x25\x73'%stream_select
            elif index == 1:
                return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65\x2e\x63\x6f\x6d\x2f\x65\x2f\x25\x73'%stream_select
            elif index == 2:
                return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x65\x6d\x6f\x6f\x6e\x2e\x73\x78\x2f\x65\x2f\x25\x73'%stream_select
            elif index == 3:
                return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x64\x70\x6c\x79\x2e\x63\x6f\x6d\x2f\x65\x2f\x25\x73'%stream_select
        else:
            notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
            return 'stop'
        return ''
    except:
        return ''

def SF_Web(url,referer=False,user=False,post=False,head=False):
    try:
        req = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'sec-ch-ua': sec_ch_ua,
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': useragent
        }
        if user:
            req.update({'User-Agent':user})
        if referer:
            req.update({'Referer':referer})
        if post:
            response = requests.post(url,headers=req,data=post, timeout=15).text
        elif head:
            response = requests.head(url,headers=req, timeout=15)
        else:
            response = requests.get(url,headers=req, timeout=15).text
        return response
    except:
        return ''

def SF_Resolver_Tools(web_link,refer=False,params_send=False,Method='Get'):
    try:
        import binascii
        if not refer:
            refer = web_link
        if Method == 'GetNew':
            url = SF_Web(web_link,refer)
            refresh = re.compile('atob\("(.+?)"\)').findall(url)[0]
            if six.PY3: s = base64._bytes_from_decode_data(refresh.replace('\\x',''))
            if six.PY2: s = refresh.replace('\\x','')
            data = binascii.unhexlify(s)
            data = base64.b64decode(data).decode('utf-8')
            return data
        elif Method == 'Get':
            url = SF_Web(web_link,refer)
            refresh = re.compile('atob\("(.+?)"\)').findall(url)[0]
            if six.PY3: s = base64._bytes_from_decode_data(refresh.replace('\\x',''))
            if six.PY2: s = refresh.replace('\\x','')
            data = binascii.unhexlify(s)
            data = base64.b64decode(data).decode('utf-8')
            params_read = re.compile('name="(.+?)" value="(.+?)"').findall(data)
            params = {}
            for name,value in params_read:
                params.update({name:value})
            data = re.compile('action="(.+?)"').findall(data)[0]
            return data,params
        elif Method == 'Res':
            html = SF_Web(web_link,refer,False,params_send)
            refresh = re.compile('atob\("(.+?)"\)').findall(html)[0]
            if six.PY3: s = base64._bytes_from_decode_data(refresh.replace('\\x',''))
            if six.PY2: s = refresh.replace('\\x','')
            data = binascii.unhexlify(s)
            data = base64.b64decode(data).decode('utf-8')
            return data
        else:
            url = SF_Web(web_link,refer,False,params_send)
            refresh = re.compile('atob\("(.+?)"\)').findall(url)[0]
            if six.PY3: s = base64._bytes_from_decode_data(refresh.replace('\\x',''))
            if six.PY2: s = refresh.replace('\\x','')
            data = binascii.unhexlify(s)
            data = base64.b64decode(data).decode('utf-8')
            params_read = re.compile('name="(.+?)" value="(.+?)"').findall(data)
            params = {}
            for name,value in params_read:
                params.update({name:value})
            data = re.compile('action="(.+?)"').findall(data)[0]
            return data,params
    except:
        return '',[]

def SF_LangResolver(url):
    try:
        url = CloudRequest(url,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x74\x65\x6c\x61\x6d\x69\x78\x2e\x6e\x65\x74\x2f',useragent)
        web_link = re.compile('\x69\x64\x3d\x22\x61\x61\x2d\x6f\x70\x74\x69\x6f\x6e\x73\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x73\x69\x64\x65\x3e',re.MULTILINE|re.DOTALL).findall(url)[0]
        web_link = re.compile('\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(web_link)
        idioma = []
        for number,lang in web_link:
            language = re.compile('"#'+str(number)+'".*?server">(.*?)<',re.MULTILINE|re.DOTALL).findall(url)[0]
            if language == 'Mega - ' or language == 'Ok - ' or language == 'OpenLoad - ':
                pass
            else:
                language = re.compile('.* (.*)',re.MULTILINE|re.DOTALL).findall(language)[0]
                if six.PY3:
                    if re.fullmatch('Dublado', language, re.IGNORECASE):
                        idioma.append(('Dublado',lang))
                    elif re.fullmatch('Legendado', language, re.IGNORECASE):
                        idioma.append(('Legendado',lang))
                    elif re.fullmatch('Nacional', language, re.IGNORECASE):
                        idioma.append(('Dublado',lang))
                else:
                    if re.match("(?:" + 'Dublado' + r")\Z", language, re.IGNORECASE):
                        idioma.append(('Dublado',lang))
                    elif re.match("(?:" + 'Legendado' + r")\Z", language, re.IGNORECASE):
                        idioma.append(('Legendado',lang))
                    elif re.match("(?:" + 'Nacional' + r")\Z", language, re.IGNORECASE):
                        idioma.append(('Dublado',lang))
        if len(idioma) > 1:
            dialog = xbmcgui.Dialog()
            idm = []
            counter = 1
            for add_lang,lang_url in idioma:
                idm.append(str(counter)+' - '+str('[B]ASSISTIR ')+add_lang.upper()+'[/B]')
                counter = counter + 1
            index = dialog.select('ESCOLHA O IDIOMA', idm)
            if index >= 0:
                web_link = idioma[index][1]
                return web_link
            else:
                notify('[B]REPRODUÇÃO CANCELADA![/B]',200)
                return 'stop'
        else:
            web_link = idioma[0][1]
            return web_link
    except:
        return ''

def SF_Resolver(web_link):
    try:
        try:
            # Primeiro
            refer = web_link
            web_link,params = SF_Resolver_Tools(web_link,web_link,False,'Get')
            # Segundo
            refer = web_link
            web_link,params = SF_Resolver_Tools(web_link,refer,params,'Post')
            # Terceiro
            refer = web_link
            web_link,params = SF_Resolver_Tools(web_link,refer,params,'Post')
            # Quarto
            html = SF_Resolver_Tools(web_link,refer,params,'Res')
            web_link = re.compile('\x3c\x69\x66\x72\x61\x6d\x65\x20\x77\x69\x64\x74\x68\x3d\x22\x31\x30\x30\x25\x22\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
            # Quinto
            refer = web_link
            html = SF_Resolver_Tools(web_link,refer,False,'Res')
            web_link = re.compile('\x73\x6f\x75\x72\x63\x65\x73\x3a\x2e\x2b\x3f\x66\x69\x6c\x65\x3a\x20\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.DOTALL).findall(html)[0]
        except:
            return ''
        # Final
        html = SF_Web(web_link,refer)
        refer = web_link
        web_link = re.compile('RESOLUTION=.*x(.*)\n(.*)',re.MULTILINE|re.DOTALL).findall(html)[0][1]
        if web_link and not 'https://' in web_link:
            web_zero = re.compile('https:\/\/.*\/',re.MULTILINE|re.DOTALL).findall(refer)[0]
            web_link = web_zero + web_link
        if web_link:
            url = SF_Web(web_link,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x70\x6c\x61\x79\x2e\x73\x66\x73\x74\x72\x65\x61\x6d\x2e\x6e\x65\x74\x2f')
            if url == '' or not '.png' in url:
                return None
            web_host = re.compile('https:\/\/.*\/',re.MULTILINE|re.DOTALL).findall(web_link)[0]
            web_replace = re.compile('https:\/\/.*\/(.*).m3u8',re.MULTILINE|re.DOTALL).findall(web_link)[0]
            #Tratar Lista
            if int(player_opt) == 0:
                url = url.replace(web_replace,'http://127.0.0.1:55333/?url='+str(web_host)+str(web_replace))
            url = url.replace('.png','.png&Referer='+urllib.quote_plus('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x70\x6c\x61\x79\x2e\x73\x66\x73\x74\x72\x65\x61\x6d\x2e\x6e\x65\x74\x2f'))
            #Fim
            py = os.path.join(home, "PlaylistTemp.m3u8")
            file = open(py, "w", encoding="utf-8")
            file.write(url)
            file.close()
            return url
        else:
            return None
    except:
        return None

def wovy_seasonslinks(url,season,custom_useragent):
    try:
        try:
            Path = home
            if os.path.exists(Path+'\cloudrequest')==False:
                import zipfile, io
                if six.PY3: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x33\x2e\x7a\x69\x70')
                if six.PY2: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x32\x2e\x7a\x69\x70', stream=True)
                z = zipfile.ZipFile(io.BytesIO(r.content))
                z.extractall(Path)
            else:
                Version_CloudRequest()
        except:
            notify('[B]Erro ao importar plugin![/B]')
        import cloudrequest, html
        WOVY_URI = decode(features_pass, WOVY_URL)
        livewire_url = "\x25\x73\x2f\x6c\x69\x76\x65\x77\x69\x72\x65\x2f\x75\x70\x64\x61\x74\x65"%WOVY_URI
        headers = {
            'Host':urlparse(WOVY_URI).netloc,
            'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language':'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding':'gzip, deflate',
            'X-Requested-With':'\x63\x6f\x6d\x2e\x61\x70\x70\x2e\x77\x61\x74\x63\x68\x75\x67',
            'Sec-Fetch-Site':'same-origin',
            'Sec-Fetch-Mode':'navigate',
            'Sec-Fetch-User':'?1',
            'Sec-Fetch-Dest':'document',
            'Referer':'\x25\x73\x2f\x74\x76\x2d\x73\x68\x6f\x77\x73'%WOVY_URI,
            'Upgrade-Insecure-Requests':'1',
            'User-Agent':custom_useragent
        }
        session = cloudrequest.create_scraper(browser={'browser': 'firefox','platform': 'windows','mobile': False})
        # Requisição GET para obter o HTML da página
        res = session.get(page_url, headers=headers)
        html_content = res.text
        # Extrai o token CSRF da meta tag
        csrf_match = re.search('\x3c\x6d\x65\x74\x61\x20\x6e\x61\x6d\x65\x3d\x22\x63\x73\x72\x66\x2d\x74\x6f\x6b\x65\x6e\x22\x20\x63\x6f\x6e\x74\x65\x6e\x74\x3d\x22\x28\x5b\x5e\x22\x5d\x2b\x29\x22', html_content)
        csrf_token = csrf_match.group(1) if csrf_match else None
        # Extrai todos os snapshots
        snapshot_matches = re.findall('\x77\x69\x72\x65\x3a\x73\x6e\x61\x70\x73\x68\x6f\x74\x5c\x73\x2a\x3d\x5c\x73\x2a\x22\x28\x5b\x5e\x22\x5d\x2b\x29\x22', html_content)
        snapshots = [html.unescape(s) for s in snapshot_matches]
        # Filtra o snapshot do componente principal
        main_snapshot = None
        for s in snapshots:
            try:
                data = json.loads(s)
                if data.get("memo", {}).get("name") == "theme.default.tv":
                    main_snapshot = s
                    break
            except Exception:
                continue
        # Monta o corpo da requisição
        payload = {
            "_token": csrf_token,
            "components": [
                {
                    "snapshot": main_snapshot,
                    "updates": {
                        "selected": season
                    },
                    "calls": []
                }
            ]
        }
        # Cabeçalhos necessários
        headers.update({
            "Origin": WOVY_URI,
            "Referer": page_url,
            "X-CSRF-TOKEN": csrf_token
        })
        # Envia a requisição POST
        dados = session.post(livewire_url, json=payload, headers=headers).json()
        # Extrai o HTML
        html_renderizado = dados["components"][0]["effects"]["html"]
        # Salva em um arquivo HTML
        return html_renderizado
    except:
        pass
    return None

def wovy_streamlink(url,custom_useragent):
    try:
        try:
            Path = home
            if os.path.exists(Path+'\cloudrequest')==False:
                import zipfile, io
                if six.PY3: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x33\x2e\x7a\x69\x70')
                if six.PY2: r = requests.get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2e\x67\x69\x74\x68\x75\x62\x2e\x69\x6f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2f\x61\x64\x64\x6f\x6e\x73\x2f\x63\x6c\x6f\x75\x64\x72\x65\x71\x75\x65\x73\x74\x2d\x70\x79\x32\x2e\x7a\x69\x70', stream=True)
                z = zipfile.ZipFile(io.BytesIO(r.content))
                z.extractall(Path)
            else:
                Version_CloudRequest()
        except:
            notify('[B]Erro ao importar plugin![/B]')
        import cloudrequest, html
        WOVY_URI = decode(features_pass, WOVY_URL)
        livewire_url = "\x25\x73\x2f\x6c\x69\x76\x65\x77\x69\x72\x65\x2f\x75\x70\x64\x61\x74\x65"%WOVY_URI
        headers = {
            'Host':urlparse(WOVY_URI).netloc,
            'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language':'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
            'Accept-Encoding':'gzip, deflate',
            'X-Requested-With':'\x63\x6f\x6d\x2e\x61\x70\x70\x2e\x77\x61\x74\x63\x68\x75\x67',
            'Sec-Fetch-Site':'same-origin',
            'Sec-Fetch-Mode':'navigate',
            'Sec-Fetch-User':'?1',
            'Sec-Fetch-Dest':'document',
            'Referer':url,
            'Upgrade-Insecure-Requests':'1',
            'User-Agent':custom_useragent
        }
        session = cloudrequest.create_scraper(browser={'browser': 'firefox','platform': 'windows','mobile': False})
        # Requisição GET
        res = session.get(url, headers=headers)
        html_content = res.text
        # Extrai o token CSRF
        csrf_match = re.search('\x3c\x6d\x65\x74\x61\x20\x6e\x61\x6d\x65\x3d\x22\x63\x73\x72\x66\x2d\x74\x6f\x6b\x65\x6e\x22\x20\x63\x6f\x6e\x74\x65\x6e\x74\x3d\x22\x28\x5b\x5e\x22\x5d\x2b\x29\x22', html_content)
        csrf_token = csrf_match.group(1) if csrf_match else None
        # Extrai o snapshot do componente 'theme.default.episode'
        snapshot = None
        for match in re.findall('\x77\x69\x72\x65\x3a\x73\x6e\x61\x70\x73\x68\x6f\x74\x5c\x73\x2a\x3d\x5c\x73\x2a\x22\x28\x5b\x5e\x22\x5d\x2b\x29\x22', html_content):
            decoded = html.unescape(match)
            try:
                data = json.loads(decoded)
                if data.get("memo", {}).get("name") == "theme.default.episode":
                    snapshot = decoded
                    break
            except:
                continue
        # Monta o payload completo
        if snapshot and csrf_token:
            payload = {
                "_token": csrf_token,
                "components": [
                    {
                        "snapshot": snapshot,
                        "updates": {},
                        "calls": [
                            {
                                "path": "",
                                "method": "watching",
                                "params": []
                            }
                        ]
                    }
                ]
            }
            headers = {
                "Content-Type": "application/json",
                "X-Livewire": "",
                "X-CSRF-TOKEN": csrf_token,
                "X-Requested-With": "XMLHttpRequest",
                "Referer": url,
                "User-Agent": custom_useragent
            }
            res = session.post(livewire_url, headers=headers, json=payload)
            if res.ok:
                # Extrai o HTML
                scripts = res.json()["components"][0]["effects"]["scripts"]
                scripts_key = next(iter(scripts))
                html = scripts[scripts_key]
                # playerConfig
                match = re.search('\x66\x69\x6c\x65\x3a\x5c\x73\x2a\x22\x68\x74\x74\x70\x73\x3a\x5c\x5c\x2f\x5c\x5c\x2f\x5b\x5e\x22\x5d\x2b\x5c\x2e\x6d\x33\x75\x38\x22', html)
                if match:
                    file_url = match.group(0).split('"')[1].replace('\\/', '/')
                    return file_url
    except:
        pass
    return None

def wvmob_resolver(url):
    try:
        if features_enable == 'true' and not features_pass == '':
            if not features_checker():
                xbmcgui.Dialog().ok('Aviso:', '[B]Opção indisponível - Reinicie seu Kodi.[/B]')
                return 'stop',''
        else:
            xbmcgui.Dialog().ok('Aviso:', '[B]Opção indisponível - Reinicie seu Kodi.[/B]')
            return 'stop',''
        import ast
        url = ast.literal_eval(url)
        wvmob_user = url[2]
        refer = url[1]
        url = url[0]
        WOVY_URI = decode(features_pass, WOVY_URL)
        stream_link = wovy_streamlink(url,wvmob_user)
        if not stream_link:
            return "",""
        refer_stream = '%s://%s'%(urlparse(stream_link).scheme,urlparse(stream_link).netloc)
        link = ''
        try:
            link = getWVMData(stream_link,refer_stream,wvmob_user)
            stream_pkg = re.compile('\x45\x58\x54\x2d\x58\x2d\x53\x54\x52\x45\x41\x4d\x2d\x49\x4e\x46\x2e\x2b\x3f\x28\x68\x74\x74\x70\x2e\x2b\x3f\x5c\x2e\x6d\x33\x75\x38\x29',re.MULTILINE|re.DOTALL).findall(link)[0]
        except:
            wvmob_user = ''
            if not xbmcaddon.Addon().getSetting("wvmob_user"):
                wvmob_time = str(time.time()).split('.')[0]
                wvmob_time = datetime.fromtimestamp(int(wvmob_time)) + timedelta(hours=5)
                params = '\x7b\x27\x77\x76\x6d\x6f\x62\x27\x3a\x20\x31\x7d'
                params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
                wvmob_user = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params))
                wvmob_user = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(wvmob_user)[0]
                addon.setSetting("wvmob_user",str(wvmob_user))
                addon.setSetting("wvmob_time",str(wvmob_time.timestamp()).split('.')[0])
            elif int(xbmcaddon.Addon().getSetting("wvmob_time")) <= int(str(time.time()).split('.')[0]):
                wvmob_time = str(time.time()).split('.')[0]
                wvmob_time = datetime.fromtimestamp(int(wvmob_time)) + timedelta(hours=5)
                params = '\x7b\x27\x77\x76\x6d\x6f\x62\x27\x3a\x20\x31\x7d'
                params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
                wvmob_user = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params))
                wvmob_user = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(wvmob_user)[0]
                addon.setSetting("wvmob_user",str(wvmob_user))
                addon.setSetting("wvmob_time",str(wvmob_time.timestamp()).split('.')[0])
            else:
                wvmob_user = xbmcaddon.Addon().getSetting("wvmob_user")
            link = getWVMData(stream_link,refer_stream,wvmob_user)
        stream_pkg = re.compile('\x45\x58\x54\x2d\x58\x2d\x53\x54\x52\x45\x41\x4d\x2d\x49\x4e\x46\x2e\x2b\x3f\x28\x68\x74\x74\x70\x2e\x2b\x3f\x5c\x2e\x6d\x33\x75\x38\x29',re.MULTILINE|re.DOTALL).findall(link)[0]
        stream_lang = re.compile('\x4c\x41\x4e\x47\x55\x41\x47\x45\x3d\x22\x70\x74\x22\x2c\x55\x52\x49\x3d\x22\x28\x2e\x2a\x3f\x29\x22').findall(link)
        if link == '':
            xbmcgui.Dialog().ok('Aviso:', '[B]Episódio ou Temporada não disponível.[/B]')
            return '',''
        sub = ''
        if stream_lang:
            sub = stream_lang[0]
            get_sub = getWVMData(sub,refer_stream,wvmob_user)
            try:
                get_sub = re.findall('.*?.vtt',get_sub)[0]
                sub = get_sub + '|User-Agent=%s&Referer=%s'%(wvmob_user,refer_stream)
            except:
                sub = ''
        link = link.replace('\x55\x52\x49\x3d\x22\x22','\x55\x52\x49\x3d\x22\x52\x45\x4d\x4f\x56\x45\x22')
        stream_fix = re.compile('\x55\x52\x49\x3d\x22\x28\x2e\x2b\x3f\x29\x22',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(link)
        for replace in stream_fix:
            if not "REMOVE" in replace:
                link = link.replace(replace, 'http://127.0.0.1:55333/?url=' + urllib.quote_plus(replace) + '&Referer=%s&User-Agent=%s'%(urllib.quote_plus(refer_stream),urllib.quote_plus(wvmob_user)))
        if six.PY3: link = link.replace(stream_pkg,home + 'PlaylistTemp.m3u8').replace('\x55\x52\x49\x3d\x22\x52\x45\x4d\x4f\x56\x45\x22','\x55\x52\x49\x3d\x22\x22')
        if six.PY2: link = link.replace(stream_pkg,home + '\PlaylistTemp.m3u8').replace('\x55\x52\x49\x3d\x22\x52\x45\x4d\x4f\x56\x45\x22','\x55\x52\x49\x3d\x22\x22')
        py = os.path.join(home, "Playlist.m3u8")
        file = open(py, "w", encoding="utf-8")
        file.write(link.replace('\r',''))
        file.close()
        link = ''
        link = getWVMData(stream_pkg,refer_stream,wvmob_user).replace('\r','')
        #####
        stream_fix = re.compile('\x28\x68\x74\x74\x70\x73\x2e\x2b\x3f\x2e\x74\x73\x29', re.MULTILINE|re.IGNORECASE).findall(link)
        for replace in stream_fix:
            link = link.replace(replace,urllib.quote_plus(replace))
        link = link.replace('https%3A%2F%2F','http://127.0.0.1:55333/?url=https://')
        #rem = re.compile('\x5c\x23\x45\x58\x54\x49\x4e\x46\x5c\x3a\x2e\x2b\x3f\x2c\x2e\x2b\x3f\x5c\x2e\x74\x73\x0a', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link)[0]
        #link = link.replace(rem,'')
        link = link.replace('.ts','.ts&Referer=%s&User-Agent=%s'%(urllib.quote_plus(refer_stream),urllib.quote_plus(wvmob_user)))
        py = os.path.join(home, "PlaylistTemp.m3u8")
        file = open(py, "w", encoding="utf-8")
        file.write(link)
        file.close()
        #return
        if six.PY3: return home + 'Playlist.m3u8',sub
        if six.PY2: return home + '\PlaylistTemp.m3u8',sub
    except:
        return '',''

def wvmob_req(url,refer,user):
    req = {
        'Host':urlparse(url).netloc,
        'user-agent':user,
        'accept':'*/*',
        'origin':refer,
        'x-requested-with':'\x63\x6f\x6d\x2e\x61\x70\x70\x2e\x77\x61\x74\x63\x68\x75\x67',
        'sec-fetch-site':'same-site',
        'sec-fetch-mode':'cors',
        'sec-fetch-dest':'empty',
        'referer':refer + '/',
        'accept-encoding':'gzip, deflate',
        'accept-language':'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'
    }
    return req

def resolver1_episodes(url):
    try:
        link = ''
        params = ''
        if url.startswith('resolver1_episodes='):
            #xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 1: [COLOR gold]Habilitado para filmes apenas[/COLOR][/B]')
            #return 'stop',''
            link = url.split('resolver1_episodes=')[1]
            params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x31\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x65\x70\x69\x73\x6f\x64\x65\x73\x3d\x25\x73\x27\x7d'%urllib.quote(link).replace('%23','#')
        else:
            link = url.split('resolver1_mv=')[1]
            params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x31\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x6d\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%urllib.quote(link)
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Resolver 1 - Código: 404[/COLOR][/B]')
            return 'stop',''
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        sub = ''
        if html == 'API Under Maintenance':
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 1: [COLOR gold]API em manutenção[/COLOR][/B]')
            return 'stop'
        if html == 'episode not found!':
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 1: [COLOR gold]Episódio não encontrado![/COLOR][/B]')
            return 'stop',''
        stream = base64.b64decode(html.encode('utf-8')).decode('utf-8')
        if '#' in stream:
            stream,sub = stream.split('#')
            sub = sub + '\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73'%useragent
        if not valide_v2(stream.split('|')[0]):
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 1: [COLOR gold]Conteúdo offline![/COLOR][/B]')
            return 'stop',''
        return stream,sub
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Resolver 1 - Código: 404[/COLOR][/B]')
        return '',''

def resolver2_episodes(url):
    try:
        #xbmcgui.Dialog().ok('Aviso:', '[B]Servidor em manutenção.[CR][COLOR gold]Não há previsão para retorno dessa opção.[/COLOR][/B]')
        #return 'stop'
        link = ''
        params = ''
        if url.startswith('resolver2_episodes='):
            link = url.split('resolver2_episodes=')[1]
            params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x32\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x65\x70\x69\x73\x6f\x64\x65\x73\x3d\x25\x73\x27\x7d'%urllib.quote(link).replace('%23','#')
        else:
            link = url.split('resolver2_mv=')[1]
            params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x32\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x6d\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%urllib.quote(link)
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Resolver 2 - Código: 404[/COLOR][/B]')
            return 'stop'
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        if html == 'API Under Maintenance':
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 2: [COLOR gold]API em manutenção[/COLOR][/B]')
            return 'stop'
        if html == 'episode not found!':
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 2: [COLOR gold]Episódio não encontrado![/COLOR][/B]')
            return 'stop'
        stream = base64.b64decode(html.encode('utf-8')).decode('utf-8')
        if not valide_v2(stream.split('|')[0]):
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 2: [COLOR gold]Conteúdo offline![/COLOR][/B]')
            return 'stop',''
        return stream
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Resolver 2 - Código: 404[/COLOR][/B]')
        return ''

def resolver3_episodes(url):
    try:
        link = ''
        params = ''
        if url.startswith('resolver3_episodes='):
            link = url.split('resolver3_episodes=')[1]
            params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x33\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x65\x70\x69\x73\x6f\x64\x65\x73\x3d\x25\x73\x27\x7d'%urllib.quote(link).replace('%23','#')
        else:
            link = url.split('resolver3_mv=')[1]
            params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x33\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x6d\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%urllib.quote(link)
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Resolver 3 - Código: 404[/COLOR][/B]')
            return 'stop'
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        if html == 'API Under Maintenance':
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 3: [COLOR gold]API em manutenção[/COLOR][/B]')
            return 'stop'
        if html == 'episode not found!':
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 3: [COLOR gold]Episódio não encontrado![/COLOR][/B]')
            return 'stop'
        stream = base64.b64decode(html.encode('utf-8')).decode('utf-8')
        if not valide_v2(stream, get_mode=True):
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 3: [COLOR gold]Conteúdo offline![/COLOR][/B]')
            return 'stop'
        return stream
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Resolver 3 - Código: 404[/COLOR][/B]')
        return ''

def resolver4_episodes(url):
    try:
        link = ''
        params = ''
        if url.startswith('resolver4_episodes='):
            link = url.split('resolver4_episodes=')[1]
            params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x34\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x65\x70\x69\x73\x6f\x64\x65\x73\x3d\x25\x73\x27\x7d'%urllib.quote(link).replace('%23','#')
        else:
            link = url.split('resolver4_mv=')[1]
            params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x34\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x6d\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%urllib.quote(link)
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Resolver 4 - Código: 404[/COLOR][/B]')
            return 'stop'
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        if html == 'API Under Maintenance':
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 4: [COLOR gold]API em manutenção[/COLOR][/B]')
            return 'stop'
        if html == 'episode not found!':
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 4: [COLOR gold]Episódio não encontrado![/COLOR][/B]')
            return 'stop'
        html = base64.b64decode(html.encode('utf-8')).decode('utf-8')
        res,useragent = html.split('|')
        if '\x3c\x70\x3e\x56\x69\x64\x65\x6f\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x2e\x3c\x2f\x70\x3e' in res:
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 4: [COLOR gold]Episódio não encontrado![/COLOR][/B]')
            return 'stop'
        host = urlparse(res).netloc
        referer = res
        headers = {
            'Sec-Fetch-Dest':'iframe',
            'Sec-Fetch-Mode':'navigate',
            'Sec-Fetch-Site':'cross-site',
            'Sec-Fetch-Storage-Access': 'active',
            'Sec-GPC':'1'
        }
        res = getMovieData(res, referer='\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x65\x6e\x6f\x76\x61\x74\x65\x63\x70\x6c\x75\x73\x2e\x63\x6f\x6d\x2f', append_headers=headers)
        # Regex para capturar o atributo src dentro da tag iframe
        pattern = '\x3c\x69\x66\x72\x61\x6d\x65\x5b\x5e\x3e\x5d\x2b\x73\x72\x63\x3d\x22\x28\x5b\x5e\x22\x5d\x2b\x29\x22'
        match = re.search(pattern, res)
        if match:
            player = match.group(1)
            headers.update({
                'Sec-Fetch-Site':'same-origin',
                'Sec-Fetch-Storage-Access': 'none'
            })
            headers.pop('Sec-GPC')
            response = getMovieData(player, referer=referer, append_headers=headers)
            # Regex para capturar URLs que terminam em .m3u8
            pattern = '\x68\x74\x74\x70\x73\x3f\x3a\x2f\x2f\x5b\x5e\x5c\x73\x22\x5d\x2b\x5c\x2e\x28\x3f\x3a\x6d\x33\x75\x38\x7c\x6d\x70\x34\x29\x5b\x5e\x5c\x73\x22\x5d\x2a'
            matches = re.findall(pattern, response)
            for url in matches:
                url = url.replace(r"\u0026", "&").replace('\\', '')
                refer = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x65\x6d\x62\x65\x64\x73\x2e\x63\x6f\x6d'
                if not valide_v2(url, referer=refer + '/', origin=refer, get_mode=True):
                    xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 4: [COLOR gold]Conteúdo offline![/COLOR][/B]')
                    return 'stop'
                return '{}|User-Agent={}&Referer={}&Origin={}'.format(url, useragent, refer + '/', refer)
        if '\x3c\x70\x3e\x56\x69\x64\x65\x6f\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x2e\x3c\x2f\x70\x3e' in res or 'Vídeo não encontrado' in res or 'Página não encontrada' in res:
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 4: [COLOR gold]Episódio não encontrado![/COLOR][/B]')
            return 'stop'
        res = helpers.get_packed_data(res).replace("'",'"')
        data = re.findall('\x46\x69\x72\x65\x50\x6c\x61\x79\x65\x72\x5c\x28\x22\x28\x2e\x2a\x3f\x29\x22',res)[0]
        params = {'\x68\x61\x73\x68':data,'\x72':''}
        res = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x2f\x70\x6c\x61\x79\x65\x72\x2f\x69\x6e\x64\x65\x78\x2e\x70\x68\x70\x3f\x64\x61\x74\x61\x3d\x25\x73\x26\x64\x6f\x3d\x67\x65\x74\x56\x69\x64\x65\x6f'%(host,data), origin='https://%s'%host, referer='https://%s'%host, post=params, replace_headers={'X-Requested-With':'XMLHttpRequest'}).replace("'",'"')
        stream = json.loads(res).get('\x73\x65\x63\x75\x72\x65\x64\x4c\x69\x6e\x6b')
        if not valide_v2(stream):
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 4: [COLOR gold]Conteúdo offline![/COLOR][/B]')
            return 'stop'
        return stream
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Resolver 4 - Código: 404[/COLOR][/B]')
        return ''

def chresolver1(url):
    try:
        link = url.split('chresolver1=')[1]
        params = '\x7b\x27\x63\x68\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x31\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x25\x73\x27\x7d'%link
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params))
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        html = base64.b64decode(html.encode('utf-8')).decode('utf-8')
        return html + '|User-Agent=%s'%useragent
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]CHResolver 1 - Código: 404[/COLOR][/B]')
        return ''

def chresolver2(url):
    try:
        xbmcgui.Dialog().ok('Aviso: Este servidor está fora do ar', '[B][COLOR gold]Remova e adicione aos favoritos novamente se quiser atualizar os links.[/COLOR][/B]')
        return 'stop'
        import json
        ch,chid = url.split('chresolver2=')[1].split('#')
        # get_id
        res = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70\x2f\x74\x76\x2f\x25\x73'%ch)
        if not '\x6c\x65\x74\x20\x76\x69\x64\x65\x6f\x5f\x69\x64' in res:
            res = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70\x2f\x74\x76\x2f\x25\x73'%ch)
        if re.findall('\x6c\x65\x74\x20\x76\x69\x64\x65\x6f\x5f\x69\x64\x20\x3d\x20\x28\x2e\x2a\x3f\x29\x3b',res):
            chid = re.findall('\x6c\x65\x74\x20\x76\x69\x64\x65\x6f\x5f\x69\x64\x20\x3d\x20\x28\x2e\x2a\x3f\x29\x3b',res)[0]
        params = {'\x61\x63\x74\x69\x6f\x6e':'\x67\x65\x74\x50\x6c\x61\x79\x65\x72','\x63\x6c\x69\x65\x6e\x74\x5f\x69\x70':getIP(),'\x76\x69\x64\x65\x6f\x5f\x69\x64':chid}
        # get_id
        res = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70\x2f\x61\x70\x69','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70\x2f\x74\x76\x2f\x25\x73'%ch,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70',post=params)
        if not '\x76\x69\x64\x65\x6f\x5f\x75\x72\x6c' in res:
            res = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70\x2f\x61\x70\x69','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70\x2f\x74\x76\x2f\x25\x73'%ch,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70',post=params)
        if not '\x76\x69\x64\x65\x6f\x5f\x75\x72\x6c' in res:
            checker_host = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6e\x65\x77\x2e\x6d\x33\x75\x38\x2e\x6f\x6e\x65\x2f\x25\x73\x2f\x69\x6e\x64\x65\x78\x2e\x6d\x33\x75\x38'%ch.replace('-','')
            if valide_v2(checker_host,urllib.unquote_plus('\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30'),urllib.unquote_plus('\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30\x25\x32\x46')):
                return checker_host + '|User-Agent=%s&Origin=%s&Referer=%s'%(useragent,'\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30','\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30\x25\x32\x46')
        if '\x35\x32\x30\x3a\x20\x57\x65\x62\x20\x73\x65\x72\x76\x65\x72\x20\x69\x73\x20\x72\x65\x74\x75\x72\x6e\x69\x6e\x67\x20\x61\x6e\x20\x75\x6e\x6b\x6e\x6f\x77\x6e\x20\x65\x72\x72\x6f\x72' in res:
            xbmcgui.Dialog().ok('Aviso:', '[B]Servidor em manutenção.[CR][COLOR gold]Não há previsão para retorno dessa opção.[/COLOR][/B]')
            return 'stop'
        data = json.loads(res).get('\x64\x61\x74\x61')
        host = data.get('\x76\x69\x64\x65\x6f\x5f\x75\x72\x6c')
        if '\x63\x61\x6e\x61\x6c\x2f\x61\x6c\x74\x2e\x70\x68\x70' in host:
            res = getMovieData(host,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x66\x6c\x69\x78\x2e\x74\x6f\x70\x2f\x74\x76\x2f\x25\x73'%ch,getrequest=True)
            return '%s'%str(res.url) + '|User-Agent=%s&Origin=%s&Referer=%s'%(useragent,'\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30','\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30\x25\x32\x46')
        signature = ''
        for key,msg in data.items():
            if '\x73\x69\x67\x6e' in key or '\x75\x72\x6c\x5f\x73' in key:
                signature = msg
                break
        if signature:
            if not valide_v2('\x25\x73\x3f\x77\x6d\x73\x41\x75\x74\x68\x53\x69\x67\x6e\x3d\x25\x73'%(host,signature),urllib.unquote_plus('\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30'),urllib.unquote_plus('\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30\x25\x32\x46')):
                xbmcgui.Dialog().ok('Aviso:', '[B]Ops - Parece que o servidor está em manutenção.[CR][COLOR gold]Não temos previsão para retorno.[/COLOR][/B]')
                return 'stop'
            return '\x25\x73\x3f\x77\x6d\x73\x41\x75\x74\x68\x53\x69\x67\x6e\x3d\x25\x73'%(host,signature) + '|User-Agent=%s&Origin=%s&Referer=%s'%(useragent,'\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30','\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30\x25\x32\x46')
        if not valide_v2('%s'%host,urllib.unquote_plus('\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30'),urllib.unquote_plus('\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30\x25\x32\x46')):
            xbmcgui.Dialog().ok('Aviso:', '[B]Ops - Parece que o servidor está em manutenção.[CR][COLOR gold]Não temos previsão para retorno.[/COLOR][/B]')
            return 'stop'
        return '%s'%host + '|User-Agent=%s&Origin=%s&Referer=%s'%(useragent,'\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30','\x25\x36\x38\x25\x37\x34\x25\x37\x34\x25\x37\x30\x25\x37\x33\x25\x33\x41\x25\x32\x46\x25\x32\x46\x25\x36\x35\x25\x36\x44\x25\x36\x32\x25\x36\x35\x25\x36\x34\x25\x36\x36\x25\x36\x43\x25\x36\x39\x25\x37\x38\x25\x32\x45\x25\x37\x34\x25\x36\x46\x25\x37\x30\x25\x32\x46')
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Canal indisponível - [CR][COLOR gold]Tente novamente mais tarde.[/COLOR][/B]')
        return ''

def novelas_resolver(episode):
    try:
        url = getMovieData(episode,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6e\x6f\x76\x65\x66\x78\x2e\x62\x69\x7a\x2f')
        if '\x70\x6c\x61\x79\x65\x72\x2e\x73\x6f\x75\x72\x63\x65\x20\x3d\x20\x7b' in url:
            episode = re.compile('\x73\x6f\x75\x72\x63\x65\x73\x3a\x20\x5c\x5b\x7b\x20\x73\x72\x63\x3a\x20\x27\x28\x2e\x2b\x3f\x29\x27',re.DOTALL|re.MULTILINE).findall(url)[0]
            refer = episode + '&verifypeer=false'
            return episode + '|User-Agent=%s&Referer=%s'%(useragent,refer)
        decode = re.compile('(eval\(.+?)</script>',re.DOTALL|re.MULTILINE).findall(url)[0]
        import jsunpack
        decoded = jsunpack.unpack(decode)
        decoded = decoded.replace("'",'"')
        episode = re.compile('sources:(\[.+?}\])',re.DOTALL|re.MULTILINE).findall(decoded)[0]
        try:
            episode = json.loads(episode)[1].get('file')
        except:
            episode = json.loads(episode)[0].get('file')
        refer = episode + '&verifypeer=false'
        episode = episode + '|User-Agent=%s&Referer=%s'%(useragent,refer)
        return episode
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        exit()
        return ''

def askflix(episode):
    try:
        import json
        html = getMovieData(episode).replace("'",'"')
        if not re.findall('\x3c\x6c\x69\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x74\x79\x70\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x70\x6f\x73\x74\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x6e\x75\x6d\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x22\x74\x69\x74\x6c\x65\x22\x3e\x28\x2e\x2b\x3f\x29\x3c',html,re.MULTILINE|re.DOTALL):
            html = custom_proxy(episode)
        if '<h1>Página não encontrada</h1>' in html:
            xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![/B]")
            return 'stop'
        players = re.compile('\x3c\x6c\x69\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x74\x79\x70\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x70\x6f\x73\x74\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x6e\x75\x6d\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x22\x74\x69\x74\x6c\x65\x22\x3e\x28\x2e\x2b\x3f\x29\x3c',re.MULTILINE|re.DOTALL).findall(html)
        data_type, data_post, data_nume, data_name = players[0]
        params = {'action': 'doo_player_ajax', 'post': data_post, 'nume': data_nume, 'type': data_type}
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x61\x73\x6b\x66\x6c\x69\x78\x2e\x62\x69\x7a\x2f\x77\x70\x2d\x61\x64\x6d\x69\x6e\x2f\x61\x64\x6d\x69\x6e\x2d\x61\x6a\x61\x78\x2e\x70\x68\x70', post=params)
        if not '{' in html and not 'embed_url' in html:
            html = custom_proxy('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x61\x73\x6b\x66\x6c\x69\x78\x2e\x62\x69\x7a\x2f\x77\x70\x2d\x61\x64\x6d\x69\x6e\x2f\x61\x64\x6d\x69\x6e\x2d\x61\x6a\x61\x78\x2e\x70\x68\x70', post=params)
        player = json.loads(html).get('embed_url')
        html = getMovieData(player)
        if '<title>404 Página não encontrada</title>' in html:
            xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![/B]")
            return 'stop'
        data_id, data_hash = re.compile('\x64\x61\x74\x61\x2d\x69\x64\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x68\x61\x73\x68\x3d\x22\x28\x2e\x2a\x3f\x29\x22', re.MULTILINE).findall(html)[0]
        params = {'action': 'getPlayer', 'data_id': data_id, 'data_hash': data_hash}
        host = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73'%urlparse(player).netloc
        html = getMovieData('%s/api'%host, player, host, post=params)
        if not '{' in html and not 'video_url' in html:
            #old '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x73\x68\x64\x2e\x6c\x69\x6e\x6b\x2f\x61\x70\x69'
            html = custom_proxy('%s/api'%host, player, host, post=params)
        import json
        player_ = json.loads(html).get('data').get('video_url')
        html = getMovieData(player_, player)
        if not '\x44\x69\x76\x4c\x69\x6e\x6b\x43\x6f\x6e\x76\x65\x72\x74\x65\x72' in html and not re.findall('\x28\x65\x76\x61\x6c\x5c\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e',html):
            html = custom_proxy(player_, player)
        if '\x44\x69\x76\x4c\x69\x6e\x6b\x43\x6f\x6e\x76\x65\x72\x74\x65\x72' in html:
            player__ = re.compile('\x44\x69\x76\x4c\x69\x6e\x6b\x43\x6f\x6e\x76\x65\x72\x74\x65\x72\x2e\x2b\x3f\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x22',re.DOTALL|re.MULTILINE).findall(html)[0]
            html = getMovieData(player__, player_)
            if '\x3c\x74\x69\x74\x6c\x65\x3e\x41\x63\x63\x6f\x75\x6e\x74\x20\x53\x75\x73\x70\x65\x6e\x64\x65\x64\x3c\x2f\x74\x69\x74\x6c\x65\x3e' in html:
                xbmcgui.Dialog().ok("Aviso:", "[B]Aguarde uma correção - use outra opção.[CR][COLOR gold]Link removido por direitos autorais.[/COLOR][/B]")
                return 'stop'
            #getplayer_redirects_1
            action_1,value = re.compile('\x61\x63\x74\x69\x6f\x6e\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x2e\x2b\x3f\x76\x61\x6c\x75\x65\x3d\x22\x28\x2e\x2a\x3f\x29\x22',re.DOTALL|re.MULTILINE).findall(html)[0]
            html = getMovieData(action_1, action_1, post={'token': value})
            #getplayer_redirects_2
            action_2,value = re.compile('\x61\x63\x74\x69\x6f\x6e\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x2e\x2b\x3f\x76\x61\x6c\x75\x65\x3d\x22\x28\x2e\x2a\x3f\x29\x22',re.DOTALL|re.MULTILINE).findall(html)[0]
            html,cookies = CloudRequest(action_2, action_1, post={'token': value}, CloudInfo=True)
            #getplayer_redirects_3
            action_3,value = re.compile('\x61\x63\x74\x69\x6f\x6e\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x2e\x2b\x3f\x76\x61\x6c\x75\x65\x3d\x22\x28\x2e\x2a\x3f\x29\x22',re.DOTALL|re.MULTILINE).findall(html)[0]
            html = CloudRequest(action_3, action_2, CloudIP=cookies, post={'token': value})
            ###
            player = re.compile('\x63\x6f\x6e\x74\x65\x75\x64\x6f\x22\x3e\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2a\x3f\x29\x22',re.DOTALL|re.MULTILINE).findall(html)[0]
            html = CloudRequest(player, action_3, CloudIP=cookies)
        html = helpers.get_hunter_data(html)
        decoded = helpers.get_packed_data(html).replace("'",'"')
        player = re.compile('\x72\x65\x74\x75\x72\x6e\x22\x28\x2e\x2b\x3f\x29\x22',re.DOTALL|re.MULTILINE).findall(decoded)[0]
        html,cookies = CloudRequest(player, CloudInfo=True)
        if helpers.get_hunter_data(html):
            html = helpers.get_hunter_data(html)
        if helpers.get_packed_data(html):
            html = helpers.get_packed_data(html)
        html = html.replace("'",'"')
        if '\x3c\x70\x3e\x56\x69\x64\x65\x6f\x20\x6e\x6f\x74\x20\x66\x6f\x75\x6e\x64\x2e\x3c\x2f\x70\x3e' in html:
            xbmcgui.Dialog().ok("Aviso:", "[B]Capítulo não encontrado![CR][COLOR gold]Siga para o próximo capítulo.[/COLOR][/B]")
            return 'stop'
        stream,server = '',''
        if re.findall('\x76\x69\x64\x65\x6f\x55\x72\x6c\x3a\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x76\x69\x64\x65\x6f\x53\x65\x72\x76\x65\x72\x3a\x22\x28\x2e\x2a\x3f\x29\x22',html):
            stream,server = re.findall('\x76\x69\x64\x65\x6f\x55\x72\x6c\x3a\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x76\x69\x64\x65\x6f\x53\x65\x72\x76\x65\x72\x3a\x22\x28\x2e\x2a\x3f\x29\x22',html)[0]
            stream = stream.replace('\/','/')
            host = urlparse(player).netloc
            return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x25\x73\x3f\x73\x3d\x25\x73\x26\x64\x3d\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73\x26\x52\x65\x66\x65\x72\x65\x72\x3d\x25\x73'%(host,stream,server,useragent,player)
        elif re.findall('\x22\x76\x69\x64\x65\x6f\x55\x72\x6c\x22\x3a\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x22\x76\x69\x64\x65\x6f\x53\x65\x72\x76\x65\x72\x22\x3a\x22\x28\x2e\x2a\x3f\x29\x22',html):
            stream,server = re.findall('\x22\x76\x69\x64\x65\x6f\x55\x72\x6c\x22\x3a\x22\x28\x2e\x2a\x3f\x29\x22\x2c\x22\x76\x69\x64\x65\x6f\x53\x65\x72\x76\x65\x72\x22\x3a\x22\x28\x2e\x2a\x3f\x29\x22',html)[0]
            stream = stream.replace('\/','/')
            host = urlparse(player).netloc
            return '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x25\x73\x3f\x73\x3d\x25\x73\x26\x64\x3d\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x25\x73\x26\x52\x65\x66\x65\x72\x65\x72\x3d\x25\x73'%(host,stream,server,useragent,player)
        elif re.findall('\x68\x6f\x73\x74\x4c\x69\x73\x74\x3a\x7b\x31\x3a\x5c\x5b\x22\x28\x2e\x2a\x3f\x29\x22\x5c\x5d\x2e\x2b\x3f\x76\x69\x64\x65\x6f\x55\x72\x6c\x3a\x22\x28\x2e\x2a\x3f\x29\x22',html):
            server,stream = re.findall('\x68\x6f\x73\x74\x4c\x69\x73\x74\x3a\x7b\x31\x3a\x5c\x5b\x22\x28\x2e\x2a\x3f\x29\x22\x5c\x5d\x2e\x2b\x3f\x76\x69\x64\x65\x6f\x55\x72\x6c\x3a\x22\x28\x2e\x2a\x3f\x29\x22',html)[0]
            host = urlparse(player).netloc
            headers = {'Referer':player,'User-Agent':useragent}
            html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x25\x73\x3f\x73\x3d\x31\x26\x64\x3d'%(host,stream),replace_headers=headers)
            link = re.compile('RESOLUTION=.*x(.*)\n(.*)',re.MULTILINE|re.IGNORECASE).findall(html)[0][1]
            html = getMovieData(link,replace_headers=headers)
            html = html.replace('https://','http://127.0.0.1:55333/?url=https://')
            html = html.replace('.jpg','.jpg&Referer=%s&User-Agent=%s'%(urllib.quote_plus(player),urllib.quote_plus(useragent)))
            #Fim
            py = os.path.join(home, "PlaylistTemp.m3u8")
            file = open(py, "w", encoding="utf-8")
            file.write(str(html))
            file.close()
            if six.PY3: return home + 'PlaylistTemp.m3u8'
            if six.PY2: return home + '\PlaylistTemp.m3u8'
        return ''
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        return ''

def desenhos_resolver(url):
    try:
        base = getMovieData(url+'\x3f\x6c\x69\x62\x65\x72\x61\x64\x6f\x3d\x74\x72\x75\x65').replace("'",'"')
        base = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x70\x6f\x73\x74\x2d\x76\x69\x64\x65\x6f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x73\x70\x61\x6e\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        video = re.compile('\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        if '\x62\x6c\x6f\x67\x67\x65\x72' in video or '\x74\x75\x64\x6f\x67\x6f\x73\x74\x6f\x73\x6f' in video:
            html = getMovieData(video)
            if '\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x65\x72\x72\x6f\x72\x4d\x65\x73\x73\x61\x67\x65\x22\x3e' in html:
                video = re.compile('\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[1]
                return video + '|User-Agent=' + useragent + '&Referer=' + video
            player_iframe = re.compile('\x70\x6c\x61\x79\x5f\x75\x72\x6c\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22\x2c\x22\x66\x6f\x72\x6d\x61\x74\x5f\x69\x64\x22\x3a\x28\x2e\x2b\x3f\x29\x7d', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
            for play, quality in player_iframe:
                if quality == '22':
                    play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                    return play + '|User-Agent=' + useragent + '&Referer=' + play
            for play, quality in player_iframe:
                if quality == '18':
                    play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                    return play + '|User-Agent=' + useragent + '&Referer=' + play
        else:
            video = re.compile('src="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[1]
            return video + '|User-Agent=' + useragent + '&Referer=' + video
    except:
        return ''

def desenhos2_resolver(url):
    try:
        cookies = {'\x5f\x5f\x64\x64\x67\x69\x64\x5f':'\x72\x41\x63\x62\x33\x68\x32\x6b\x66\x70\x41\x73\x45\x58\x72\x68',
                '\x5f\x5f\x64\x64\x67\x32\x5f':'\x65\x59\x38\x4c\x52\x4f\x30\x59\x66\x4a\x34\x34\x4d\x56\x55\x31',
                '\x5f\x5f\x64\x64\x67\x31\x5f':'\x50\x68\x73\x4c\x35\x37\x72\x58\x50\x57\x6a\x59\x53\x4c\x65\x49\x56\x50\x35\x31'
        }
        base = getMovieData(url,cookies=cookies)
        try:
            video = re.compile('\x3c\x69\x66\x72\x61\x6d\x65\x2e\x2b\x3f\x64\x61\x74\x61\x2d\x6c\x61\x7a\x79\x2d\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        except:
            video = re.compile('<video src="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
            return video + '|User-Agent=' + useragent + '&Referer=' + url
        if '\x62\x6c\x6f\x67\x67\x65\x72' in video or '\x74\x75\x64\x6f\x67\x6f\x73\x74\x6f\x73\x6f' in video:
            html = getMovieData(video)
            if '\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x65\x72\x72\x6f\x72\x4d\x65\x73\x73\x61\x67\x65\x22\x3e' in html:
                video = re.compile('\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[1]
                return video + '|User-Agent=' + useragent + '&Referer=' + video
            player_iframe = re.compile('\x70\x6c\x61\x79\x5f\x75\x72\x6c\x2e\x2b\x3f\x22\x28\x2e\x2b\x3f\x29\x22\x2c\x22\x66\x6f\x72\x6d\x61\x74\x5f\x69\x64\x22\x3a\x28\x2e\x2b\x3f\x29\x7d', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
            for play, quality in player_iframe:
                if quality == '22':
                    play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                    return play + '|User-Agent=' + useragent + '&Referer=' + play
            for play, quality in player_iframe:
                if quality == '18':
                    play = play.encode('utf-8').decode('\x75\x6e\x69\x63\x6f\x64\x65\x5f\x65\x73\x63\x61\x70\x65')
                    return play + '|User-Agent=' + useragent + '&Referer=' + play
        else:
            video = re.compile('<iframe.+?data-lazy-src="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
            video = video.replace('&#038;','&').replace('&#038;','&')
            base = getMovieData(video,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x61\x6e\x69\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x70\x2e\x63\x6f\x6d\x2f',cookies=cookies)
            decode = re.compile('\x28\x65\x76\x61\x6c\x5c\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x63\x72\x69\x70\x74\x3e',re.DOTALL|re.MULTILINE).findall(base)[0]
            import jsunpack
            decoded = jsunpack.unpack(decode)
            decoded = decoded.replace("'",'"')
            video = re.compile('"file":"(.+?)"',re.DOTALL|re.MULTILINE).findall(decoded)[0]
            return video + '|User-Agent=' + useragent + '&Referer=' + video
    except:
        return ''

def getIP():
    try:
        import json,ast
        checker = ['\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x70\x76\x34\x2e\x73\x65\x65\x69\x70\x2e\x6f\x72\x67\x2f\x6a\x73\x6f\x6e\x69\x70','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x70\x76\x34\x2e\x6a\x73\x6f\x6e\x69\x70\x2e\x63\x6f\x6d\x2f','\x68\x74\x74\x70\x3a\x2f\x2f\x61\x70\x69\x2e\x69\x70\x69\x66\x79\x2e\x6f\x72\x67\x2f\x3f\x66\x6f\x72\x6d\x61\x74\x3d\x6a\x73\x6f\x6e']
        for site in checker:
            my_ip = ast.literal_eval(getMovieData(site))
            if my_ip.get('ip'):
                return my_ip.get('ip')
        return ''
    except:
        return ''

def hub_resolver(channel):
    try:
        html = getMovieData(channel)
        if '\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x67\x65\x6f\x42\x6c\x6f\x63\x6b\x65\x64\x22\x3e' in html:
            return 'notavailable'
        if '\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x72\x65\x6d\x6f\x76\x65\x64\x22\x3e' in html or '\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x72\x65\x6d\x6f\x76\x65\x64\x56\x69\x64\x65\x6f\x43\x6f\x6e\x74\x65\x6e\x74\x22\x3e' in html:
            return 'removed'
        if '<title>Página não encontrada 404' in html:
            return 'notavailable'
        sources = []
        qvars = re.search(r'qualityItems_[^\[]+([^;]+)', html)
        if qvars:
            sources = json.loads(qvars.group(1))
            sources = [(src.get('text'), src.get('url')) for src in sources if src.get('url')]
        if not sources:
            sections = re.findall(r'(var\sra[a-z0-9]+=.+?);flash', html)
            for section in sections:
                pvars = re.findall(r'var\s(ra[a-z0-9]+)=([^;]+)', section)
                link = re.findall(r'var\smedia_\d+=([^;]+)', section)[0]
                link = re.sub(r"/\*.+?\*/", '', link)
                for key, value in pvars:
                    link = re.sub(key, value, link)
                link = link.replace('"', '').split('+')
                link = [i.strip() for i in link]
                link = ''.join(link)
                if 'urlset' not in link:
                    r = re.findall(r'(\d+p)', link, re.I)
                    if r:
                        sources.append((r[0], link))
        if not sources:
            fvars = re.search(r'flashvars_\d+\s*=\s*(.+?});\s', html)
            if fvars:
                sources = json.loads(fvars.group(1)).get('mediaDefinitions')
                sources = [(src.get('quality'), src.get('videoUrl')) for src in sources if
                           type(src.get('quality')) is not list and src.get('videoUrl')]
        if sources:
            return sources[0][1] + '|User-Agent=' + urllib.quote_plus(useragent)
        return ''
    except:
        xbmcgui.Dialog().ok(addon_name, "[B]Falha ao resolver ou indisponível no momento.[/B]")
        return ''

def online(counter,url):
    try:
        opener = urllib2.build_opener()
        opener.addheaders=[('Accept-Language', 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'),('User-Agent', useragent),('Accept', 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'), ('Referer', 'VXVULGO PLAY Matrix - '+addon_version)]
        data = opener.open('https://whos.amung.us/pingjs/?k=brplay'+url).read()
        count = re.compile("'(.+?)'").findall(str(data))[0]
    except:
        pass
    if int(count) > int(counter):
        xbmcgui.Dialog().ok(addon_name, "[B][COLOR white]Lista com o máximo de pessoas![/COLOR][CR]Total: [COLOR gold]"+count+"[/COLOR][/B]")
        exit()

def InstallPlugin():
    inputstreams = ['inputstream.ffmpegdirect', 'inputstream.adaptive']
    for inputstream in inputstreams:
        try:
            inputstream = translate('special://home/addons/%s'%inputstream)
            if os.path.exists(inputstream)==False:
                xbmc.executebuiltin('InstallAddon(%s)'%inputstream)
                xbmc.executebuiltin('SendClick(11)')
        except:
            pass

def check_player():
    try:
        player_file = '\x50\x48\x42\x73\x59\x58\x6c\x6c\x63\x6d\x4e\x76\x63\x6d\x56\x6d\x59\x57\x4e\x30\x62\x33\x4a\x35\x50\x67\x6f\x67\x49\x43\x41\x67\x50\x48\x42\x73\x59\x58\x6c\x6c\x63\x6e\x4d\x2b\x43\x69\x41\x67\x49\x43\x41\x67\x49\x43\x41\x67\x50\x48\x42\x73\x59\x58\x6c\x6c\x63\x69\x42\x75\x59\x57\x31\x6c\x50\x53\x4a\x4e\x57\x46\x42\x73\x59\x58\x6c\x6c\x63\x69\x49\x67\x59\x58\x56\x6b\x61\x57\x38\x39\x49\x6d\x5a\x68\x62\x48\x4e\x6c\x49\x69\x42\x30\x65\x58\x42\x6c\x50\x53\x4a\x46\x65\x48\x52\x6c\x63\x6d\x35\x68\x62\x46\x42\x73\x59\x58\x6c\x6c\x63\x69\x49\x67\x64\x6d\x6c\x6b\x5a\x57\x38\x39\x49\x6e\x52\x79\x64\x57\x55\x69\x50\x67\x6f\x67\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x38\x5a\x6d\x6c\x73\x5a\x57\x35\x68\x62\x57\x55\x2b\x63\x47\x78\x68\x65\x57\x56\x79\x58\x32\x6c\x6b\x50\x43\x39\x6d\x61\x57\x78\x6c\x62\x6d\x46\x74\x5a\x54\x34\x4b\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x67\x50\x47\x68\x70\x5a\x47\x56\x34\x59\x6d\x31\x6a\x50\x6e\x52\x79\x64\x57\x55\x38\x4c\x32\x68\x70\x5a\x47\x56\x34\x59\x6d\x31\x6a\x50\x67\x6f\x67\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x38\x63\x47\x78\x68\x65\x57\x4e\x76\x64\x57\x35\x30\x62\x57\x6c\x75\x61\x57\x31\x31\x62\x58\x52\x70\x62\x57\x55\x2b\x4d\x54\x49\x77\x50\x43\x39\x77\x62\x47\x46\x35\x59\x32\x39\x31\x62\x6e\x52\x74\x61\x57\x35\x70\x62\x58\x56\x74\x64\x47\x6c\x74\x5a\x54\x34\x4b\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x38\x4c\x33\x42\x73\x59\x58\x6c\x6c\x63\x6a\x34\x4b\x49\x43\x41\x67\x49\x44\x77\x76\x63\x47\x78\x68\x65\x57\x56\x79\x63\x7a\x34\x4b\x49\x43\x41\x67\x49\x44\x78\x79\x64\x57\x78\x6c\x63\x79\x42\x68\x59\x33\x52\x70\x62\x32\x34\x39\x49\x6e\x42\x79\x5a\x58\x42\x6c\x62\x6d\x51\x69\x50\x67\x6f\x67\x49\x43\x41\x67\x49\x43\x41\x67\x49\x44\x78\x79\x64\x57\x78\x6c\x49\x48\x42\x73\x59\x58\x6c\x6c\x63\x6a\x30\x69\x54\x56\x68\x51\x62\x47\x46\x35\x5a\x58\x49\x69\x49\x48\x42\x79\x62\x33\x52\x76\x59\x32\x39\x73\x63\x7a\x30\x69\x63\x32\x31\x69\x49\x69\x38\x2b\x43\x69\x41\x67\x49\x43\x41\x67\x49\x43\x41\x67\x50\x48\x4a\x31\x62\x47\x55\x67\x5a\x48\x5a\x6b\x61\x57\x31\x68\x5a\x32\x55\x39\x49\x6e\x52\x79\x64\x57\x55\x69\x49\x48\x42\x73\x59\x58\x6c\x6c\x63\x6a\x30\x69\x54\x56\x68\x51\x62\x47\x46\x35\x5a\x58\x49\x69\x4c\x7a\x34\x4b\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x38\x63\x6e\x56\x73\x5a\x53\x42\x77\x62\x47\x46\x35\x5a\x58\x49\x39\x49\x6b\x31\x59\x55\x47\x78\x68\x65\x57\x56\x79\x49\x69\x42\x77\x63\x6d\x39\x30\x62\x32\x4e\x76\x62\x48\x4d\x39\x49\x6e\x4a\x30\x62\x58\x41\x69\x4c\x7a\x34\x4b\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x38\x63\x6e\x56\x73\x5a\x53\x42\x77\x62\x47\x46\x35\x5a\x58\x49\x39\x49\x6b\x31\x59\x55\x47\x78\x68\x65\x57\x56\x79\x49\x69\x42\x77\x63\x6d\x39\x30\x62\x32\x4e\x76\x62\x48\x4d\x39\x49\x6e\x4a\x30\x63\x33\x41\x69\x4c\x7a\x34\x4b\x49\x43\x41\x67\x49\x43\x41\x67\x49\x43\x41\x38\x63\x6e\x56\x73\x5a\x53\x42\x77\x62\x47\x46\x35\x5a\x58\x49\x39\x49\x6b\x31\x59\x55\x47\x78\x68\x65\x57\x56\x79\x49\x69\x42\x77\x63\x6d\x39\x30\x62\x32\x4e\x76\x62\x48\x4d\x39\x49\x6e\x4e\x76\x63\x43\x49\x76\x50\x67\x6f\x67\x49\x43\x41\x67\x49\x43\x41\x67\x49\x44\x78\x79\x64\x57\x78\x6c\x49\x47\x6c\x75\x64\x47\x56\x79\x62\x6d\x56\x30\x63\x33\x52\x79\x5a\x57\x46\x74\x50\x53\x4a\x30\x63\x6e\x56\x6c\x49\x69\x42\x77\x62\x47\x46\x35\x5a\x58\x49\x39\x49\x6b\x31\x59\x55\x47\x78\x68\x65\x57\x56\x79\x49\x69\x38\x2b\x43\x69\x41\x67\x49\x43\x41\x67\x49\x43\x41\x67\x50\x48\x4a\x31\x62\x47\x55\x67\x63\x47\x78\x68\x65\x57\x56\x79\x50\x53\x4a\x4e\x57\x46\x42\x73\x59\x58\x6c\x6c\x63\x69\x49\x67\x64\x6d\x6c\x6b\x5a\x57\x38\x39\x49\x6e\x52\x79\x64\x57\x55\x69\x4c\x7a\x34\x4b\x49\x43\x41\x67\x49\x44\x77\x76\x63\x6e\x56\x73\x5a\x58\x4d\x2b\x43\x6a\x77\x76\x63\x47\x78\x68\x65\x57\x56\x79\x59\x32\x39\x79\x5a\x57\x5a\x68\x59\x33\x52\x76\x63\x6e\x6b\x2b'
        player_file = base64.b64decode(player_file).decode('utf-8')
        Path = translate('special://home/userdata')
        arquivo = os.path.join(Path, "playercorefactory.xml")
        exists = os.path.isfile(arquivo)
        if xbmc.getCondVisibility('system.platform.android'):
            if int(player_opt) == 0:
                try:
                    os.remove(arquivo)
                except:
                    pass
            elif int(player_opt) == 1:
                player_file = player_file.replace('player_id','com.mxtech.videoplayer.ad')
                if exists == False:
                    py = os.path.join(Path, "playercorefactory.xml")
                    file = open(py, "w", encoding="utf-8")
                    file.write(player_file)
                    file.close()
                else:
                    try:
                        with open(arquivo, encoding='utf-8') as f:
                            content = f.read()
                            if 'com.instantbits.cast.webvideo' in content:
                                py = os.path.join(Path, "playercorefactory.xml")
                                file = open(py, "w", encoding="utf-8")
                                file.write(player_file)
                                file.close()
                    except:
                        pass
            elif int(player_opt) == 2:
                player_file = player_file.replace('player_id','com.instantbits.cast.webvideo')
                if exists == False:
                    py = os.path.join(Path, "playercorefactory.xml")
                    file = open(py, "w", encoding="utf-8")
                    file.write(player_file)
                    file.close()
                else:
                    try:
                        with open(arquivo, encoding='utf-8') as f:
                            content = f.read()
                            if 'com.mxtech.videoplayer.ad' in content:
                                py = os.path.join(Path, "playercorefactory.xml")
                                file = open(py, "w", encoding="utf-8")
                                file.write(player_file)
                                file.close()
                    except:
                        pass
        else:
            try:
                os.remove(arquivo)
            except:
                pass
    except:
        pass

def base_dns(url, proxy):
    try:
        import socket
        etc_hosts = {}
        # Custom resolver to use the etc_hosts cache
        def custom_resolver(builtin_resolver):
            def wrapper(*args, **kwargs):
                if args[:2] in etc_hosts:
                    return etc_hosts[args[:2]]
                else:
                    return builtin_resolver(*args, **kwargs)
            return wrapper
        # Override the default socket.getaddrinfo with the custom resolver
        socket.getaddrinfo = custom_resolver(socket.getaddrinfo)
        # Function to bind domain name and port to a specific IP in etc_hosts
        def _bind_ip(domain_name, port, ip):
            key = (domain_name, port)
            value = (socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, port))
            etc_hosts[key] = [value]
        # Parse port from the URL or use defaults
        parsed_url = urlparse(url)
        domain_name = parsed_url.hostname
        # Verify if the URL contains an explicit port
        if ":" in parsed_url.netloc:
            port = int(parsed_url.netloc.split(":")[1])
        else:
            port = parsed_url.port or (443 if url.startswith("https://") else 80)
        # Bind the resolved IP to the domain name and port
        _bind_ip(domain_name, port, proxy)
    except Exception as e:
        pass

def convert_to_m3u8(url):
    def basename(p):
        """Returns the final component of a pathname"""
        i = p.rfind("/") + 1
        return p[i:]
    if "|" in url:
        url = url.split("|")[0]
    elif "%7C" in url:
        url = url.split("%7C")[0]
    if (
        not ".m3u8" in url
        and not "/hl" in url
        and int(url.count("/")) > 4
        and not ".mp4" in url
        and not ".avi" in url
    ):
        parsed_url = urlparse(url)
        try:
            host_part1 = "%s://%s" % (parsed_url.scheme, parsed_url.netloc)
            host_part2 = url.split(host_part1)[1]
            url = host_part1 + "/live" + host_part2
            file = basename(url)
            if ".ts" in file:
                file_new = file.replace(".ts", ".m3u8")
                url = url.replace(file, file_new)
            else:
                url = url + ".m3u8"
        except:
            pass
    return url

def Check_M3U8(url,headers,proxy):
    for i in range(3):
        try:
            #if proxy:
            #    base_dns(url,proxy)
            s = create_retry_session()
            r = s.get(url, headers=headers, allow_redirects=False, timeout=5)
            url_proxy = r.headers['Location']
            if not '.m3u8' in url_proxy and not '/auth/' in url_proxy:
                return convert_to_m3u8(url_proxy)
        except:
            pass
    return ''

def M3U8_Proxy(url):
    try:
        url = url.split('|')[0]
        parsed_url = urlparse(url)
        if parsed_url.port and parsed_url.hostname:
            if any(c.isalpha() for c in parsed_url.hostname):
                return resolve_dns(url)
        return ''
    except:
        return ''

def M3U8_Verify(host,proxy,accounts):
    try:
        host = "%s://%s" % (urlparse(host).scheme, urlparse(host).netloc)
        link_params = '%s/player_api.php?username=%s&password=%s&type=m3u&output=m3u8'
        errors = ['"auth":0','user expire','<title>404 Not Found</title>','<h1>500 Internal Server Error</h1>', 'Line is invalid', '<title>Forbidden</title>']
        for account in accounts:
            url = link_params%(host,account.split('/')[0],account.split('/')[1])
            response = getMovieData(url, replace_headers={'User-Agent': 'XC-IPTV'})
            if response and not any(x in response for x in errors):
                return account
        return ''
    except Exception as e:
        return accounts[0]

def player_normal(name, url, iconimage, description):
    CheckUpdate()
    CheckPlugin()
    check_player()
    hls = ''
    sub = ''
    sub_off = ''
    notffmpeg = ''
    playtemp1 = ''
    playtemp2 = ''
    channel_mode = False
    is_livechannel = False
    channel_proxy = ''
    global ffmpeg_opt
    if six.PY3: playtemp1 = home + 'Playlist.m3u8'
    if six.PY3: playtemp2 = home + 'PlaylistTemp.m3u8'
    if six.PY2: playtemp1 = home + '\Playlist.m3u8'
    if six.PY2: playtemp2 = home + '\PlaylistTemp.m3u8'
    if '$$lsname=' in url:
        url = url.split('$$lsname=')[0]
    if 'ffmpeg_off' in url:
        ffmpeg_input = 'true'
        url = url.replace('?ffmpeg_off','')
    else:
        ffmpeg_input = 'false'
    if url.startswith('#movies_list='): #MOVIES
        url = url.split('#movies_list=')[1].split('|')
        total = len(url) + 1
        players = ['[B]SERVIDOR %s[/B]'%play for play in range(1,total)]
        dialog = xbmcgui.Dialog()
        index = dialog.select('ESCOLHA O SERVIDOR', players)
        if index >= 0:
            url = url[index]
        else:
            url = 'stop'
    error = url
    if watch_later_checker():
        url = localizar_water_later(url)
    if '\x72\x65\x64\x65\x63\x61\x6e\x61\x69\x73' in url:
        url = resolver_rc(url)
    if url.startswith('moviecdn='):
        url,sub = moviecdn_resolver(url)
        notffmpeg = 'true'
    elif url.startswith('seriecdn='):
        url,sub = seriecdn_resolver(url.split('seriecdn=')[1])
        if '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x63\x6c\x6f\x63\x6c\x6f' in url:
            notffmpeg = 'true'
        else:
            ffmpeg_opt = 'true'
            ffmpeg_input = 'true'
            notffmpeg = 'false'
    elif url.startswith('movie2='):
        url = movies2_resolver(url)
        if url.endswith('/e/'):
            xbmcgui.Dialog().ok('Aviso:', '[B]Servidor indisponível - [COLOR gold]Escolha outro servidor.[/COLOR][/B]')
            url = 'stop'
        if url == 'stop':
            exit()
        if url:
            error = 'urlresolver=' + error
            url = resolvers.detect(url)
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            if not url:
                xbmcgui.Dialog().ok('Aviso:', '[B]Verifique se há bloqueios em sua conexão.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore.[/COLOR][/B]')
        ffmpeg_opt = 'true'
        ffmpeg_input = 'true'
        notffmpeg = 'false'
    elif url.startswith('movie='): #MOVIES
        url,sub = movies_resolver(url)
        if url == '':
            xbmcgui.Dialog().ok(addon_name, "[B][COLOR gold]Filme[/COLOR] indisponível no momento.[CR][CR]Tente novamente mais tarde ou fale com um moderador - [COLOR gold]Erro 404[/COLOR].[/B]")
            exit()
        elif url == 'stop':
            exit()
        if not '\x63\x6c\x6f\x75\x64\x2e\x6d\x61\x69\x6c\x2e\x72\x75' in url:
            error = 'urlresolver=' + error
            url = resolvers.detect(url)
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            if not url:
                xbmcgui.Dialog().ok('Aviso:', '[B]Verifique se há bloqueios em sua conexão.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore.[/COLOR][/B]')
        notffmpeg = 'true'
    elif url.startswith('serie='): #SERIES
        url,sub = movies_resolver(url)
        if url == '':
            xbmcgui.Dialog().ok(addon_name, "[B][COLOR gold]Série[/COLOR] indisponível no momento.[CR][CR]Tente novamente mais tarde ou fale com um moderador - [COLOR gold]Erro 404[/COLOR].[/B]")
            exit()
        elif url == 'stop':
            exit()
        if not '\x63\x6c\x6f\x75\x64\x2e\x6d\x61\x69\x6c\x2e\x72\x75' in url:
            error = 'urlresolver=' + error
            url = resolvers.detect(url)
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            if not url:
                xbmcgui.Dialog().ok('Aviso:', '[B]Verifique se há bloqueios em sua conexão.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore.[/COLOR][/B]')
        notffmpeg = 'true'
    elif '\x2f\x2f\x70\x6c\x61\x79\x2e\x74\x75\x61\x73\x65\x72\x69\x65' in url: #SERIES
        url,resolver = series_resolver(url)
        if url == 'stop':
            exit()
        if resolver == 'true':
            error = 'urlresolver=' + error
            url = resolvers.detect(url)
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            if not url:
                xbmcgui.Dialog().ok('Aviso:', '[B]Verifique se há bloqueios em sua conexão.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore.[/COLOR][/B]')
        notffmpeg = 'true'
    elif '\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61' in url: #SERIES2
        error = 'serie2=' + re.compile('http.+\/(.+)').findall(url)[0].replace('/','')
        url_retry = url
        url = series2_resolver(url)
        if url == 'stop':
            exit()
        if '\x70\x61\x6e\x64\x61\x66\x69\x6c\x65\x73\x2e\x63\x6f\x6d' in url:
            ffmpeg_opt = 'false'
            ffmpeg_input = 'false'
            notffmpeg = 'false'
        if '\x73\x74\x72\x65\x61\x6d\x74\x61\x70\x65' in url:
            error = 'urlresolver=' + error
            url = resolvers.detect(url)
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            if not url:
                xbmcgui.Dialog().ok('Aviso:', '[B]Verifique se há bloqueios em sua conexão.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore.[/COLOR][/B]')
        if '\x77\x61\x72\x65\x7a\x63\x64\x6e' in url:
            url = wovie_embed_resolver(url)
            if not url == '#megaerror':
                url,sub = wovie_resolver(url)
                notffmpeg = 'true'
        if url == 'stop':
            exit()
        if '#megaerror' in url:
            mega_lang = url
            for value in range(5):
                url = series2_resolver(url_retry + mega_lang)
                if url == 'stop':
                    exit()
                elif url:
                    break
        if '#sd_only' in url or not url:
            url = series2_resolver(url_retry + '#sd_only')
            if url == 'stop':
                exit()
        if '#EXTM3U' in url:
            if six.PY3: url = home + 'PlaylistTemp.m3u8'
            if six.PY2: url = home + '\PlaylistTemp.m3u8'
            hls = 'run'
        if '?disable_hls' in url:
            notffmpeg = 'true'
    elif '\x3a\x2f\x2f\x6f\x76\x65\x72\x66\x6c\x69\x78' in url: #serie3
        url = series3_resolver(url)
        if url == 'stop':
            exit()
        if url:
            error = 'urlresolver=' + error
            url = resolvers.detect(url)
            if url == 'not found':
                xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            if not url:
                xbmcgui.Dialog().ok('Aviso:', '[B]Verifique se há bloqueios em sua conexão.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore.[/COLOR][/B]')
        ffmpeg_opt = 'true'
        ffmpeg_input = 'true'
        notffmpeg = 'false'
    elif '\x6d\x69\x78\x2e\x6e\x65\x74' in url:
        error = 'mix=' + re.compile('http.+\/(.+)').findall(url)[0].replace('/','')
        url = SF_LangResolver(url)
        url_retry = url
        if not url:
            notify('[B]Não há links disponíveis.[/B]')
            exit()
        if url == 'stop':
            url = ''
            exit()
        for number in range(5):
            url = SF_Resolver(url_retry)
            if url:
                break
        if url:
            if six.PY3: url = home + 'PlaylistTemp.m3u8'
            if six.PY2: url = home + '\PlaylistTemp.m3u8'
            hls = 'run'
        else:
            url = ''
    elif '\x77\x61\x74\x63\x68\x75\x67\x2e\x77\x61\x74\x63\x68' in url:
        url,sub = wvmob_resolver(url)
        if sub:
            sub = urllib.unquote(sub)
            sub_off = 'true'
        hls = 'run'
    elif url.startswith('resolver1_episodes=') or url.startswith('resolver1_mv='):
        url,sub = resolver1_episodes(url)
        ffmpeg_opt = 'true'
        ffmpeg_input = 'true'
        notffmpeg = 'false'
    elif url.startswith('resolver2_episodes=') or url.startswith('resolver2_mv='):
        url = resolver2_episodes(url)
        notffmpeg = 'true'
    elif url.startswith('resolver3_episodes=') or url.startswith('resolver3_mv='):
        url = resolver3_episodes(url)
        if ".mp4" in url:
            channel_mode = True
        notffmpeg = 'true'
    elif url.startswith('resolver4_episodes=') or url.startswith('resolver4_mv='):
        url = resolver4_episodes(url)
        if ".mp4" in url:
            channel_mode = True
        notffmpeg = 'true'
    elif url.startswith('chresolver1='):
        if '#' in url:
            link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x63\x68\x61\x6e\x6e\x65\x6c\x73\x2e\x78\x6d\x6c'
            html = getMovieData(link)
            find_id = url.split('#')[1]
            find_hostname = re.findall('\x3c\x68\x6f\x73\x74\x6e\x61\x6d\x65\x5f\x25\x73\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x68\x6f\x73\x74\x6e\x61\x6d\x65\x5f\x25\x73\x3e'%(find_id,find_id), html)
            find_users = re.findall('\x3c\x75\x73\x65\x72\x73\x5f\x25\x73\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x75\x73\x65\x72\x73\x5f\x25\x73\x3e'%(find_id,find_id), html)
            host,accounts='',[]
            if find_hostname and find_users:
                host = base64.b64decode(find_hostname[0]).decode('utf-8')
                accounts = base64.b64decode(find_users[0]).decode('utf-8').split('|')
            dialog = xbmcgui.Dialog()
            channel_proxy = False #M3U8_Proxy(host)
            accounts = M3U8_Verify(host,channel_proxy,accounts)
            if accounts:
                channel = url.split('chresolver1=')[1].split('#')[0]
                url = host%(accounts,channel)
                if not valide_v2(url,custom_useragent='XC-IPTV',get_mode=True):
                    url = 'stop'
                    xbmcgui.Dialog().ok('Aviso: Verificação falhou!', '[B]O acesso pode estar sendo bloqueado pela sua internet.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore[/COLOR][CR][COLOR grey]Fazemos verificações diárias nos canais para garantir o funcionamento.[/COLOR][/B]')
                else:
                    channel_mode = True
                    is_livechannel = True
                    if url and not '|' in url:
                        url = '\x25\x73\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x58\x43\x2d\x49\x50\x54\x56'%url
            else:
                url = 'stop'
                xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, updateListing=False, cacheToDisc=False)
        else:
            channel_mode = True
            is_livechannel = True
            url = '\x68\x74\x74\x70\x3a\x2f\x2f\x73\x2e\x61\x70\x6b\x77\x75\x76\x2e\x78\x79\x7a\x2f\x6c\x69\x76\x65\x2f\x64\x65\x6d\x6f\x70\x61\x64\x65\x78\x63\x68\x61\x6e\x67\x65\x2f\x64\x65\x6d\x6f\x70\x61\x64\x2f\x25\x73\x2e\x6d\x33\x75\x38\x7c\x55\x73\x65\x72\x2d\x41\x67\x65\x6e\x74\x3d\x44\x61\x6c\x76\x69\x6b\x2f\x32\x2e\x31\x2e\x30\x20\x28\x4c\x69\x6e\x75\x78\x3b\x20\x55\x3b\x20\x41\x6e\x64\x72\x6f\x69\x64\x20\x39\x3b\x20\x53\x4d\x2d\x53\x39\x30\x38\x45\x20\x42\x75\x69\x6c\x64\x2f\x54\x50\x31\x41\x2e\x32\x32\x30\x36\x32\x34\x2e\x30\x31\x34\x29'%url.split('chresolver1=')[1]
    elif url.startswith('chresolver2='):
        url = chresolver2(url)
        channel_mode = True
    elif url.startswith('onedrive='):
        url = url.split('onedrive=')[1]
        notffmpeg = 'true'
    elif url.startswith('novelas_play='): #NOVELAS
        url = novelas_resolver(url.replace('novelas_play=',''))
        ffmpeg_input = 'true'
        notffmpeg = 'true'
    elif '\x61\x73\x6b\x66\x6c\x69\x78\x2e\x62\x69\x7a' in url:
        url = askflix(url)
        if 'PlaylistTemp.m3u8' in url:
            hls = 'run'
        notffmpeg = 'true'
    elif '\x64\x65\x73\x65\x6e\x68\x6f\x73\x61\x6e\x69\x6d\x61\x64\x6f\x73\x2e\x73\x69\x74\x65' in url: #DESENHOS
        url = desenhos_resolver(url)
        notffmpeg = 'true'
    elif '\x61\x6e\x69\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x70\x2e\x63\x6f\x6d' in url: #DESENHOS2
        url = desenhos2_resolver(url)
        notffmpeg = 'true'
    elif url.startswith('doramas_resolver1='):
        url,sub = doramas_resolver1(url)
        padrao = '\x28\x73\x65\x63\x76\x69\x64\x65\x6f\x5c\x64\x2a\x5c\x2e\x6f\x6e\x6c\x69\x6e\x65\x2e\x2a\x67\x65\x74\x5f\x66\x69\x6c\x65\x2e\x2a\x5c\x2e\x6d\x70\x34\x7c\x76\x69\x64\x65\x6f\x2e\x2a\x5c\x2e\x6d\x70\x34\x2e\x2a\x53\x69\x67\x6e\x65\x64\x48\x65\x61\x64\x65\x72\x73\x29'
        if re.search(padrao, url):
            channel_mode = True
        if 'Playlist.m3u8' in url:
            hls = 'run'
        if url == 'not found':
            xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
        notffmpeg = 'true'
    elif '\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65' in url:
        url = animes1_resolver(url)
        if 'PlaylistTemp.m3u8' in url:
            hls = 'run'
        notffmpeg = 'true'
    elif '\x61\x6e\x69\x6d\x65\x73\x7a\x6f\x6e\x65' in url:
        url = animes2_resolver(url)
        if 'PlaylistTemp.m3u8' in url:
            hls = 'run'
        notffmpeg = 'true'
    elif '\x61\x6e\x69\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x63\x63\x2e\x74\x6f' in url:
        url = animes3_resolver(url)
        notffmpeg = 'true'
    elif '\x62\x65\x74\x74\x65\x72\x61\x6e\x69\x6d\x65\x2e\x73\x62\x73' in url:
        url = animes4_resolver(url)
        notffmpeg = 'true'
    elif '\x62\x65\x74\x74\x65\x72\x61\x6e\x69\x6d\x65\x2e\x6e\x65\x74' in url:
        url = animes5_resolver(url)
        notffmpeg = 'true'
    elif '\x78\x70\x61\x6e\x69\x6d\x65\x73\x3d' in url: #animes6
        url_error = url
        url,error_code = animes6_resolver(url_error)
        if not url:
            if error_code == 9:
                xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 6 - Host não implementado no Resolver.[/COLOR][/B]')
            else:
                xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 6 - Código: %s[/COLOR][/B]'%error_code)
        elif url == 'not found':
            xbmcgui.Dialog().ok("Aviso:", "[B]Episódio não encontrado![/B]")
        #notffmpeg = 'true'
    elif 'pornhub' in url: #PORNHUB
        url = hub_resolver(url)
        if url == 'notavailable':
            xbmcgui.Dialog().ok("Aviso:", "[B]Este vídeo não está mais disponível.[/B]")
        if url == 'removed':
            xbmcgui.Dialog().ok("Aviso:", "[B]Este vídeo foi deletado.[/B]")
        ffmpeg_opt = 'true'
        ffmpeg_input = 'true'
        notffmpeg = 'false'
    elif url.startswith('plus_channel='):
        url = plus_channels(url)
        if url == 'stop':
            exit()
        channel_mode = True
        is_livechannel = True
    elif url == 'here' and 'CANAIS ABERTOS' in name or 'CANAIS ABERTOS' in name or 'DOCUMENTÁRIOS' in name or 'ESPORTES' in name or 'FILMES & SÉRIES' in name or 'INFATIL' in name or 'MÚSICAS & VARIEDADES' in name or 'NOTÍCIAS' in name:
        if epgEnabled == "true":
            notify('[B]Atualizando o EPG...[/B]', 1000)
            xbmc.executebuiltin("Container.Refresh")
    # Ativar Repetir
    if is_livechannel:
        xbmc.executebuiltin('PlayerControl(RepeatOne)')
    elif not is_livechannel:
        xbmc.executebuiltin('PlayerControl(RepeatOff)')
    # Verificar
    custom_error_log = ['\x23\x6d\x6f\x76\x69\x65\x73\x5f\x6c\x69\x73\x74\x3d','\x6d\x6f\x76\x69\x65\x32\x3d','\x6d\x6f\x76\x69\x65\x63\x64\x6e\x3d','\x73\x65\x72\x69\x65\x3d','\x73\x65\x72\x69\x65\x63\x64\x6e\x3d', '\x75\x72\x6c\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d']
    if not url:
        if not any(error.startswith(x) for x in custom_error_log):
            SendErrorLog(error)
        exit()
    if url == 'stop' or url == 'not found':
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, updateListing=False, cacheToDisc=False)
    li = xbmcgui.ListItem(name, path=url)
    li.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    li.setProperty('http-reconnect','true')
    li.setProperty('ForceResolvePlugin', 'true')
    if int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0]) > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setMediaType('video')
        info.setPlot(description)
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    if channel_mode:
        host = urlparse(url.split('|')[0]).netloc
        if ':' in host and any(c.isalpha() for c in host):
            host_check = ''
            if '|' in url:
                host_check = url.split('|')[0]
            elif '%7C' in url:
                host_check = url.split('%7C')[0]
            req = get_headers(url)
            checker = Check_M3U8(host_check,req,channel_proxy)
            if checker:
                url = checker
            #elif channel_proxy:
            #    if url.startswith('http://'):
            #        url += '&Proxy=%s&Proxy_Host=%s'%(channel_proxy,'http://%s'%host)
            #    else:
            #        url += '&Proxy=%s&Proxy_Host=%s'%(channel_proxy,'https://%s'%host)
        import codec
        url = codec.URL_PROXY + string_encoder(url)
        li.setPath(url)
        codec.code().init()
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    elif url.startswith('inputstream_adaptive='):
        url = url.split('inputstream_adaptive=')[1]
        li = xbmcgui.ListItem(name, path=url)
        li.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
        li.setProperty('http-reconnect','true')
        li.setProperty('ForceResolvePlugin', 'true')
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty("inputstream.adaptive.manifest_type", "hls")
        if '|' in url:
            li.setProperty("inputstream.adaptive.manifest_headers", urllib.unquote_plus(url.split('|')[1]))
        li.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        li.setProperty('inputstream.adaptive.is_realtime_stream', 'true')
        li.setProperty('inputstream.adaptive.original_audio_language', 'pt')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    elif (not url == '') and (not url == None) and (not '.mp4' in url) and (not playtemp1 == url) and (not playtemp2 == url) and (notffmpeg == ''):
        if ffmpeg_opt == "false" and ffmpeg_input == "false":
            li.setContentLookup(True)
            #li.setMimeType('application/vnd.apple.mpegurl')
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.stream_mode', 'catchup')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            li.setProperty('inputstream.ffmpegdirect.is_catchup_stream', 'catchup')
            li.setProperty('inputstream.ffmpegdirect.catchup_granularity', '60')
            li.setProperty('inputstream.ffmpegdirect.catchup_terminates', 'true')            
            #li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
            #li.setProperty('inputstream.ffmpegdirect.manifest_type','hls')           
            li.setProperty('inputstream.ffmpegdirect.default_url',url)
            li.setProperty('inputstream.ffmpegdirect.catchup_url_format_string',url)
            li.setProperty('inputstream.ffmpegdirect.programme_start_time','1')
            li.setProperty('inputstream.ffmpegdirect.programme_end_time','19')
            li.setProperty('inputstream.ffmpegdirect.catchup_buffer_start_time','1')
            li.setProperty('inputstream.ffmpegdirect.catchup_buffer_offset','1') 
            li.setProperty('inputstream.ffmpegdirect.default_programme_duration','19')
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        else:
            if sub_off:
                li.setSubtitles([sub.replace('\x2f\x70\x74\x2f','\x2f\x66\x6f\x72\x63\x65\x64\x2f'),sub])
            elif sub:
                li.setSubtitles([sub])
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    elif not url == '' and not url == None:
        if ffmpeg_opt == "false" and ffmpeg_input == "false":
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
            if sub_off:
                li.setSubtitles([sub.replace('\x2f\x70\x74\x2f','\x2f\x66\x6f\x72\x63\x65\x64\x2f'),sub])
            elif sub:
                li.setSubtitles([sub])
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
        else:
            if sub_off:
                li.setSubtitles([sub.replace('\x2f\x70\x74\x2f','\x2f\x66\x6f\x72\x63\x65\x64\x2f'),sub])
            elif sub:
                li.setSubtitles([sub])
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    else:
        xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=False, updateListing=False, cacheToDisc=False)
    if hls == 'run':
        try:
            start_hls()
        except:
            pass

def updateEPG():
    try:
        arquivo = os.path.join(profile, "epgbr.xml")
        exists = os.path.isfile(arquivo)
        uversao = proxied_update('4664b973aba74f1bfef7f2f92c2acbbb/raw/version_epg.txt')
        uversao = re.compile('[a-zA-Z\.\d]+').findall(uversao)[0]
        if exists == False:
            downloadEPG(uversao)
        else:
            if epgLast == "":
                downloadEPG(uversao)
            else:
                if uversao != epgLast:
                    downloadEPG(uversao)
                else:
                    InstallPlugin()
    except:
        notify('[COLOR red]Erro ao atualizar EPG![/COLOR]')

def downloadEPG(data):
    try:
        import downloader
        arquivo = os.path.join(profile, "epgbr.xml")
        exists = os.path.isfile(arquivo)
        dp = xbmcgui.DialogProgress()
        dp.create('Baixando EPG...','Por favor aguarde...')
        if exists:
            try:
                os.remove(arquivo)
            except:
                pass
        #downloader_epg.download(base64.b64decode(epg_url), arquivo, dp)
        downloader.download(epg_url, arquivo, dp)
        xbmc.sleep(100)
        #data = datetime.now()
        #data = data.strftime("%d.%m.%y")
        xbmcaddon.Addon().setSetting("epg_last", data)
        #CleanEPG()
        #dp.close()
        #xbmc.sleep(2000)
        #InstallPlugin()
    except:
        notify('[COLOR red]Erro ao atualizar EPG![/COLOR]')

def CleanEPG():
    arquivo = os.path.join(profile, "epgbr.xml")
    try:
        with open(arquivo, encoding='utf-8') as f:
            content = f.read()
            for dias in range(1, 8):
                days = datetime.now() - timedelta(days=dias)
                days = days.strftime('%Y%m%d')
                if content.find(days):
                    content = re.sub('<programme.+stop="'+days+'.+<.programme>', '', content)
                if dias == 7:
                    content = content.replace('\n', '').replace('\r','')
                    content = content.replace('<programme start=', '\n' +'<programme start=')
            file = open(arquivo,'w',encoding='utf-8')
            file.write(content)
            file.close()
    except:
        addon_log('Fix EPG Fail')

def epgParseData():
    try:
        arquivo = os.path.join(profile, "epgbr.xml")
        xml = ET.parse(arquivo)
        return xml.getroot()
    except:
        notify('[COLOR red]Erro ao carregar EPG![/COLOR]')
        return None

def getID_EPG(name):
    #name = name.encode('utf-8','ignore')
    if re.search("A&E",name,re.IGNORECASE):
        channel_id = 'Ae.br'
    elif re.search("AMC",name,re.IGNORECASE):
        channel_id = 'Amc.br'
    elif re.search("Animal Planet",name,re.IGNORECASE):
        channel_id = 'Animalplanet.br'
    elif re.search("Arte 1",name,re.IGNORECASE):
        channel_id = 'Arte1.br'
    elif re.search("AXN",name,re.IGNORECASE):
        channel_id = 'Axn.br'
    elif re.search("Baby TV",name,re.IGNORECASE) or re.search("BabyTV",name,re.IGNORECASE):
        channel_id = 'BabyTV.br'
    elif re.search("Band",name,re.IGNORECASE) and not re.search("Band News",name,re.IGNORECASE) and not re.search("Band Sports",name,re.IGNORECASE):
        channel_id = 'BandRede.br'
    elif re.search("Band News",name,re.IGNORECASE):
        channel_id = 'Bandnews.br'
    elif re.search("Band Sports",name,re.IGNORECASE):
        channel_id = 'Bandsportshd.br'
    elif re.search("BIS",name,re.IGNORECASE):
        channel_id = 'Bishd.br'
    elif re.search("Boomerang",name,re.IGNORECASE):
        channel_id = 'Boomerang.br'
    elif re.search("Canal Brasil",name,re.IGNORECASE):
        channel_id = 'Canalbrasil.br'
    elif re.search("Cancao Nova",name,re.IGNORECASE) or re.search("Canção Nova",name,re.IGNORECASE):
        channel_id = 'CancaoNova.br'
    elif re.search("Cartoon Network",name,re.IGNORECASE):
        channel_id = 'Cartoonnetwork.br'
    elif re.search("Cinemax",name,re.IGNORECASE):
        channel_id = 'Cinemax.br'
    elif re.search("Combate",name,re.IGNORECASE):
        channel_id = 'Combatehd.br'
    elif re.search("Comedy Central",name,re.IGNORECASE):
        channel_id = 'Comedycentral.br'
    elif re.search("Cultura",name,re.IGNORECASE):
        channel_id = 'Tvcultura.br'
    elif re.search("Curta!",name,re.IGNORECASE) or re.search("Curta",name,re.IGNORECASE):
        channel_id = 'Curta.br'
    elif re.search("Discovery Channel",name,re.IGNORECASE):
        channel_id = 'Discovery.br'
    elif re.search("Discovery Civilization",name,re.IGNORECASE):
        channel_id = 'DiscoveryCivilization.br'
    elif re.search("Discovery Home & Health",name,re.IGNORECASE) or re.search("Discovery H&H",name,re.IGNORECASE):
        channel_id = 'Homehealth.br'
    elif re.search("Discovery Kids",name,re.IGNORECASE):
        channel_id = 'Discoverykids.br'
    elif re.search("Discovery Science",name,re.IGNORECASE):
        channel_id = 'DiscoveryScience.br'
    elif re.search("Discovery Theater",name,re.IGNORECASE):
        channel_id = 'Hdtheater.br'
    elif re.search("Discovery Turbo",name,re.IGNORECASE):
        channel_id = 'Discturbohd.br'
    elif re.search("Discovery World",name,re.IGNORECASE):
        channel_id = 'Discoveryworldhd.br'
    elif re.search("Disney Channel",name,re.IGNORECASE):
        channel_id = 'Disneychannel.br'
    elif re.search("Disney Junior",name,re.IGNORECASE) or re.search("Disney Jr",name,re.IGNORECASE):
        channel_id = 'Disneyjrhd.br'
    elif re.search("Disney XD",name,re.IGNORECASE):
        channel_id = 'Disneyxd.br'
    elif re.search("Disney",name,re.IGNORECASE):
        channel_id = 'Disneychannel.br'
    elif re.search("E!",name,re.IGNORECASE):
        channel_id = 'E.br'
    elif re.search("E!",name,re.IGNORECASE):
        channel_id = 'E.br'
    elif re.search("ESPN",name,re.IGNORECASE) and not re.search("ESPN 2",name,re.IGNORECASE) and not re.search("ESPN Brasil",name,re.IGNORECASE) and not re.search("ESPN Extra",name,re.IGNORECASE):
        channel_id = 'ESPNInternational.br'
    elif re.search("ESPN 2",name,re.IGNORECASE):
        channel_id = 'ESPN+.br'
    elif re.search("ESPN Brasil",name,re.IGNORECASE):
        channel_id = 'Espnbrasil.br'
    elif re.search("ESPN Extra",name,re.IGNORECASE):
        channel_id = 'Espnextra.br'
    elif re.search("FishTV",name,re.IGNORECASE) or re.search("Fish TV",name,re.IGNORECASE):
        channel_id = 'Fishtv.br'
    elif re.search("Food Network",name,re.IGNORECASE):
        channel_id = 'Foodnetworkhd.br'
    elif re.search("Star Channel",name,re.IGNORECASE) or re.search("Fox",name,re.IGNORECASE) and not re.search("Fox Life",name,re.IGNORECASE) and not re.search("FOX Premium 1",name,re.IGNORECASE) and not re.search("FOX Premium 2",name,re.IGNORECASE) and not re.search("Fox Sports",name,re.IGNORECASE) and not re.search("Fox Sports 2",name,re.IGNORECASE) and not re.search("Fox 25",name,re.IGNORECASE) and not re.search("News",name,re.IGNORECASE):
        channel_id = 'Fox.br'
    elif re.search("Star Life",name,re.IGNORECASE) or re.search("Fox Life",name,re.IGNORECASE):
        channel_id = 'Foxlife.br'
    elif re.search("Star Hits 1",name,re.IGNORECASE) or re.search("FOX Premium 1",name,re.IGNORECASE):
        channel_id = 'Foxpremium1.br'
    elif re.search("Star Hits 2",name,re.IGNORECASE) or re.search("FOX Premium 2",name,re.IGNORECASE):
        channel_id = 'Foxpremium2.br'
    elif re.search("Fox Sports",name,re.IGNORECASE) and not re.search("Fox Sports 2",name,re.IGNORECASE):
        channel_id = 'Foxsports.br'
    elif re.search("Fox Sports 2",name,re.IGNORECASE):
        channel_id = 'Foxsports2.br'
    elif re.search("Futura",name,re.IGNORECASE):
        channel_id = 'Futura.br'
    elif re.search("FX",name,re.IGNORECASE) and not re.search("US",name,re.IGNORECASE):
        channel_id = 'Fx.br'
    elif re.search("Film & Arts",name,re.IGNORECASE):
        channel_id = 'FilmArts.br'
    elif re.search("Globo Brasilia",name,re.IGNORECASE) or re.search("Globo Brasília",name,re.IGNORECASE):
        channel_id = 'GloboBrasilia.br'
    elif re.search("Globo Campinas",name,re.IGNORECASE) or re.search("Globo EPTV Campinas",name,re.IGNORECASE):
        channel_id = 'GloboEPTVCampinas.br'
    elif re.search("Globo Minas",name,re.IGNORECASE):
        channel_id = 'Globominas.br'
    elif re.search("Globo News",name,re.IGNORECASE):
        channel_id = 'Globonews.br'
    elif re.search("Globo RBS TV Poa",name,re.IGNORECASE) or re.search("RBS TV",name,re.IGNORECASE) or re.search("RBS Porto Alegre",name,re.IGNORECASE):
        channel_id = 'GloboPortoAlegre.br'
    elif re.search("Globo RJ",name,re.IGNORECASE):
        channel_id = 'Globorj.br'
    elif re.search("Globo SP",name,re.IGNORECASE) or re.search("Globo",name,re.IGNORECASE) and not re.search("Mais Globosat",name,re.IGNORECASE) and not re.search("Globo Nordeste",name,re.IGNORECASE):
        channel_id = 'Globosp.br'
    elif re.search("Globo TV Anhanguera",name,re.IGNORECASE):
        channel_id = 'GloboAnhangueraGoias.br'
    elif re.search("Globo TV Bahia",name,re.IGNORECASE):
        channel_id = 'Tvbahia.br'
    elif re.search("Globo TV Tem Bauru",name,re.IGNORECASE) or re.search("TV Tem Bauru",name,re.IGNORECASE) or re.search("TVTem Bauru",name,re.IGNORECASE):
        channel_id = 'Tvtembauru.br'
    elif re.search("Globo TV Tribuna",name,re.IGNORECASE) or re.search("TV Tribuna",name,re.IGNORECASE):
        channel_id = 'Tvtribuna.br'
    elif re.search("Globo TV Vanguarda",name,re.IGNORECASE) or re.search("TV Vanguarda",name,re.IGNORECASE):
        channel_id = 'Vangsaojchd.br'
    elif re.search("Globo Inter TV Alto Litoral",name,re.IGNORECASE):
        channel_id = 'Inttvaltolit.br'
    elif re.search("Globo Inter TV Grande Minas",name,re.IGNORECASE) or re.search("Globo Inter TV Minas",name,re.IGNORECASE):
        channel_id = 'Intertvgminas.br'
    elif re.search("Globo NSC Florianopolis",name,re.IGNORECASE):
        channel_id = 'NSCTV.br'
    elif re.search("Globo Nordeste",name,re.IGNORECASE):
        channel_id = 'Globorecife.br'
    elif re.search("RPC TV",name,re.IGNORECASE) or re.search("RPC Parana",name,re.IGNORECASE) or re.search("RPC Curitiba",name,re.IGNORECASE):
        channel_id = 'Rpccuritiba.br'
    elif re.search("Gloob",name,re.IGNORECASE) and not re.search("Gloobinho",name,re.IGNORECASE):
        channel_id = 'Gloob.br'
    elif re.search("Gloobinho",name,re.IGNORECASE):
        channel_id = 'Gloobinho.br'
    elif re.search("GNT",name,re.IGNORECASE):
        channel_id = 'Gnt.br'
    elif re.search("HBO",name,re.IGNORECASE) and not re.search("HBO 2",name,re.IGNORECASE) and not re.search("HBO Family",name,re.IGNORECASE) and not re.search("HBO Plus",name,re.IGNORECASE) and not re.search("HBO Signature",name,re.IGNORECASE) and not re.search("HBO Mundi",name,re.IGNORECASE) and not re.search("HBO Xtreme",name,re.IGNORECASE) and not re.search("HBO Pop",name,re.IGNORECASE):
        channel_id = 'Hbo.br'
    elif re.search("HBO 2",name,re.IGNORECASE):
        channel_id = 'Hbo2.br'
    elif re.search("HBO Family",name,re.IGNORECASE):
        channel_id = 'Hbofamily.br'
    elif re.search("HBO Plus",name,re.IGNORECASE):
        channel_id = 'Hboplus.br'
    elif re.search("HBO Signature",name,re.IGNORECASE):
        channel_id = 'Hbosignature.br'
    elif re.search("HBO Mundi",name,re.IGNORECASE):
        channel_id = 'Max.br'
    elif re.search("HBO Xtreme",name,re.IGNORECASE):
        channel_id = 'Maxprime.br'
    elif re.search("HBO Pop",name,re.IGNORECASE):
        channel_id = 'Maxup.br'
    elif re.search("History",name,re.IGNORECASE):
        channel_id = 'Historychannel.br'
    elif re.search("ID",name,re.IGNORECASE) and not re.search("Nat Geo Kids",name,re.IGNORECASE):
        channel_id = 'Investigacaodiscoveryid.br'
    elif re.search("Lifetime",name,re.IGNORECASE):
        channel_id = 'Lifetime.br'
    elif re.search("Mais GloboSat",name,re.IGNORECASE) or re.search("Modo Viagem",name,re.IGNORECASE):
        channel_id = '+globosat.br'
    elif re.search("Max",name,re.IGNORECASE) and not re.search("Max Prime",name,re.IGNORECASE) and not re.search("Max UP",name,re.IGNORECASE):
        channel_id = 'Max.br'
    elif re.search("Max Prime",name,re.IGNORECASE):
        channel_id = 'Maxprime.br'
    elif re.search("Max UP",name,re.IGNORECASE):
        channel_id = 'Maxup.br'
    elif re.search("Megapix",name,re.IGNORECASE):
        channel_id = 'Megapix.br'
    elif re.search("MTV",name,re.IGNORECASE) and not re.search("US",name,re.IGNORECASE):
        channel_id = 'Mtv.br'
    elif re.search("Multishow",name,re.IGNORECASE):
        channel_id = 'Multishow.br'
    elif re.search("Nat Geo Kids",name,re.IGNORECASE) and not re.search("Nat Geo Wild",name,re.IGNORECASE) and not re.search("National Geographic",name,re.IGNORECASE):
        channel_id = 'Natgeokids.br'
    elif re.search("Nat Geo Wild",name,re.IGNORECASE):
        channel_id = 'Natgeowildhd.br'
    elif re.search("Nat Geo",name,re.IGNORECASE):
        channel_id = 'Nationalgeographic.br'
    elif re.search("Nick",name,re.IGNORECASE) and not re.search("Nick Jr",name,re.IGNORECASE) and not re.search("Nick Junior",name,re.IGNORECASE):
        channel_id = 'Nickelodeon.br'
    elif re.search("Nick Jr",name,re.IGNORECASE):
        channel_id = 'NickJr.br'
    elif re.search("Off",name,re.IGNORECASE) and not re.search("CNN",name,re.IGNORECASE):
        channel_id = 'Off.br'
    elif re.search("PlayBoy",name,re.IGNORECASE):
        channel_id = 'Playboytv.br'
    elif re.search("Paramount",name,re.IGNORECASE):
        channel_id = 'Paramounthd.br'
    elif re.search("Paramount",name,re.IGNORECASE):
        channel_id = 'Playtv.br'
    elif re.search("Premiere Clube",name,re.IGNORECASE):
        channel_id = 'Premierefchd.br'
    elif re.search("Prime Box",name,re.IGNORECASE):
        channel_id = 'Primeboxbrazil.br'
    elif re.search("Ra Tim Bum",name,re.IGNORECASE):
        channel_id = 'Tvratimbum.br'
    elif re.search("Record News",name,re.IGNORECASE):
        channel_id = 'Recordnews.br'
    elif re.search("Record News",name,re.IGNORECASE):
        channel_id = 'Recordnews.br'
    elif re.search("Record",name,re.IGNORECASE) or re.search("Record SP",name,re.IGNORECASE):
        channel_id = 'Rederecord.br'
    elif re.search("Rede Brasil",name,re.IGNORECASE):
        channel_id = 'Redebrasil.br'
    elif re.search("Rede TV",name,re.IGNORECASE) or re.search("RedeTV",name,re.IGNORECASE):
        channel_id = 'Redetv.br'
    elif re.search("Rede Vida",name,re.IGNORECASE):
        channel_id = 'Redevida.br'
    elif re.search("SBT",name,re.IGNORECASE):
        channel_id = 'Sbt.br'
    elif re.search("Sexy Hot",name,re.IGNORECASE) or re.search("SexyHot",name,re.IGNORECASE):
        channel_id = 'Sexyhot.br'
    elif re.search("Sony",name,re.IGNORECASE):
        channel_id = 'Sony.br'
    elif re.search("Space",name,re.IGNORECASE):
        channel_id = 'Space.br'
    elif re.search("Sportv",name,re.IGNORECASE) and not re.search("Sportv 2",name,re.IGNORECASE) and not re.search("Sportv 3",name,re.IGNORECASE):
        channel_id = 'Sportv.br'
    elif re.search("Sportv 2",name,re.IGNORECASE):
        channel_id = 'Sportv2.br'
    elif re.search("Sportv 3",name,re.IGNORECASE):
        channel_id = 'Sportv3.br'
    elif re.search("Studio Universal",name,re.IGNORECASE):
        channel_id = 'Studiouniversal.br'
    elif re.search("Universal Channel",name,re.IGNORECASE) or re.search("Universal TV",name,re.IGNORECASE):
        channel_id = 'Universalchannel.br'
    elif re.search("Syfy",name,re.IGNORECASE) or re.search("Usa Network",name,re.IGNORECASE):
        channel_id = 'Syfy.br'
    elif re.search("TBS",name,re.IGNORECASE):
        channel_id = 'Tbs.br'
    elif re.search("TCM",name,re.IGNORECASE):
        channel_id = 'Tcm.br'
    elif re.search("Telecine Action",name,re.IGNORECASE):
        channel_id = 'Tcaction.br'
    elif re.search("Telecine Action",name,re.IGNORECASE):
        channel_id = 'Tcaction.br'
    elif re.search("Telecine Cult",name,re.IGNORECASE):
        channel_id = 'Tccult.br'
    elif re.search("Telecine Fun",name,re.IGNORECASE):
        channel_id = 'Tcfun.br'
    elif re.search("Telecine Pipoca",name,re.IGNORECASE):
        channel_id = 'Tcpipoca.br'
    elif re.search("Telecine Premium",name,re.IGNORECASE):
        channel_id = 'Tcpremium.br'
    elif re.search("Telecine Touch",name,re.IGNORECASE):
        channel_id = 'Tctouch.br'
    elif re.search("TLC",name,re.IGNORECASE):
        channel_id = 'Tlc.br'
    elif re.search("TNT S.RIE",name,re.IGNORECASE):
        channel_id = 'TNTSerie.br'
    elif re.search("TNT",name,re.IGNORECASE) and not re.search("TNT S.RIE",name,re.IGNORECASE) and not re.search("TNT NOVELA",name,re.IGNORECASE):
        channel_id = 'Tnt.br'
    elif re.search("Tooncast",name,re.IGNORECASE):
        channel_id = 'Tooncast.br'
    elif re.search("truTV",name,re.IGNORECASE):
        channel_id = 'Trutv.br'
    elif re.search("TV Gazeta",name,re.IGNORECASE):
        channel_id = 'TVGazeta.br'
    elif re.search("VH1",name,re.IGNORECASE) and not re.search("VH1 Megahits",name,re.IGNORECASE):
        channel_id = 'VH1HD.br'
    elif re.search("VH1 Megahits",name,re.IGNORECASE):
        channel_id = 'VH1MegaHits.br'
    elif re.search("Viva",name,re.IGNORECASE) or re.search("Globoplay Novelas",name,re.IGNORECASE):
        channel_id = 'Viva.br'
    elif re.search("Warner Channel",name,re.IGNORECASE) or re.search("Warner",name,re.IGNORECASE):
        channel_id = 'Warnerchannel.br'
    elif re.search("WooHoo",name,re.IGNORECASE):
        channel_id = 'Woohoo.br'
    elif re.search("Zoomoo",name,re.IGNORECASE):
        channel_id = 'Zoomoo.br'
    elif re.search("CNN Brasil",name,re.IGNORECASE):
        channel_id = 'Cnnbrasil.br'
    elif re.search("H2",name,re.IGNORECASE):
        channel_id = 'H2.br'
    elif re.search("HGTV",name,re.IGNORECASE):
        channel_id = 'Hgtv.br'
    else:
        channel_id = ''
    return channel_id

def getEPG(root, chan, max_epg=2):
    try:
        agora = datetime.now().strftime("%Y%m%d%H%M%S")
        programas = root.findall("./programme[@channel='{}']".format(chan))
        epg_lista = []
        desc_lista = []
        for item in programas:
            start, stop = item.get('start')[:-6], item.get('stop')[:-6]
            if int(agora) < int(stop):
                titulo = item.find('title').text
                desc = item.find('desc')
                sinopse = "[CR][CR]{}".format(desc.text) if desc is not None else "[CR][CR]Nenhuma informação disponível"
                epg_formatado = "[B][COLOR white]{}[/COLOR][/B][CR][COLOR gold][B]{}:{} - {}:{}[/B][/COLOR]".format(
                    titulo, start[8:-4], start[10:-2], stop[8:-4], stop[10:-2]
                )
                epg_lista.append(' - %s'%epg_formatado)
                desc_lista.append(epg_formatado + sinopse)
                if len(epg_lista) >= max_epg:
                    break  # Para após atingir o limite definido
        return epg_lista[0] if epg_lista else '', "[CR][CR]".join(desc_lista) if desc_lista else ''
    except Exception:
        return '', ''

def getEPG2(root,chan):
    try:
        programas = root.findall("./programme[@channel='"+chan+"']")
        agora = datetime.now()
        agora = agora.strftime("%Y%m%d%H%M%S")
        proximo = datetime.now()
        proximo = proximo.strftime("%Y%m%d%H%M%S")
        for item in programas:
            start = item.get('start')[:-6]
            stop = item.get('stop')[:-6]
            if int(start) <= int(agora) < int(stop):
                proximo = stop
                epg = ' - [B][COLOR white]' + item.find('title').text + '[/COLOR][/B]' + '[CR][COLOR gold][B]' + start[8:-4] + ':' + start[10:-2] + ' - ' + stop[8:-4] + ':' + stop[10:-2] + '[/B][/COLOR]'
                desc = item.find('desc')
                if desc is None:
                    sinopse = '[CR][CR]Nenhuma informação disponível'
                else:
                    sinopse = '[CR][CR]' + desc.text
                desc_epg = epg + sinopse
            if int(start) <= int(proximo) < int(stop):
                epg2 = '[B][COLOR white]' + item.find('title').text + '[/COLOR][/B]' + '[CR][COLOR gold][B]' + start[8:-4] + ':' + start[10:-2] + ' - ' + stop[8:-4] + ':' + stop[10:-2] + '[/B][/COLOR]'
                desc = item.find('desc')
                epg_show = epg.replace(' - [B][COLOR white]','[B][COLOR white]')
                if desc is None:
                    sinopse2 = '[CR][CR]Nenhuma informação disponível'
                else:
                    sinopse2 = '[CR][CR]' + desc.text
                desc_epg = epg_show + sinopse + '[CR][CR]' + epg2+sinopse2
        return epg, desc_epg;
    except:
        epg = ''
        desc_epg = ''
        return epg, desc_epg;

def remove_repetidos(keys):
    l = []
    for i in keys:
        if i not in l:
            l.append(i)
    l.sort()
    return l

def editar_txt(txt):
    keys = {}
    x = {'&Aacute;':'Á','&aacute;':'á','&Acirc;':'Â','&acirc;':'â','&Agrave;':'À','&agrave;':'à','&Aring;':'Å','&aring;':'å','&Atilde;':'Ã','&atilde;':'ã','&Auml;':'Ä','&auml;':'ä','&AElig;':'Æ','&aelig;':'æ','&Eacute;':'É','&eacute;':'é','&Ecirc;':'Ê','&ecirc;':'ê','&Egrave;':'È','&egrave;':'è','&Euml;':'Ë','&euml;':'ë','&ETH;':'Ð','&eth;':'ð','&Iacute;':'Í','&iacute;':'í','&Icirc;':'Î','&icirc;':'î','&Igrave;':'Ì','&igrave;':'ì','&Iuml;':'Ï','&iuml;':'ï','&Oacute;':'Ó','&oacute;':'ó','&Ocirc;':'Ô','&ocirc;':'ô','&Ograve;':'Ò','&ograve;':'ò','&Oslash;':'Ø','&oslash;':'ø','&Otilde;':'Õ','&otilde;':'õ','&Ouml;':'Ö','&ouml;':'ö','&Uacute;':'Ú','&uacute;':'ú','&Ucirc;':'Û','&ucirc;':'û','&Ugrave;':'Ù','&ugrave;':'ù','&Uuml;':'Ü','&uuml;':'ü','&Ccedil;':'Ç','&ccedil;':'ç','&Ntilde;':'Ñ','&ntilde;':'ñ','&lt;':'<','&gt;':'>','&amp;':'&','&quot;':'"','&reg;':'®','&copy;':'©','&Yacute;':'Ý','&yacute;':'ý','&THORN;':'Þ','&thorn;':'þ','&szlig;':'ß','&ndash;':'-','&acute;':'D´','&acirc;':'â','&Acirc;':'Â','&ldquo;':'`','&rdquo;':'`','&ordf;':'ª','&nbsp;':'-','&rsquo;':"´",'&sup2;':'²','&sup3;':'³','&hellip;':'...','&ordm;':'º','&deg;':'°'}
    z = re.compile('&.*?;').findall(str(txt))
    keys = remove_repetidos(z)
    for name, age in x.items():
        txt = txt.replace(name,age)
    return txt

def pornhub(name,url,fanart):
    try:
        base_url = 'https://pt.pornhub.com'
        if not 'https://pt.pornhub.com' in url:
            url = base_url+url
        base = getMovieData(url)
        link = base.replace('\n','').replace('\r','').replace('data-thumb_url = "','data-thumb_url="')
        nome = re.compile('data-video-vkey="(.+?)".+?data-poster="(.+?)".+?alt="(.+?)"').findall(link)
        for url, thumb, title in nome:
            if not 'javascript:void(0)' in url:
                title = editar_txt(title)
                title = title.replace("&#039;","'").upper()
                addLink('[B]'+title+'[/B]','%s/view_video.php/?viewkey=%s'%(base_url,url),16,thumb,fanart,'','','')
        #PageNavigation
        page = re.compile('<li class="page_current.+?<li class="page_number"><a class="greyButton" href="(.+?)">(.+?)</a></li>').findall(link)
        #page = re.findall('',base,re.DOTALL)[0]
        for url, page_id in page:
            url = url.replace('&amp;','&')
            addDir('[B][COLOR gold]PRÓXIMA PÁGINA %s[/COLOR][/B]'%page_id,base_url+url,2,'',fanart,'','','')
    except:
        xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[/B]')

try:
    if 'PESQUISE POR FILMES' in xbmc.getInfoLabel('ListItem.Label') or 'HUB' and 'PESQUISA?' in xbmc.getInfoLabel('ListItem.Label') or 'PESQUISAR SÉRIES' in xbmc.getInfoLabel('ListItem.Label') or 'PESQUISAR NOVELAS' in xbmc.getInfoLabel('ListItem.Label') or 'PESQUISAR ANIMES' in xbmc.getInfoLabel('ListItem.Label') or 'PESQUISAR DORAMAS' in xbmc.getInfoLabel('ListItem.Label') or 'PESQUISAR DESENHOS' in xbmc.getInfoLabel('ListItem.Label'):
        global pesquisa_desativar
        global search
        pesquisa_desativar = 'false'
        search = ''
except:
    pass

def search_clean(title):
    try:
        title = remover_acentos(title).decode('utf-8')
        return re.sub(r'\W', '', title)
    except:
        return ''

def pesquisar_filmes():
    try:
        global pesquisa_desativar
        global search
        if pesquisa_desativar == 'false':
            if search == '':
                search = get_search_string('PESQUISE O SEU FILME FAVORITO')
                if search:
                    if search == '' or search == ' ' or search == '  ':
                        pesquisa_desativar = 'false'
                        search = ''
                        pesquisar_filmes()
                        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                    pesquisa_desativar = 'true'
                    pesquisa_final(url)
                else:
                    pesquisa_desativar = 'false'
                    search = ''
                    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        else:
            pesquisa_final(url)
    except:
        pass

def pesquisa_final(mode):
    try:
        if features_enable == 'true' and not features_pass == '' and mode == '\x23\x68\x6f\x6d\x65\x3d\x73\x65\x61\x72\x63\x68\x5f\x70\x6c\x75\x73\x6d\x6f\x76\x69\x65\x73\x23':
            hashed_pw_verify = features_checker()
            if hashed_pw_verify:
                url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'mvmenunew'
                url = getMovieData(url)
                url = re.compile('\x3c\x73\x65\x61\x72\x63\x68\x5f\x62\x61\x73\x65\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x65\x61\x72\x63\x68\x5f\x62\x61\x73\x65\x3e').findall(url)[0]
                link = getMovieData(url)
                nome = re.compile('<title>(.*?)</title>.*?<link>(.*?)</link>.*?<thumbnail>(.*?)</thumbnail>.*?<fanart>(.*?)</fanart>.*?<info>(.*?)</info>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(link)
                find_id = '0'
                for title, url, thumb, fanArt, info in nome:
                    if not thumb:
                        thumb = iconimage
                    if not fanArt:
                        fanArt = fanart
                    title2 = title.replace('[B][COLOR white]','').replace('[/COLOR][/B]','').replace(' [COLOR gold](LEG)[/COLOR]','')
                    title2 = search_clean(title2)
                    title2 = re.sub(u"[àáâãäå]", 'a', title2)
                    title2 = re.sub(u"[èéêë]", 'e', title2)
                    title2 = re.sub(u"[ìíîï]", 'i', title2)
                    title2 = re.sub(u"[òóôõö]", 'o', title2)
                    title2 = re.sub(u"[ùúûü]", 'u', title2)
                    title2 = re.sub(u"[ýÿ]", 'y', title2)
                    title2 = re.sub(u"[ß]", 'ss', title2)
                    title2 = re.sub(u"[ñ]", 'n', title2)
                    title2 = re.sub(u"[&]", 'e', title2)
                    title2 = title2.lower()
                    if search in title2 and '.mp4' in url:
                        addLink(title,url,16,thumb,fanArt,info,'','')
                        find_id = '1'
                if find_id == '0':
                    notify('[B][COLOR gold]'+search+'[/COLOR] não encontrado![/B]')
                    exit()
        else:
            link = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x35\x62\x38\x37\x37\x39\x37\x33\x32\x39\x63\x37\x62\x34\x36\x34\x32\x32\x35\x36\x35\x66\x66\x62\x61\x61\x62\x33\x62\x65\x37\x65\x2f\x72\x61\x77\x2f\x70\x61\x67\x65\x2e\x78\x6d\x6c')
            link = link.replace('\n','').replace('\r','')
            nome = re.compile('<title>(.*?)</title>.*?<link>(.*?)</link>.*?<thumbnail>(.*?)</thumbnail>.*?<fanart>(.*?)</fanart>.*?<info>(.*?)</info>').findall(link)
            find_id = '0'
            for title, url, thumb, fanArt, info in nome:
                title2 = title.replace('[B][COLOR white]','').replace('[/COLOR][/B]','').replace(' [COLOR gold](LEG)[/COLOR]','')
                title2 = search_clean(title2)
                title2 = title2.lower()
                if (search in title2) and not url == 'here':
                    addLink(title,url,16,thumb,fanArt,info,'','')
                    find_id = '1'
            if find_id == '0':
                notify('[B][COLOR gold]'+search+'[/COLOR] não encontrado![/B]')
                exit()
    except:
        pass

def pesquisar_series():
    try:
        link = ''
        url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x53\x65\x72\x69\x65\x73\x42\x61\x73\x65'
        try:
            if features_enable == 'true' and not features_pass == '':
                hashed_pw_verify = features_checker()
                if hashed_pw_verify:
                    url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'srs'
        except:
            pass
        link = getMovieData(url)
        link = link.replace('\n','').replace('\r','')
        nome = re.compile('<name>(.*?)</name>.*?<externallink>(.*?)</externallink>.*?<thumbnail>(.*?)</thumbnail>.*?<fanart>(.*?)</fanart>.*?<info>(.*?)</info>').findall(link)
        find_id = '0'
        for title, url, thumb, fanArt, info in nome:
            title2 = title.replace('[B][COLOR white]','').replace('[COLOR gold]','').replace('[/COLOR][/B]','').replace('[/COLOR]','').replace('(','').replace(')','')
            title2 = search_clean(title2)
            title2 = re.sub(u"[àáâãäå]", 'a', title2)
            title2 = re.sub(u"[èéêë]", 'e', title2)
            title2 = re.sub(u"[ìíîï]", 'i', title2)
            title2 = re.sub(u"[òóôõö]", 'o', title2)
            title2 = re.sub(u"[ùúûü]", 'u', title2)
            title2 = re.sub(u"[ýÿ]", 'y', title2)
            title2 = re.sub(u"[ß]", 'ss', title2)
            title2 = re.sub(u"[ñ]", 'n', title2)
            title2 = re.sub(u"[&]", 'e', title2)
            title2 = title2.lower()
            if search in title2:
                try:
                    thumb = base64.b64decode(thumb).decode('utf-8')
                except:
                    pass
                if thumb.startswith('serie='):
                    myid = base64.b64decode(thumb.split('serie=')[1]).decode('utf-8')
                    thumb = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x70\x6f\x73\x74\x65\x72\x50\x74\x2f\x33\x34\x32\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                    fanArt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2f\x31\x32\x38\x30\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                if fanArt.startswith('serie='):
                    myid = base64.b64decode(fanArt.split('serie=')[1]).decode('utf-8')
                    fanArt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2f\x31\x32\x38\x30\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                if not fanArt:
                    fanArt = fanart
                if url.startswith('#series_list='):
                    title = '[B][COLOR white]●[/COLOR][/B] ' + title
                    mode_select = 27
                elif url.startswith('rede='):
                    url = url.replace('rede=','')
                    url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x65\x64\x65\x63\x61\x6e\x61\x69\x73\x2e\x63\x78\x2f\x62\x72\x6f\x77\x73\x65\x2d' + url + '\x2d\x76\x69\x64\x65\x6f\x73\x2d\x31\x2d\x64\x61\x74\x65\x2e\x68\x74\x6d\x6c'
                    title = '[B][COLOR red]●[/COLOR][/B] ' + title
                    mode_select = 7
                elif url.startswith('serie2='):
                    title = '[B][COLOR blue]●[/COLOR][/B] ' + title
                    mode_select = 26
                elif url.startswith('serie3='):
                    title = '[B][COLOR dodgerblue]●[/COLOR][/B] ' + title
                    mode_select = 26
                elif url.startswith('seriecdn='):
                    title = '[B][COLOR orange]●[/COLOR][/B] ' + title
                    mode_select = 26
                elif url.startswith('tseries='):
                    title = '[B][COLOR gold]●[/COLOR][/B] ' + title
                    mode_select = 24
                elif url.startswith('ntcdn_tvshows='): #Reservado
                    title = '[B][COLOR orangered]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('serie='):
                    title = '[B][COLOR red]●[/COLOR][/B] ' + title
                    mode_select = 23
                    try:
                        url = base64.b64decode(url.split('serie=')[1]).decode('utf-8')
                        url = 'serie=' + url
                    except:
                        pass
                elif url.startswith('sfserie='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 29
                    try:
                        url = base64.b64decode(url.split('sfserie=')[1]).decode('utf-8')
                        url = 'sfserie=' + url
                    except:
                        pass
                elif url.startswith('wvmob='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 30
                    try:
                        url = base64.b64decode(url.split('wvmob=')[1]).decode('utf-8')
                        url = 'wvmob=' + url
                    except:
                        pass
                elif url.startswith('resolver1_tvshows='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver2_tvshows='):
                    title = '[B][COLOR lime]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver3_tvshows='):
                    title = '[B][COLOR skyblue]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver4_tvshows='):
                    title = '[B][COLOR mediumslateblue]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('onedrive='):
                    title = '[B][COLOR darkorange]●[/COLOR][/B] ' + title
                    mode_select = 31
                else:
                    continue
                addDir(title,url,mode_select,thumb,fanArt,info,'','')
                find_id = '1'
        if find_id == '0':
            notify('[B][COLOR gold]'+search+'[/COLOR] não encontrado![/B]')
            exit()
    except:
        pass

def pesquisar_novelas():
    try:
        link = ''
        url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x30\x37\x66\x31\x66\x34\x63\x64\x31\x62\x32\x30\x33\x63\x62\x66\x32\x65\x66\x65\x63\x39\x35\x39\x63\x34\x65\x38\x36\x34\x35\x61\x2f\x72\x61\x77\x2f\x6e\x6f\x76\x65\x6c\x61\x73\x2e\x78\x6d\x6c'
        try:
            if features_enable == 'true' and not features_pass == '':
                hashed_pw_verify = features_checker()
                if hashed_pw_verify:
                    url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass
        except:
            pass
        link = getMovieData(url)
        link = link.replace('\n','').replace('\r','')
        nome = re.compile('<name>(.*?)</name>.*?<externallink>(.*?)</externallink>.*?<thumbnail>(.*?)</thumbnail>.*?<fanart>(.*?)</fanart>.*?<info>(.*?)</info>').findall(link)
        find_id = '0'
        for title, url, thumb, fanArt, info in nome:
            title2 = title.replace('[B][COLOR white]','').replace('[COLOR gold]','').replace('[/COLOR][/B]','').replace('[/COLOR]','').replace('(','').replace(')','')
            title2 = search_clean(title2)
            title2 = re.sub(u"[àáâãäå]", 'a', title2)
            title2 = re.sub(u"[èéêë]", 'e', title2)
            title2 = re.sub(u"[ìíîï]", 'i', title2)
            title2 = re.sub(u"[òóôõö]", 'o', title2)
            title2 = re.sub(u"[ùúûü]", 'u', title2)
            title2 = re.sub(u"[ýÿ]", 'y', title2)
            title2 = re.sub(u"[ß]", 'ss', title2)
            title2 = re.sub(u"[ñ]", 'n', title2)
            title2 = re.sub(u"[&]", 'e', title2)
            title2 = title2.lower()
            if search in title2:
                try:
                    thumb = base64.b64decode(thumb).decode('utf-8')
                except:
                    pass
                if url.startswith('#novelas_list='):
                    title = '[B][COLOR white]●[/COLOR][/B] ' + title
                    mode_select = 27
                elif url.startswith('rede='):
                    url = url.replace('rede=','')
                    url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x65\x64\x65\x63\x61\x6e\x61\x69\x73\x2e\x63\x78\x2f\x62\x72\x6f\x77\x73\x65\x2d' + url + '\x2d\x76\x69\x64\x65\x6f\x73\x2d\x31\x2d\x64\x61\x74\x65\x2e\x68\x74\x6d\x6c'
                    title = '[B][COLOR red]●[/COLOR][/B] ' + title
                    mode_select = 7
                elif url.startswith('novelas='):
                    title = '[B][COLOR gold]●[/COLOR][/B] ' + title
                    mode_select = 25
                elif url.startswith('novelas2='):
                    title = '[B][COLOR blue]●[/COLOR][/B] ' + title
                    mode_select = 25
                elif url.startswith('resolver1_tvshows='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver3_tvshows='):
                    title = '[B][COLOR skyblue]●[/COLOR][/B] ' + title
                    mode_select = 31
                else:
                    continue
                addDir(title.encode('utf-8'),url,mode_select,thumb,fanArt,info,'','')
                find_id = '1'
        if find_id == '0':
            notify('[B][COLOR gold]'+search+'[/COLOR] não encontrado![/B]')
            exit()
    except:
        pass

def pesquisar_animes():
    try:
        link = ''
        url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x41\x6e\x69\x6d\x65\x73\x42\x61\x73\x65'
        link = getMovieData(url)
        link = link.replace('\n','').replace('\r','')
        nome = re.compile('<name>(.*?)</name>.*?<externallink>(.*?)</externallink>.*?<thumbnail>(.*?)</thumbnail>.*?<info>(.*?)</info>').findall(link)
        find_id = '0'
        for title, url, thumb, info in nome:
            title2 = title.replace('[B][COLOR white]','').replace('[COLOR gold]','').replace('[/COLOR][/B]','').replace('[/COLOR]','').replace('(','').replace(')','')
            title2 = search_clean(title2)
            title2 = re.sub(u"[àáâãäå]", 'a', title2)
            title2 = re.sub(u"[èéêë]", 'e', title2)
            title2 = re.sub(u"[ìíîï]", 'i', title2)
            title2 = re.sub(u"[òóôõö]", 'o', title2)
            title2 = re.sub(u"[ùúûü]", 'u', title2)
            title2 = re.sub(u"[ýÿ]", 'y', title2)
            title2 = re.sub(u"[ß]", 'ss', title2)
            title2 = re.sub(u"[ñ]", 'n', title2)
            title2 = re.sub(u"[&]", 'e', title2)
            title2 = title2.lower()
            if search in title2:
                try:
                    thumb = base64.b64decode(thumb).decode('utf-8')
                except:
                    pass
                if url.startswith('#animes_list='):
                    title = '[B][COLOR white]●[/COLOR][/B] ' + title
                    mode_select = 22
                elif url.startswith('animes1='):
                    title = '[B][COLOR blue]●[/COLOR][/B] ' + title
                    mode_select = 22
                elif url.startswith('animes2='):
                    title = '[B][COLOR red]●[/COLOR][/B] ' + title
                    mode_select = 22
                elif url.startswith('animes3='):
                    title = '[B][COLOR lime]●[/COLOR][/B] ' + title
                    mode_select = 22
                elif url.startswith('animes4='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 22
                elif url.startswith('animes5='):
                    title = '[B][COLOR gold]●[/COLOR][/B] ' + title
                    mode_select = 22
                elif url.startswith('animes6='):
                    title = '[B][COLOR darkorange]●[/COLOR][/B] ' + title
                    mode_select = 22
                else:
                    continue
                addDir(title,url,mode_select,thumb,fanart,info,'','')
                find_id = '1'
        if find_id == '0':
            notify('[B][COLOR gold]'+search+'[/COLOR] não encontrado![/B]')
            exit()
    except:
        pass

def pesquisar_doramas():
    try:
        link = ''
        url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x44\x6f\x72\x61\x6d\x61\x73\x42\x61\x73\x65'
        link = getMovieData(url)
        link = link.replace('\n','').replace('\r','')
        nome = re.compile('<name>(.*?)</name>.*?<externallink>(.*?)</externallink>.*?<thumbnail>(.*?)</thumbnail>.*?<fanart>(.*?)</fanart>.*?<info>(.*?)</info>').findall(link)
        find_id = '0'
        for title, url, thumb, fanart, info in nome:
            title2 = title.replace('[B][COLOR white]','').replace('[COLOR gold]','').replace('[/COLOR][/B]','').replace('[/COLOR]','').replace('(','').replace(')','')
            title2 = search_clean(title2)
            title2 = re.sub(u"[àáâãäå]", 'a', title2)
            title2 = re.sub(u"[èéêë]", 'e', title2)
            title2 = re.sub(u"[ìíîï]", 'i', title2)
            title2 = re.sub(u"[òóôõö]", 'o', title2)
            title2 = re.sub(u"[ùúûü]", 'u', title2)
            title2 = re.sub(u"[ýÿ]", 'y', title2)
            title2 = re.sub(u"[ß]", 'ss', title2)
            title2 = re.sub(u"[ñ]", 'n', title2)
            title2 = re.sub(u"[&]", 'e', title2)
            title2 = title2.lower()
            if search in title2:
                if url.startswith('#doramas_list='):
                    title = '[B][COLOR white]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('doramas_resolver1='):
                    title = '[B][COLOR gold]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver1_tvshows='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver3_tvshows='):
                    title = '[B][COLOR skyblue]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver4_tvshows='):
                    title = '[B][COLOR mediumslateblue]●[/COLOR][/B] ' + title
                    mode_select = 31
                else:
                    continue
                addDir(title,url,mode_select,thumb,fanart,info,'','')
                find_id = '1'
        if find_id == '0':
            notify('[B][COLOR gold]'+search+'[/COLOR] não encontrado![/B]')
            exit()
    except:
        pass

def pesquisar_desenhos():
    try:
        link = ''
        url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x44\x65\x73\x65\x6e\x68\x6f\x73\x42\x61\x73\x65'
        try:
            if features_enable == 'true' and not features_pass == '':
                hashed_pw_verify = features_checker()
                if hashed_pw_verify:
                    url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'des'
        except:
            pass
        link = getMovieData(url)
        link = link.replace('\n','').replace('\r','')
        nome = re.compile('<name>(.*?)</name>.*?<externallink>(.*?)</externallink>.*?<thumbnail>(.*?)</thumbnail>.*?<fanart>(.*?)</fanart>.*?<info>(.*?)</info>').findall(link)
        find_id = '0'
        for title, url, thumb, fanArt, info in nome:
            title2 = title.replace('[B][COLOR white]','').replace('[COLOR gold]','').replace('[/COLOR][/B]','').replace('[/COLOR]','').replace('(','').replace(')','')
            title2 = search_clean(title2)
            title2 = re.sub(u"[àáâãäå]", 'a', title2)
            title2 = re.sub(u"[èéêë]", 'e', title2)
            title2 = re.sub(u"[ìíîï]", 'i', title2)
            title2 = re.sub(u"[òóôõö]", 'o', title2)
            title2 = re.sub(u"[ùúûü]", 'u', title2)
            title2 = re.sub(u"[ýÿ]", 'y', title2)
            title2 = re.sub(u"[ß]", 'ss', title2)
            title2 = re.sub(u"[ñ]", 'n', title2)
            title2 = re.sub(u"[&]", 'e', title2)
            title2 = title2.lower()
            if search in title2:
                try:
                    thumb = base64.b64decode(thumb).decode('utf-8')
                except:
                    pass
                if thumb.startswith('serie='):
                    myid = base64.b64decode(thumb.split('serie=')[1]).decode('utf-8')
                    thumb = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x70\x6f\x73\x74\x65\x72\x50\x74\x2f\x33\x34\x32\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                    fanArt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2f\x31\x32\x38\x30\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                if fanArt.startswith('serie='):
                    myid = base64.b64decode(fanArt.split('serie=')[1]).decode('utf-8')
                    fanArt = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x63\x6f\x6e\x74\x65\x6e\x74\x2f\x73\x65\x72\x69\x65\x73\x2f\x62\x61\x63\x6b\x67\x72\x6f\x75\x6e\x64\x2f\x31\x32\x38\x30\x2f\x25\x73\x2e\x77\x65\x62\x70'%myid
                if not fanArt:
                    fanArt = fanart
                if url.startswith('#series_list='):
                    title = '[B][COLOR white]●[/COLOR][/B] ' + title
                    mode_select = 27
                elif url.startswith('rede='):
                    url = url.replace('rede=','')
                    url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x65\x64\x65\x63\x61\x6e\x61\x69\x73\x2e\x63\x78\x2f\x62\x72\x6f\x77\x73\x65\x2d' + url + '\x2d\x76\x69\x64\x65\x6f\x73\x2d\x31\x2d\x64\x61\x74\x65\x2e\x68\x74\x6d\x6c'
                    title = '[B][COLOR red]●[/COLOR][/B] ' + title
                    mode_select = 7
                elif url.startswith('serie2='):
                    title = '[B][COLOR blue]●[/COLOR][/B] ' + title
                    mode_select = 26
                elif url.startswith('serie3='):
                    title = '[B][COLOR dodgerblue]●[/COLOR][/B] ' + title
                    mode_select = 26
                elif url.startswith('ntcdn_tvshows='): #Reservado
                    title = '[B][COLOR orangered]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('seriecdn='):
                    title = '[B][COLOR orange]●[/COLOR][/B] ' + title
                    mode_select = 26
                elif url.startswith('tseries='):
                    title = '[B][COLOR gold]●[/COLOR][/B] ' + title
                    mode_select = 24
                elif url.startswith('serie='):
                    title = '[B][COLOR red]●[/COLOR][/B] ' + title
                    mode_select = 23
                    try:
                        url = base64.b64decode(url.split('serie=')[1]).decode('utf-8')
                        url = 'serie=' + url
                    except:
                        pass
                elif url.startswith('sfserie='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 29
                    try:
                        url = base64.b64decode(url.split('sfserie=')[1]).decode('utf-8')
                        url = 'sfserie=' + url
                    except:
                        pass
                elif url.startswith('wvmob='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 30
                    try:
                        url = base64.b64decode(url.split('wvmob=')[1]).decode('utf-8')
                        url = 'wvmob=' + url
                    except:
                        pass
                elif url.startswith('resolver1_tvshows='):
                    title = '[B][COLOR yellow]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver2_tvshows='):
                    title = '[B][COLOR lime]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver3_tvshows='):
                    title = '[B][COLOR skyblue]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('resolver4_tvshows='):
                    title = '[B][COLOR mediumslateblue]●[/COLOR][/B] ' + title
                    mode_select = 31
                elif url.startswith('onedrive='):
                    title = '[B][COLOR darkorange]●[/COLOR][/B] ' + title
                    mode_select = 31
                else:
                    continue
                addDir(title,url,mode_select,thumb,fanArt,info,'','')
                find_id = '1'
        if find_id == '0':
            notify('[B][COLOR gold]'+search+'[/COLOR] não encontrado![/B]')
            exit()
    except:
        pass

from unicodedata import normalize

def remover_acentos(txt, codif='utf-8'):
    return normalize('NFKD', txt).encode('ascii', 'ignore')

def ascii(string):
    if isinstance(string, basestring):
        if isinstance(string, unicode):
           string = string.encode('ascii', 'ignore')
    return string
def uni(string, encoding = 'utf-8'):
    if isinstance(string, basestring):
        if not isinstance(string, unicode):
            string = unicode(string, encoding, 'ignore')
    return string
def removeNonAscii(s): return "".join(filter(lambda x: ord(x)<128, s))

class ProxyHTTPRequestHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.0'
    def do_GET(self, body=True):
        try:
            p = urlparse(self.path)
            q = dict(parse_qsl(p.query))
            req_headers = {'user-agent':useragent}
            if 'url' not in q:
                self.send_error(404)
                return
            u = q['url']
            with create_retry_session() as s:
                if 'Referer' in q:
                    if 'stream-' in q['Referer']:
                        req_headers = wvmob_req(u,q['Referer'],q['User-Agent'])
                    else:
                        req_headers.update({'referer':q['Referer']})
                else:
                    req_headers.update({'referer':u})
                res = s.get(u, headers=req_headers, timeout=5)
                if 'audio/aac' in u and '.ts' in u:
                    self.send_header('Content-Type', 'video/mp2t')
                    self.send_header('user-agent', useragent)
                    self.send_header('referer', req_headers['referer'])
                    if six.PY3: self.end_headers()
                    self.wfile.write(res.content)
                    return
                elif 'audio/aac' in u and not '.ts' in u:
                    res = res.text
                    stream_lang = re.compile('(.+\/).+.m3u8').findall(u)[0]
                    stream = re.compile('EXTINF.+\n(.+).ts', re.IGNORECASE).findall(res)
                    for rep in stream:
                        res = res.replace(rep,'http://127.0.0.1:55333/?url=' + stream_lang + rep)
                    self.send_header('Content-Type', 'video/mp2t')
                    self.send_header('user-agent', useragent)
                    self.send_header('referer', req_headers['referer'])
                    if six.PY3: self.end_headers()
                    self.wfile.write(bytes(res,'utf-8'))
                    return
                else:
                    self.send_header('Content-Type', 'video/mp2t')
                    self.send_header('user-agent', useragent)
                    self.send_header('referer', req_headers['referer'])
                    if six.PY3: self.end_headers()
                    self.wfile.write(res.content[8:])
                    return
        finally:
            self.finish()

def start_hls():
    try:
        server_address = ('127.0.0.1', 55333)
        httpd = HTTPServer(server_address, ProxyHTTPRequestHandler)
        server_thread = threading.Thread(target=httpd.serve_forever)
        server_thread.start()
        monitor = xbmc.Monitor()
        while not monitor.waitForAbort(3):
            pass
        httpd.shutdown()
        server_thread.join()
    except:
        pass

def sendJSON(command):
    data = ''
    try:
        data = xbmc.executeJSONRPC(uni(command))
    except UnicodeEncodeError:
        data = xbmc.executeJSONRPC(ascii(command))

    return uni(data)


def pluginquerybyJSON(url):
    json_query = uni('{"jsonrpc":"2.0","method":"Files.GetDirectory","params":{"directory":"%s","media":"video","properties":["thumbnail","title","year","dateadded","fanart","rating","season","episode","studio"]},"id":1}') %url

    json_folder_detail = json.loads(sendJSON(json_query))
    for i in json_folder_detail['result']['files'] :
        url = i['file']
        name = removeNonAscii(i['label'])
        thumbnail = removeNonAscii(i['thumbnail'])
        try:
            fanart = removeNonAscii(i['fanart'])
        except Exception:
            fanart = ''
        try:
            date = i['year']
        except Exception:
            date = ''
        try:
            episode = i['episode']
            season = i['season']
            if episode == -1 or season == -1:
                description = ''
            else:
                description = '[COLOR yellow] S' + str(season)+'[/COLOR][COLOR hotpink] E' + str(episode) +'[/COLOR]'
        except Exception:
            description = ''
        try:
            studio = i['studio']
            if studio:
                description += '\n Studio:[COLOR steelblue] ' + studio[0] + '[/COLOR]'
        except Exception:
            studio = ''

        desc = description+'\n\nDate: '+str(date)

        if i['filetype'] == 'file':
            #addLink(url,name,thumbnail,fanart,description,'',date,'',None,'',total=len(json_folder_detail['result']['files']))
            addLink(name.encode('utf-8', 'ignore'),url.encode('utf-8'),'',thumbnail,fanart,desc,'','')
            #xbmc.executebuiltin("Container.SetViewMode(500)")

        else:
            #addDir(name,url,53,thumbnail,fanart,description,'',date,'')
            addDir(name.encode('utf-8', 'ignore'),url.encode('utf-8'),6,iconimage,fanart,desc,'','')
            #xbmc.executebuiltin("Container.SetViewMode(500)")

def getFavorites(fav_opt=0,choose=False):
    try:
        try:
            items = json.loads(open(favorites, 'r', encoding='utf-8').read())
        except:
            items = ''
        if isinstance(items, list):
            items = {'unknown': items}
            b = open(favorites, "w", encoding="utf-8")
            if six.PY3: b.write(json.dumps(items))
            if six.PY2: b.write(json.dumps(items).decode('utf-8'))
        total = len(items)
        if total < 1:
            xbmcplugin.endOfDirectory(addon_handle,cacheToDisc=False)
        filmes,animes,series,doramas,desenhos,novelas,unknown,canais = [],[],[],[],[],[],[],[]
        if int(total) > 0:
            for key, values in items.items():
                for i in values:
                    name = i[0]
                    url = i[1]
                    try:
                        urldecode = base64.b64decode(base64.b16decode(url))
                    except:
                        urldecode = url
                    try:
                        url2 = urldecode.decode('utf-8')
                    except:
                        url2 = urldecode
                    mode = i[2]
                    subtitle = i[3]
                    try:
                        subtitledecode = base64.b64decode(base64.b16decode(subtitle))
                    except:
                        subtitledecode = subtitle
                    try:
                        sub2 = subtitledecode.decode('utf-8')
                    except:
                        sub2 = subtitledecode
                    iconimage = i[4]
                    try:
                        fanArt = i[5]
                        if fanArt == None:
                            raise
                    except:
                        if addon.getSetting('use_thumb') == "true":
                            fanArt = iconimage
                        else:
                            fanArt = fanart
                    description = i[6]
                    mode_links = int('16')
                    if mode == '0':
                        mode_links = int(mode[1:])
                        mode = 0
                    mode_links = int(mode_links)
                    mode = int(mode)
                    if key == 'filmes':
                        filmes.append((name,url2,mode,iconimage,fanArt,description,'',''))
                    elif key == 'animes':
                        animes.append((name,url2,mode,iconimage,fanArt,description,'',''))
                    elif key == 'series':
                        series.append((name,url2,mode,iconimage,fanArt,description,'',''))
                    elif key == 'doramas':
                        doramas.append((name,url2,mode,iconimage,fanArt,description,'',''))
                    elif key == 'desenhos':
                        desenhos.append((name,url2,mode,iconimage,fanArt,description,'',''))
                    elif key == 'novelas':
                        novelas.append((name,url2,mode,iconimage,fanArt,description,'',''))
                    elif key == 'unknown':
                        unknown.append((name,url2,mode,iconimage,fanArt,description,'',''))
                    elif key == 'canais':
                        canais.append((name,url2,mode,iconimage,fanArt,description,'',''))
                    elif fav_opt:
                        pass
                    elif mode == 0:
                        try:
                            addLink(name.encode('utf-8', 'ignore'),url2,mode_links,iconimage,fanArt,description,'','')
                        except:
                            pass
                    elif mode == 11 or mode == 16:
                        try:
                            addLink(name.encode('utf-8', 'ignore'),url2,mode,iconimage,fanArt,description,'','')
                        except:
                            pass
                    elif mode > 0 and mode < 7:
                        try:
                            addDir(name.encode('utf-8', 'ignore'),url2,mode,iconimage,fanArt,description,'','')
                        except:
                            pass
                    else:
                        try:
                            addDir(name.encode('utf-8', 'ignore'),url2,mode,iconimage,fanArt,description,'','')
                        except:
                            pass
            if fav_opt:
                pattern = '\[COLOR white\]([^●].+?)\[\/COLOR\]'
                pattern_ch = '\[B\]([^●].+?)\[\/B]'
                if choose == 'filmes':
                    filmes.sort(key=lambda x: re.findall(pattern,x[0])[0])
                    for item in filmes:
                        if item[2] == 16:
                            addLink(*item)
                        else:
                            addDir(*item)
                elif choose == 'animes':
                    animes.sort(key=lambda x: re.findall(pattern,x[0])[0])
                    for item in animes:
                        addDir(*item)
                elif choose == 'series':
                    series.sort(key=lambda x: re.findall(pattern,x[0])[0])
                    for item in series:
                        addDir(*item)
                elif choose == 'doramas':
                    doramas.sort(key=lambda x: re.findall(pattern,x[0])[0])
                    for item in doramas:
                        addDir(*item)
                elif choose == 'desenhos':
                    desenhos.sort(key=lambda x: re.findall(pattern,x[0])[0])
                    for item in desenhos:
                        addDir(*item)
                elif choose == 'novelas':
                    novelas.sort(key=lambda x: re.findall(pattern,x[0])[0])
                    for item in novelas:
                        addDir(*item)
                elif choose == 'unknown':
                    unknown.sort(key=lambda x: re.findall(pattern,x[0])[0])
                    for item in unknown:
                        addDir(*item)
                elif choose == 'canais':
                    canais.sort(key=lambda x: re.findall(pattern_ch,x[0])[0])
                    for item in canais:
                        if item[2] == 16 or item[2] == 11:
                            addLink(*item)
                        else:
                            addDir(*item)
            else:
                if animes:
                    addDir('[B][COLOR gold]●[/COLOR] [COLOR white]ANIMES[/COLOR][/B]','animes',15,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x67\x79\x68\x49\x34\x43\x62\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x32\x74\x36\x4e\x37\x75\x6b\x2e\x6a\x70\x67','[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, movemos seus animes favoritos para uma única categoria.[/COLOR][/B]','','')
                if desenhos:
                    addDir('[B][COLOR gold]●[/COLOR] [COLOR white]DESENHOS[/COLOR][/B]','desenhos',15,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x58\x61\x74\x4d\x69\x6b\x4f\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x58\x32\x47\x4d\x33\x54\x68\x2e\x6a\x70\x67','[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, movemos seus desenhos favoritos para uma única categoria.[/COLOR][/B]','','')
                if doramas:
                    addDir('[B][COLOR gold]●[/COLOR] [COLOR white]DORAMAS[/COLOR][/B]','doramas',15,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x41\x63\x72\x6b\x5a\x6e\x45\x2e\x70\x6e\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x6d\x61\x67\x65\x2e\x74\x6d\x64\x62\x2e\x6f\x72\x67\x2f\x74\x2f\x70\x2f\x6f\x72\x69\x67\x69\x6e\x61\x6c\x2f\x37\x42\x6f\x52\x68\x67\x38\x7a\x58\x50\x30\x63\x61\x39\x5a\x71\x6c\x34\x70\x38\x6c\x6c\x43\x46\x52\x32\x50\x2e\x6a\x70\x67','[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, movemos seus doramas favoritos para uma única categoria.[/COLOR][/B]','','')
                if filmes:
                    addDir('[B][COLOR gold]●[/COLOR] [COLOR white]FILMES[/COLOR][/B]','filmes',15,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x64\x31\x31\x79\x37\x33\x73\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x6a\x77\x72\x31\x51\x37\x50\x2e\x6a\x70\x67','[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, movemos seus filmes favoritos para uma única categoria.[/COLOR][/B]','','')
                if novelas:
                    addDir('[B][COLOR gold]●[/COLOR] [COLOR white]NOVELAS[/COLOR][/B]','novelas',15,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x6e\x4a\x31\x48\x47\x71\x57\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x6f\x56\x56\x49\x39\x37\x55\x2e\x6a\x70\x67','[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, movemos suas novelas favoritas para uma única categoria.[/COLOR][/B]','','')
                if series:
                    addDir('[B][COLOR gold]●[/COLOR] [COLOR white]SÉRIES[/COLOR][/B]','series',15,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x43\x54\x69\x79\x65\x35\x6f\x2e\x6a\x70\x67','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x71\x49\x47\x59\x55\x77\x53\x2e\x6a\x70\x67','[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, movemos suas séries favoritas para uma única categoria.[/COLOR][/B]','','')
                if unknown:
                    addDir('[B][COLOR gold]●[/COLOR] [COLOR white]DESCONHECIDOS[/COLOR][/B]','unknown',15,'https://i.imgur.com/eY2nDV1.png','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x69\x2e\x69\x6d\x67\x75\x72\x2e\x63\x6f\x6d\x2f\x71\x49\x47\x59\x55\x77\x53\x2e\x6a\x70\x67','[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, movemos seus os favoritos para uma única categoria.[/COLOR][/B]','','')
                if canais:
                    addDir('[B][COLOR gold]●[/COLOR] [COLOR white]TV AO VIVO[/COLOR][/B]','canais',15,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR gold]●[/COLOR] [COLOR white]Para uma melhor organização, movemos seus canais favoritos para uma única categoria.[/COLOR][/B]','','')
            xbmcplugin.setContent(addon_handle, 'movies')
            xbmcplugin.endOfDirectory(addon_handle)
            monitor_switch()
            xbmc.executebuiltin('Container.SetViewMode(54)')
        else:
            notify('[B]Não há favoritos![/B]',500)
            exit()
    except:
        exit()

def update_dict_favorite(old_dict, new_dict):
    if isinstance(old_dict, list):
        old_dict = {'unknown': old_dict}
    for key, value in new_dict.items():
        if key in old_dict:
            old_dict[key].extend([value])
        else:
            old_dict[key] = [value]
    return old_dict

def addFavorite(name,url,fav_mode,subtitle,iconimage,fanart,description):
    favList = {}
    if os.path.exists(favorites)==False:
        addonID = xbmcaddon.Addon().getAddonInfo('id')
        addon_data_path = translate(os.path.join('special://home/userdata/addon_data', addonID))
        if os.path.exists(addon_data_path)==False:
            os.mkdir(addon_data_path)
        xbmc.sleep(7)
        favList = {content_status['active_menu']: [(name,url,fav_mode,subtitle,iconimage,fanart,description)]}
        a = open(favorites, "w", encoding="utf-8")
        if six.PY3: a.write(json.dumps(favList))
        if six.PY2: a.write(json.dumps(favList).decode('utf-8'))
        a.close()
        notify('[B]Adicionado aos Favoritos![/B]',500)
        #xbmc.executebuiltin("XBMC.Container.Refresh")
    else:
        a = open(favorites, 'r', encoding='utf-8').read()
        data = json.loads(a)
        data = update_dict_favorite(data,{content_status['active_menu']: (name,url,fav_mode,subtitle,iconimage,fanart,description)})
        b = open(favorites, "w", encoding="utf-8")
        if six.PY3: b.write(json.dumps(data))
        if six.PY2: b.write(json.dumps(data).decode('utf-8'))
        b.close()
        notify('[B]Adicionado aos Favoritos![/B]',500)
    #xbmc.executebuiltin("Container.Refresh")

def rmFavorite(name):
    data = json.loads(open(favorites, 'r', encoding='utf-8').read())
    for key,values in data.items():
        if key == content_status['active_menu']:
            for index,value in enumerate(values):
                if value[0]==name:
                    del values[index]
                    b = open(favorites, "w", encoding="utf-8")
                    if six.PY3: b.write(json.dumps(data))
                    if six.PY2: b.write(json.dumps(data).decode('utf-8'))
                    b.close()
                    break
    xbmc.executebuiltin("Container.Refresh")
    notify('[B]Favorito removido![/B]',500)

def addDir(name,url,mode,iconimage,fanart,description,genre,date,folder=True):
    if six.PY2:
        name = name.encode('utf-8','ignore')
        if not isinstance(url, list):
            url = url.encode('utf-8','ignore')
        iconimage = iconimage.encode('utf-8','ignore')
        fanart = fanart.encode('utf-8','ignore')
    if mode == 1:
        if url > '':
            u=sys.argv[0]+"?url="+urllib.quote_plus(base64.b16encode(base64.b64encode(url.encode('utf-8'))))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(str(description))
        else:
            u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(5)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(str(description))
    else:
        u=sys.argv[0]+"?url="+urllib.quote_plus(str(url))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(str(description))
    li=xbmcgui.ListItem(name)
    if date == '':
        date = None
    else:
        description += '\n\nDate: %s' %date
    li.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    if int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0]) > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setMediaType('video')
        info.setPlot(description)
        if genre:
            info.setGenres([genre])
        if date:
            info.setDateAdded(date)
            try:
                date = int(date)
                info.setYear(date)
            except:
                pass
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
        if genre:
            li.setInfo('video', { 'genre': genre })
        if date:
            li.setInfo('video', { 'dateadded': date })
            try:
                date = int(date)
                li.setInfo('video', { 'year': date })
            except:
                pass
    try:
        name_decode = name.decode('utf-8')
    except:
        name_decode = name
    try:
        name_fav = json.dumps(name_decode)
    except:
        name_fav =  name_decode
    try:
        url_fav = urllib.quote_plus(base64.b16encode(base64.b64encode(url.encode('utf-8'))))
    except:
        pass
    try:
        contextMenu = []
        ignore = ['#menu_canais','#desenhos_menu','#doramas_menu','#animes_menu','#novelas_menu','#filmes_menu','#series_menu']
        ignore_mode = [4,8,9,10,12,15]
        if favoritos == 'true' and not any(x in url for x in ignore) and not any(x == mode for x in ignore_mode):
            if name_fav in FAV and '"'+url_fav+'"' in FAV:
                contextMenu.append(('[B][COLOR firebrick]-[/COLOR] FAVORITOS[/B]','RunPlugin(%s?mode=14&name=%s)'%(sys.argv[0], urllib.quote_plus(name))))
            else:
                fav_params = ('%s?mode=13&name=%s&url=%s&subtitle=%s&iconimage=%s&fanart=%s&description=%s&fav_mode=%s'%(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(base64.b16encode(base64.b64encode(url.encode('utf-8')))), '', urllib.quote_plus(iconimage), urllib.quote_plus(fanart), urllib.quote_plus(str(description)), str(mode)))
                contextMenu.append(('[B][COLOR lime]+[/COLOR] FAVORITOS[/B]','RunPlugin(%s)' %fav_params))
        #contextMenu.append(('Informação', 'RunPlugin(%s?mode=19&name=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(description))))
        li.addContextMenuItems(contextMenu)
    except:
        pass
    xbmcplugin.addDirectoryItem(handle=addon_handle,url=u,listitem=li, isFolder=folder)

def addLink(name,url,mode,iconimage,fanart,description,genre,date,folder=False):
    if six.PY2:
        name = name.encode('utf-8','ignore')
        if not isinstance(url, list):
            url = url.encode('utf-8','ignore')
        iconimage = iconimage.encode('utf-8','ignore')
        fanart = fanart.encode('utf-8','ignore')
    if mode > 1:
        u=sys.argv[0]+"?url="+urllib.quote_plus(str(url))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(str(description))
    else:
        u=url
    if date == '':
        date = None
    else:
        description += '\n\nDate: %s' %date
    if iconimage > '':
        thumbnail = iconimage
    else:
        thumbnail = 'DefaultVideo.png'
    li=xbmcgui.ListItem(name)
    li.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    if int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0]) > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setMediaType('video')
        info.setPlot(description)
        if genre:
            info.setGenres([genre])
        if date:
            info.setDateAdded(date)
            try:
                date = int(date)
                info.setYear(date)
            except:
                pass
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
        if genre:
            li.setInfo('video', { 'genre': genre })
        if date:
            li.setInfo('video', { 'dateadded': date })
            try:
                date = int(date)
                li.setInfo('video', { 'year': date })
            except:
                pass
    if mode == 11 or url == 'here':
        li.setProperty('IsPlayable', 'false')
    else:
        li.setProperty('IsPlayable', 'true')
    try:
        name_fav = json.dumps(name)
    except:
        name_fav = name
    name2_fav = name
    desc_fav = description
    try:
        name_decode = name.decode('utf-8')
    except:
        name_decode = name
    try:
        name_fav = json.dumps(name_decode)
    except:
        name_fav =  name_decode
    try:
        contextMenu = []
        if favoritos == 'true' and mode == 16 and (content_status['active_menu'] == 'filmes') or (content_status['active_menu'] == 'canais'):
            if name_fav in FAV:
                contextMenu.append(('[B][COLOR firebrick]-[/COLOR] FAVORITOS[/B]','RunPlugin(%s?mode=14&name=%s)'%(sys.argv[0], urllib.quote_plus(name))))
            else:
                fav_params = ('%s?mode=13&name=%s&url=%s&subtitle=%s&iconimage=%s&fanart=%s&description=%s&fav_mode=0%s'%(sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(base64.b16encode(base64.b64encode(url.encode('utf-8')))), '', urllib.quote_plus(iconimage), urllib.quote_plus(fanart), urllib.quote_plus(str(description)), str(mode)))
                contextMenu.append(('[B][COLOR lime]+[/COLOR] FAVORITOS[/B]','RunPlugin(%s)' %fav_params))
        #contextMenu.append(('Informação', 'RunPlugin(%s?mode=19&name=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(description))))
        if url.startswith('watch_later='):
            contextMenu.append(('[B][COLOR gold]- Apagar Episódio[/COLOR][/B]', 'RunPlugin(%s?mode=17&name=%s&url=%s&iconimage=%s&fanart=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(base64.b16encode(base64.b64encode(url.encode('utf-8')))), urllib.quote_plus(iconimage), urllib.quote_plus(fanart), urllib.quote_plus(str(description)))))
        elif any(host in url for host in watch_later_approved['episodes']):
            contextMenu.append(('[B][COLOR gold]+ Baixar Episódio[/COLOR][/B]', 'RunPlugin(%s?mode=17&name=%s&url=%s&iconimage=%s&fanart=%s&description=%s)' % (sys.argv[0], urllib.quote_plus(name), urllib.quote_plus(base64.b16encode(base64.b64encode(url.encode('utf-8')))), urllib.quote_plus(iconimage), urllib.quote_plus(fanart), urllib.quote_plus(str(description)))))
        li.addContextMenuItems(contextMenu)
    except:
        pass
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=li, isFolder=folder)

def parental_password():
    try:
        addonID = xbmcaddon.Addon().getAddonInfo('id')
        addon_data_path = translate(os.path.join('special://home/userdata/addon_data', addonID))
        if os.path.exists(addon_data_path)==False:
            os.mkdir(addon_data_path)
        xbmc.sleep(7)
        #Path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode("utf-8")
        #arquivo = os.path.join(Path, "password.txt")
        arquivo = os.path.join(addon_data_path, "pass.txt")
        exists = os.path.isfile(arquivo)
        if exists == False:
            password = '0000'
            p_encoded = base64.b64encode(password.encode()).decode('utf-8')
            p_file = open(arquivo,'w', encoding='utf-8')
            p_file.write(p_encoded)
            p_file.close()
    except:
        pass

def contador():
    try:
        versao_report = urllib.quote_plus('VXVULGO PLAY {} {} - Update {}'.format('Omega' if six.PY3 else 'Leia', addon_version, versao))
        response = getMovieData('https://whos.amung.us/pingjs/?k=brplayrepodl&t=%s'%versao_report, 'https://www.youtube.com/', head=True, timeout=5, cache=False, retry=False)
    except:
        pass
contador()

def siteoficial():
    import xbmc
    import webbrowser
    host = 'https://bit.ly/BRPLAYREPODL'
    android_action = 'StartAndroidActivity(,android.intent.action.VIEW,,%s)'
    if xbmc.getCondVisibility('system.platform.windows'):
        webbrowser.open(host)
    if xbmc.getCondVisibility('system.platform.android'):
        xbmc.executebuiltin(android_action%(host))

def check_internet():
    import socket
    try:
        conn = socket.create_connection(("8.8.8.8", 53), timeout=5)
        conn.close()
        return True
    except (OSError, IOError):
        return False

def SaveToFolder(path, filename, source):
    try:
        py = os.path.join(path, filename)
        with open(py, "w", encoding="utf-8") as file:
            file.write(source.decode("utf-8") if isinstance(source, bytes) else source)
    except Exception as e:
        pass

def get_gist_files(url):
    try:
        """
        Retorna apenas filename e content dos arquivos de um Gist.
        """
        headers = {
            "Accept": "application/vnd.github+json"
        }
        response = getMovieData(url, replace_headers=headers)
        gist_json = json.loads(response)
        files = []
        for filename, fileinfo in gist_json["files"].items():
            files.append({
                "filename": filename,
                "content": fileinfo.get("content", "")
            })
        return files
    except Exception as e:
        return {}

def proxied_update(url):
    try:
        list_url = ['\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x67\x69\x73\x74\x3f\x70\x61\x74\x68\x3d\x25\x73', '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x25\x73']
        errors = ['Erro ao decodificar resposta do Gist', 'Arquivo não encontrado', 'Formato inválido' , 'Token não configurado no servidor']
        for host_seek in list_url:
            response_proxied = '\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76' in host_seek
            if response_proxied:
                url = url.replace('/raw/', '/')
            response = getMovieData(host_seek%url)
            if response and response_proxied:
                response_match = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(response)
                response_match = response_match[0] if response_match else ''
                try:
                    response = base64.b64decode(response_match.encode('utf-8')).decode('utf-8')
                except:
                    pass
            if response:
                return response
        return ''
    except:
        pass

def CheckUpdate():
    try:
        update_servers = ['\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x75\x70\x64\x61\x74\x65\x2e\x6a\x73\x6f\x6e','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x70\x69\x2e\x67\x69\x74\x68\x75\x62\x2e\x63\x6f\x6d\x2f\x67\x69\x73\x74\x73\x2f\x66\x35\x65\x36\x38\x36\x39\x37\x63\x31\x65\x66\x38\x39\x35\x61\x39\x38\x36\x64\x30\x34\x36\x32\x38\x36\x65\x61\x62\x33\x35\x35']
        for host in update_servers:
            response = getMovieData(host) if not '\x61\x70\x69\x2e\x67\x69\x74\x68\x75\x62\x2e\x63\x6f\x6d' in host else get_gist_files(host)
            json_files = json.loads(response) if not '\x61\x70\x69\x2e\x67\x69\x74\x68\x75\x62\x2e\x63\x6f\x6d' in host else response
            version_diff = next(
                (item["content"] for item in json_files if item["filename"] == "default.py"),
                None  # valor padrão se não encontrar
            )
            uversao = next(
                (item["content"] for item in json_files if item["filename"] == "version_matrix.txt"),
                None  # valor padrão se não encontrar
            )
            uversao = str(uversao).replace(' ', '').replace('\n', '').replace('\r', '')
            version_diff = ('#version %s'%uversao in version_diff) or not ('#version' in version_diff)
            if (versao != uversao) and (version_diff):
                Update()
                break
    except:
        xbmc.executebuiltin("Notification([B][COLOR gold]CHECK UPDATE FAIL![/COLOR][/B], [COLOR white][B]Atualização indisponível no momento.[/COLOR][/B]"+",5000,"+icon+")")
        if xbmcgui.Dialog().yesno(addon_name, '[B][COLOR white]Baixar o Update manualmente?[CR][CR]Houve um erro ao tentar atualizar automáticamente, verifique sua conexão ou horário do sistema.[/COLOR][/B]'):
            siteoficial()
            exit()
        else:
            exit()

def Update():
    try:
        update_servers = ['\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x75\x70\x64\x61\x74\x65\x2e\x6a\x73\x6f\x6e','\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x70\x69\x2e\x67\x69\x74\x68\x75\x62\x2e\x63\x6f\x6d\x2f\x67\x69\x73\x74\x73\x2f\x66\x35\x65\x36\x38\x36\x39\x37\x63\x31\x65\x66\x38\x39\x35\x61\x39\x38\x36\x64\x30\x34\x36\x32\x38\x36\x65\x61\x62\x33\x35\x35']
        for host in update_servers:
            response = getMovieData(host) if not '\x61\x70\x69\x2e\x67\x69\x74\x68\x75\x62\x2e\x63\x6f\x6d' in host else get_gist_files(host)
            json_files = json.loads(response) if not '\x61\x70\x69\x2e\x67\x69\x74\x68\x75\x62\x2e\x63\x6f\x6d' in host else response
            update_list = {
                'database.py': 'database.py',
                'downloader.py': 'downloader.py',
                'jsunpack.py': 'jsunpack.py',
                'jsunhunt.py': 'jsunhunt.py',
                'extract.py': 'extract.py',
                'codec.py': 'codec.py',
                'default.py': 'default.py',
                'settings_matrix.xml' if six.PY3 else 'settings.xml': 'resources/settings.xml',
                'addon_matrix.xml' if six.PY3 else 'addon.xml': 'addon.xml'
            }
            for item in json_files:
                filename, content = item['filename'], item['content']
                if filename in update_list:
                    if ('checkintegrity23022021' in content) or (filename.endswith('.xml') and ('</addon>' in content) or ('</settings>' in content)):
                        SaveToFolder(home, update_list[filename], content)
        uversao = next(
            (item["content"] for item in json_files if item["filename"] == "version_matrix.txt"),
            None  # valor padrão se não encontrar
        )
        if uversao:
            uversao = re.compile('[a-zA-Z\.\d]+').findall(uversao)[0]
            xbmc.executebuiltin("Notification([B][COLOR gold]Update "+uversao+"[/COLOR][/B], [B][COLOR white]Atualização concluída[/COLOR][/B]"+",5000,"+icon+")")
    except:
        xbmcgui.Dialog().ok(addon_name, "[COLOR white][B]Não foi possível atualizar no momento, tente mais tarde.[/COLOR][/B]")

def CheckPlugin():
    plugins = [
        ("jsunpack.py", "63423fd47519e9161221c9bcc9bcf427/raw/jsunpack.py"),
        ("codec.py", "63423fd47519e9161221c9bcc9bcf427/raw/codec.py"),
        ("jsunhunt.py", "63423fd47519e9161221c9bcc9bcf427/raw/jsunhunt.py")
    ]
    for filename, url in plugins:
        try:
            arquivo = os.path.join(home, filename)
            exists = os.path.isfile(arquivo)
            if exists == False:
                source = proxied_update(url)
                if 'checkintegrity23022021' in str(source):
                    py = os.path.join(home, filename)
                    file = open(py, "w", encoding="utf-8")
                    file.write(source)
                    file.close()
            elif filename == "jsunhunt.py":
                with open(arquivo, encoding='utf-8') as f:
                    content = f.read()
                    if not '#checkintegrity23022021' in content:
                        source = proxied_update(url)
                        if source:
                            py = os.path.join(home, filename)
                            file = open(py, "w", encoding="utf-8")
                            file.write(source)
                            file.close()
        except:
            pass
    try:
        Path = translate(os.path.join('special://home/userdata'))
        arquivo = os.path.join(Path, "advancedsettings.xml")
        exists = os.path.isfile(arquivo)
        if exists == False:
            base = '\x50\x47\x46\x6b\x64\x6d\x46\x75\x59\x32\x56\x6b\x63\x32\x56\x30\x64\x47\x6c\x75\x5a\x33\x4d\x2b\x43\x67\x6b\x38\x62\x47\x39\x6e\x62\x47\x56\x32\x5a\x57\x77\x2b\x4c\x54\x45\x38\x4c\x32\x78\x76\x5a\x32\x78\x6c\x64\x6d\x56\x73\x50\x67\x6f\x38\x4c\x32\x46\x6b\x64\x6d\x46\x75\x59\x32\x56\x6b\x63\x32\x56\x30\x64\x47\x6c\x75\x5a\x33\x4d\x2b'
            base = base64.b64decode(base).decode('utf-8')
            py = os.path.join(Path, "advancedsettings.xml")
            file = open(py, "w", encoding="utf-8")
            file.write(base)
            file.close()
    except:
        pass

def time_convert(timestamp):
    try:
        if timestamp > '':
            dt_object = datetime.fromtimestamp(int(timestamp))
            time_br = dt_object.strftime('%d/%m/%Y às %H:%M:%S')
            return str(time_br)
        else:
            valor = ''
            return valor
    except:
        valor = ''
        return valor

def NewsInfos():
    try:
        info_decode = '\x61\x48\x52\x30\x63\x48\x4d\x36\x4c\x79\x39\x69\x63\x6d\x46\x36\x64\x57\x4e\x68\x63\x47\x78\x68\x65\x53\x35\x6d\x62\x33\x4a\x31\x62\x57\x56\x70\x63\x6d\x39\x7a\x4c\x6d\x4e\x76\x62\x53\x39\x6f\x4f\x54\x41\x74\x62\x6d\x39\x30\x61\x57\x5a\x70\x59\x32\x46\x6a\x62\x32\x56\x7a'
        info_decode = base64.b64decode(info_decode).decode('utf-8')
        info = getMovieData(info_decode, timeout=5)
        if info.find('<matrix>True</matrix>') >= 0 or info.find('<matrix>true</matrix>') >= 0:
            infoget = re.compile('<msg_matrix>(.+?)<\/msg_matrix>').findall(info)[0]
            infonote = infoget.replace(',','.')
            notify('[B]'+infonote+'[/B]')
    except:
        pass

def donate_consider():
    try:
        show_msg = False
        if addon.getSetting("donate_consider"):
            now = (datetime.now()).strftime('%y%m%d')
            if addon.getSetting("donate_consider") <= now:
                show_msg = True
        elif not addon.getSetting("donate_consider"):
            show_msg = True
        import webbrowser
        android_action = 'StartAndroidActivity(,android.intent.action.VIEW,,%s)'
        if show_msg == True:
            if xbmcgui.Dialog().yesno('Considere fazer uma doação:', '[B]Você pode ajudar com uma pequena doação, [COLOR gray]é opcional podendo continuar utilizando sem fazer uma doação.[/COLOR][CR][CR][COLOR blue]●[/COLOR] [COLOR gold]Deseja contribuir?[/COLOR][/B]'):
                donatetext = '[B][COLOR white]DOAR COM[/COLOR] [COLOR gold]%s[/COLOR][/B]'
                dialog = xbmcgui.Dialog()
                donate = dialog.select(donatemsg, [donatetext%('MERCADO PAGO'), donatetext%('PAYPAL'), donatetext%('PICPAY')])
                if donate == 0:
                    donatetext = '[B][COLOR white]DOAR[/COLOR] [COLOR gold]%s[/COLOR][/B]'
                    dialog = xbmcgui.Dialog()
                    donate = dialog.select(donatemsg, [donatetext%('R$ %s')%value for value in range(5,31)])
                    if donate == 0:
                        valor = 'https://mpago.la/1vSohb3'
                        if xbmc.getCondVisibility('system.platform.windows'):#5
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#5
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 1:
                        valor = 'https://mpago.la/2BGTnJz'
                        if xbmc.getCondVisibility('system.platform.windows'):#6
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#6
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 2:
                        valor = 'https://mpago.la/1toxKcu'
                        if xbmc.getCondVisibility('system.platform.windows'):#7
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#7
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 3:
                        valor = 'https://mpago.la/1JuqwoC'
                        if xbmc.getCondVisibility('system.platform.windows'):#8
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#8
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 4:
                        valor = 'https://mpago.la/22M7EVK'
                        if xbmc.getCondVisibility('system.platform.windows'):#9
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#9
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 5:
                        valor = 'https://mpago.la/2SWsUSM'
                        if xbmc.getCondVisibility('system.platform.windows'):#10
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#10
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 6:
                        valor = 'https://mpago.la/27qTDPZ'
                        if xbmc.getCondVisibility('system.platform.windows'):#11
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#11
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 7:
                        valor = 'https://mpago.la/1qNwS7j'
                        if xbmc.getCondVisibility('system.platform.windows'):#12
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#12
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 8:
                        valor = 'https://mpago.la/2pzM3jH'
                        if xbmc.getCondVisibility('system.platform.windows'):#13
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#13
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 9:
                        valor = 'https://mpago.la/2jEKXum'
                        if xbmc.getCondVisibility('system.platform.windows'):#14
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#14
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 10:
                        valor = 'https://mpago.la/1gYaNa1'
                        if xbmc.getCondVisibility('system.platform.windows'):#15
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#15
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 11:
                        valor = 'https://mpago.la/2NJ57dY'
                        if xbmc.getCondVisibility('system.platform.windows'):#16
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#16
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 12:
                        valor = 'https://mpago.la/2StB4BU'
                        if xbmc.getCondVisibility('system.platform.windows'):#17
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#17
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 13:
                        valor = 'https://mpago.la/1Pqgz3y'
                        if xbmc.getCondVisibility('system.platform.windows'):#18
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#18
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 14:
                        valor = 'https://mpago.la/1jgLHZT'
                        if xbmc.getCondVisibility('system.platform.windows'):#19
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#19
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 15:
                        valor = 'https://mpago.la/1UowrWh'
                        if xbmc.getCondVisibility('system.platform.windows'):#20
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#20
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 16:
                        valor = 'https://mpago.la/2hym37i'
                        if xbmc.getCondVisibility('system.platform.windows'):#21
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#21
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 17:
                        valor = 'https://mpago.la/2NpkzNY'
                        if xbmc.getCondVisibility('system.platform.windows'):#22
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#22
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 18:
                        valor = 'https://mpago.la/1SdWshX'
                        if xbmc.getCondVisibility('system.platform.windows'):#23
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#23
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 19:
                        valor = 'https://mpago.la/2aPxuth'
                        if xbmc.getCondVisibility('system.platform.windows'):#24
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#24
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 20:
                        valor = 'https://mpago.la/2pYMak2'
                        if xbmc.getCondVisibility('system.platform.windows'):#25
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#25
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 21:
                        valor = 'https://mpago.la/2SbGnhu'
                        if xbmc.getCondVisibility('system.platform.windows'):#26
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#26
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 22:
                        valor = 'https://mpago.la/2mNZueg'
                        if xbmc.getCondVisibility('system.platform.windows'):#27
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#27
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 23:
                        valor = 'https://mpago.la/1Mdd1Gd'
                        if xbmc.getCondVisibility('system.platform.windows'):#28
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#28
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 24:
                        valor = 'https://mpago.la/2fw9M2R'
                        if xbmc.getCondVisibility('system.platform.windows'):#29
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#29
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 25:
                        valor = 'https://mpago.la/1Bd4PLB'
                        if xbmc.getCondVisibility('system.platform.windows'):#30
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):#30
                            xbmc.executebuiltin(android_action%(valor))
                elif donate == 1:
                    donatetext = '[B][COLOR white]DOAR[/COLOR] [COLOR gold]%s[/COLOR][/B]'
                    dialog = xbmcgui.Dialog()
                    donate = dialog.select(donatemsg, [donatetext%('R$ REAIS'), donatetext%('USD DOLAR')])
                    if donate == 0:
                        valor = 'https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=WDBB7ADQCPJQE&item_name=Streamer+S.A&currency_code=BRL&source=url'
                        if xbmc.getCondVisibility('system.platform.windows'):
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):
                            xbmc.executebuiltin(android_action%(valor))
                    elif donate == 1:
                        valor = 'https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=WDBB7ADQCPJQE&item_name=Streamer+S.A&currency_code=USD&source=url'
                        if xbmc.getCondVisibility('system.platform.windows'):
                            webbrowser.open(valor)
                        elif xbmc.getCondVisibility('system.platform.android'):
                            xbmc.executebuiltin(android_action%(valor))
                elif donate == 2:
                    valor = 'https://app.picpay.com/user/vxvulgoplay'
                    if xbmc.getCondVisibility('system.platform.windows'):
                        webbrowser.open(valor)
                    if xbmc.getCondVisibility('system.platform.android'):
                        xbmc.executebuiltin(android_action%(valor))
                xbmcgui.Dialog().ok(addon_name, donatemsg)
                addon.setSetting("donate_consider", (datetime.now()+timedelta(days=31)).strftime('%y%m%d'))
            else:
                addon.setSetting("donate_consider", (datetime.now()+timedelta(days=31)).strftime('%y%m%d'))
    except:
        pass

def watch_later_checker():
    addonID = xbmcaddon.Addon().getAddonInfo('id')
    folder = translate(os.path.join('special://home/userdata/addon_data', addonID))
    filepath = os.path.join(folder, "watch_later.json")
    if os.path.exists(filepath):
        return True

def CHIndex():
    if watch_later_checker():
        addDir('[B][COLOR gold]●[/COLOR] [COLOR white]CONTEÚDOS BAIXADOS[/COLOR][/B]','',18,'https://i.imgur.com/eY2nDV1.png','','[B][COLOR blue]●[/COLOR] Baixe suas Séries favoritas para assistir quando quiser.[/B]','','')
    if favoritos == 'true':
        addDir('[B][COLOR gold]●[/COLOR] [COLOR white]FAVORITOS[/COLOR][/B]','',15,'https://i.imgur.com/eY2nDV1.png','','[B][COLOR blue]●[/COLOR] Adicione suas Séries favoritas para assistir quando quiser.[/B]','','')
    #Main Menu
    menu_list = [
        ('TV AO VIVO','#menu_canais',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg'),
        ('FILMES','#filmes_menu',27,'https://i.imgur.com/d11y73s.jpg','https://i.imgur.com/jwr1Q7P.jpg'),
        ('SÉRIES','#series_menu',27,'https://i.imgur.com/CTiye5o.jpg','https://i.imgur.com/qIGYUwS.jpg'),
        ('DESENHOS','#desenhos_menu',28,'https://i.imgur.com/XatMikO.jpg','https://i.imgur.com/X2GM3Th.jpg'),
        ('DORAMAS','#doramas_menu',31,'https://i.imgur.com/AcrkZnE.png','https://image.tmdb.org/t/p/original/7BoRhg8zXP0ca9Zql4p8llCFR2P.jpg'),
        ('ANIMES','#animes_menu',22,'https://i.imgur.com/gyhI4Cb.jpg','https://i.imgur.com/2t6N7uk.jpg'),
        ('NOVELAS','#novelas_menu',25,'https://i.imgur.com/nJ1HGqW.jpg','https://i.imgur.com/oVVI97U.jpg')
    ]
    hashed_pw_verify = False
    if features_enable == 'true' and not features_pass == '':
        hashed_pw_verify = features_checker()
    for title,url,mode,thumb,fanArt in menu_list:
        title = '[B][COLOR lime]●[/COLOR] [COLOR white]%s[/COLOR][/B]'%title
        try:
            if hashed_pw_verify:
                if '\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79' in url and '\x2f\x68\x36\x2d\x73\x65\x72\x69\x65\x73\x2d\x62\x61\x73\x65\x2e\x78\x6d\x6c' in url:
                    title = title.replace('[COLOR lime]','[COLOR gold]')
                if '#series_menu' in url:
                    title = title.replace('[COLOR lime]','[COLOR gold]')
                if '#desenhos_menu' in url:
                    title = title.replace('[COLOR lime]','[COLOR gold]')
                if '#menu_canais' in url:
                    title = title.replace('[COLOR lime]','[COLOR gold]')
        except:
            pass
        info = '[B][COLOR firebrick]●[/COLOR] [COLOR white]Proibido a venda dos add-ons do VXVULGO PLAY.[/COLOR][/B][CR][B][COLOR firebrick]●[/COLOR] [COLOR white]Não vendemos IPTV, caso ache sites ou mesmo apps é falso.[/COLOR][/B]'
        addDir(title,url,mode,thumb,fanArt,info,'','')
    #Main Menu
    addDir('[B][COLOR blue]●[/COLOR] [COLOR white]CONFIGURAÇÕES[/COLOR][/B]','',4,'','','[B][COLOR blue]●[/COLOR] [COLOR white][COLOR gold]DOAÇÕES[/COLOR] - LINKS - FAQ[/COLOR][CR][COLOR blue]●[/COLOR] [COLOR white]CONTROLE DOS PAIS (+18)[/COLOR][CR][COLOR blue]●[/COLOR] [COLOR white]FAVORITOS[/COLOR][CR][COLOR blue]●[/COLOR] [COLOR white]GUIA DE PROGRAMAÇÃO (EPG)[/COLOR][/B]','','',False)
    addDir('[B][COLOR blue]●[/COLOR] [COLOR white]VERIFICAR UPDATES[/COLOR][/B]','#update',4,'','','[B][COLOR blue]●[/COLOR] [COLOR white]VERIFICAR SE HÁ UPDATES.[/COLOR][/B]','','',False)
    xbmcplugin.endOfDirectory(addon_handle,cacheToDisc=False)
    NewsInfos()

def getLocalTime():
    offset = (datetime.utcnow() - datetime.now())
    return time.time() + offset.total_seconds()

def get_params():
    return dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True))

params=get_params()
xbmcplugin.setContent(addon_handle, 'movies')

mode = int(params.get('mode', 0))
fav_mode=int(params.get('fav_mode', 0))

url = params.get('url', None)
if url:
    url = urllib.unquote_plus(url)

name = params.get('name', None)
if name:
    name = urllib.unquote_plus(name)

iconimage = params.get('iconimage', None)
if iconimage:
    iconimage = urllib.unquote_plus(iconimage)

fanart = params.get('fanart', None)
if fanart:
    fanart = urllib.unquote_plus(fanart)

description = params.get('description', None)
if description:
    description = urllib.unquote_plus(description)

subtitle = params.get('subtitle', None)
if subtitle:
    subtitle = urllib.unquote_plus(subtitle)

url_verify = url
if not url_verify:
    url_verify = 'unknown'
try:
    url_verify = base64.b64decode(base64.b16decode(url_verify))
    url_verify = url_verify.decode('utf-8')
except:
    pass
if url_verify == '#animes_menu' or url_verify == '#pesquisar_animes':
    content_status['active_menu'] = 'animes'
elif url_verify == '#doramas_menu' or url_verify == '#pesquisar_doramas':
    content_status['active_menu'] = 'doramas'
elif url_verify == '#desenhos_menu' or url_verify == '#pesquisar_desenhos':
    content_status['active_menu'] = 'desenhos'
elif url_verify == '#novelas_menu' or url_verify == '#pesquisar_novelas':
    content_status['active_menu'] = 'novelas'
elif url_verify == '#filmes_menu' or url_verify == '#pesquisar_filmes':
    content_status['active_menu'] = 'filmes'
elif url_verify == '#menu_canais':
    content_status['active_menu'] = 'canais'
elif url_verify == '#series_menu' or url_verify == '#pesquisar_series':
    content_status['active_menu'] = 'series'

if mode==0:
    CheckUpdate()
    CheckPlugin()
    if epgEnabled == "true": updateEPG()
    if epgEnabled == "false": InstallPlugin()
    parental_password()
    donate_consider()
    CHIndex()

elif mode==1:
    #url = base64.b16decode(base64.b32decode(codecs.decode(url, '\x72\x6f\x74\x31\x33')))
    #url = base64.b64decode(url)
    CheckUpdate()
    CheckPlugin()
    url = base64.b64decode(base64.b16decode(url))
    try:
        url = url.decode('utf-8')
    except:
        pass
    if epgEnabled == "true": updateEPG()
    if epgEnabled == "false": InstallPlugin()
    parental_password()
    donate_consider()
    if canais_adultos == 'true' and re.search('CANAIS +18', name, re.IGNORECASE):
        adult()
    getData(url, fanart)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode==2:
    if '#search_hub' in url:
        if pesquisa_desativar == 'false':
            if search == '':
                search = get_search_string('PESQUISE O SEU VÍDEO FAVORITO')
                if search:
                    if search == '' or search == ' ' or search == '  ':
                        pesquisa_desativar = 'false'
                        search = ''
                        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                    pesquisa_desativar = 'true'
                    search = 'https://pt.pornhub.com/video/search?search=' + search.replace(' ','+')
                    pornhub(name,search,fanart)
                    xbmcplugin.endOfDirectory(addon_handle)
                    monitor_switch()
                    xbmc.executebuiltin('Container.SetViewMode(500)')
                else:
                    pesquisa_desativar = 'false'
                    search = ''
                    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        else:
            pornhub(name,search,fanart)
            xbmcplugin.endOfDirectory(addon_handle)
            monitor_switch()
            xbmc.executebuiltin('Container.SetViewMode(500)')
    elif '#hub_categorias' in url:
        texto = getMovieData('https://pt.pornhub.com/categories')
        base_url = 'https://pt.pornhub.com'
        texto = re.compile('<div class="categoriesTitleWrapper">.+', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(texto)[0]
        category = re.compile('<li class="catPic.+?<a href="(.+?)".+?alt="(.+?)".+?src="(.+?)"', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(texto)
        for url, title, img in category:
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]'+title.upper()+'[/COLOR][/COLOR][/B]',base_url+url,2,img,fanart,'[B][COLOR white]CONTEÚDOS ADULTOS ORGANIZADOS POR [COLOR gold]CATEGORIAS[/COLOR][/COLOR][/B]','','')
        xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        pornhub(name,url,fanart)
        xbmcplugin.endOfDirectory(addon_handle)
        monitor_switch()
        xbmc.executebuiltin('Container.SetViewMode(500)')

elif mode==3:
    if url.startswith('#trilogias_list'):
        base_list = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x35\x62\x38\x37\x37\x39\x37\x33\x32\x39\x63\x37\x62\x34\x36\x34\x32\x32\x35\x36\x35\x66\x66\x62\x61\x61\x62\x33\x62\x65\x37\x65\x2f\x72\x61\x77\x2f\x74\x72\x69\x6c\x6f\x67\x69\x61\x73\x5f\x6c\x69\x73\x74\x2e\x78\x6d\x6c')
        movies = re.findall('\x3c\x6d\x6f\x76\x69\x65\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x6d\x6f\x76\x69\x65\x3e',base_list,re.MULTILINE|re.DOTALL)
        for trilogy in movies:
            title = re.findall('\x3c\x74\x69\x74\x6c\x65\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x74\x69\x74\x6c\x65\x3e',trilogy,re.MULTILINE)[0]
            thumb = re.findall('\x3c\x74\x68\x75\x6d\x62\x6e\x61\x69\x6c\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x74\x68\x75\x6d\x62\x6e\x61\x69\x6c\x3e',trilogy,re.MULTILINE) or ''
            poster = re.findall('\x3c\x66\x61\x6e\x61\x72\x74\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x66\x61\x6e\x61\x72\x74\x3e',trilogy,re.MULTILINE) or ''
            info = re.findall('\x3c\x69\x6e\x66\x6f\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x69\x6e\x66\x6f\x3e',trilogy,re.MULTILINE) or ''
            if thumb: thumb = thumb[0]
            if poster: poster = poster[0]
            if info: info = info[0]
            description = '[B][COLOR gray]AVISO: SE ALGUM FILME NÃO ESTIVER DISPONÍVEL, USE A FERRAMENTE DE PESQUISA PARA PROCURAR O FILME DESEJADO[/COLOR][CR]%s'%(info)
            addDir('[B][COLOR white]%s[/COLOR][/B]'%title,'#trilogias_select=%s'%title,3,thumb,poster or fanart,description,'','')
    elif url.startswith('#trilogias_select='):
        if six.PY2:
            url = url.decode('utf-8')
        base_list = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x35\x62\x38\x37\x37\x39\x37\x33\x32\x39\x63\x37\x62\x34\x36\x34\x32\x32\x35\x36\x35\x66\x66\x62\x61\x61\x62\x33\x62\x65\x37\x65\x2f\x72\x61\x77\x2f\x74\x72\x69\x6c\x6f\x67\x69\x61\x73\x5f\x6c\x69\x73\x74\x2e\x78\x6d\x6c')
        movies = re.findall('\x3c\x74\x69\x74\x6c\x65\x3e\x25\x73\x3c\x2f\x74\x69\x74\x6c\x65\x3e\x2e\x2b\x3f\x3c\x2f\x6d\x6f\x76\x69\x65\x3e'%url.split('#trilogias_select=')[1],base_list,re.MULTILINE|re.DOTALL)
        if movies:
            trilogy = re.findall('\x3c\x69\x74\x65\x6d\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x69\x74\x65\x6d\x3e',movies[0],re.MULTILINE|re.DOTALL)
            for movie in trilogy:
                title = re.findall('\x3c\x74\x69\x74\x6c\x65\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x74\x69\x74\x6c\x65\x3e',movie,re.MULTILINE|re.DOTALL)[0]
                link = re.findall('\x3c\x6c\x69\x6e\x6b\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x6c\x69\x6e\x6b\x3e',movie,re.MULTILINE|re.DOTALL)[0]
                thumb = re.findall('\x3c\x74\x68\x75\x6d\x62\x6e\x61\x69\x6c\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x74\x68\x75\x6d\x62\x6e\x61\x69\x6c\x3e',movie,re.MULTILINE|re.DOTALL) or ''
                poster = re.findall('\x3c\x66\x61\x6e\x61\x72\x74\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x66\x61\x6e\x61\x72\x74\x3e',movie,re.MULTILINE|re.DOTALL) or ''
                info = re.findall('\x3c\x69\x6e\x66\x6f\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x69\x6e\x66\x6f\x3e',movie,re.MULTILINE|re.DOTALL) or ''
                if thumb: thumb = thumb[0]
                if poster: poster = poster[0]
                if info: info = info[0]
                addLink(title,link,16,thumb,poster or fanart,info,'','')
        else:
            xbmcgui.Dialog().ok("Aviso:", "[B]Trilogia não encontrada.[/B]")
    xbmcplugin.endOfDirectory(addon_handle)

#Configurações/Update
elif mode==4:
    if url == '#update':
        try:
            dp = xbmcgui.DialogProgress()
            dp.create('Verificando Updates...','Por favor aguarde...')
            xbmc.sleep(2000)
            uversao = proxied_update("f5e68697c1ef895a986d046286eab355/raw/version_matrix.txt")
            uversao = str(uversao).replace(' ', '').replace('\n', '').replace('\r', '')
            dp.update(100)
            dp.close()
            if versao != uversao:
                if xbmcgui.Dialog().yesno('Informação:', '[B]Um novo update foi encontrado, deseja atualizar?[CR][COLOR blue]●[/COLOR] Update: [COLOR gold]%s[/COLOR][/B]'%uversao):
                    Update()
            else:
                xbmcgui.Dialog().ok('Informação:', "[B]Seu add-on tem o último update: [COLOR gold]%s[/COLOR][CR]Os updates tem a data do dia em que foi atualizado.[/B]"%uversao)
        except:
            xbmc.executebuiltin("Notification([B][COLOR gold]CHECK UPDATE FAIL![/COLOR][/B], [COLOR white][B]Atualização indisponível no momento.[/COLOR][/B]"+",5000,"+icon+")")
            if xbmcgui.Dialog().yesno(addon_name, '[B][COLOR white]Baixar o Update manualmente?[CR][CR]Houve um erro ao tentar atualizar automáticamente, verifique sua conexão ou horário do sistema.[/COLOR][/B]'):
                siteoficial()
                exit()
            else:
                exit()
    else:
        xbmcaddon.Addon().openSettings()
        xbmc.executebuiltin("Container.Refresh()")

#Link Vazio
elif mode==5:
    xbmc.executebuiltin("Container.Refresh()")

elif mode==6:
    pesquisar_filmes()
    xbmcplugin.endOfDirectory(addon_handle)
    monitor_switch()
    xbmc.executebuiltin('Container.SetViewMode(54)')

elif mode==11:
    playlist(name, url, iconimage, description)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode==13:
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    addFavorite(name,url,fav_mode,subtitle,iconimage,fanart,description)

elif mode==14:
    try:
        name = name.split('\\ ')[1]
    except:
        pass
    try:
        name = name.split('  - ')[0]
    except:
        pass
    rmFavorite(name)

elif mode==15:
    if not url:
        getFavorites()
    else:
        content_status['active_menu'] = url
        getFavorites(True,url)

elif mode==16:
    player_normal(name, url, iconimage, description)
    #xbmcplugin.endOfDirectory(addon_handle)

elif mode==17:
    try:
        url = base64.b64decode(base64.b16decode(url))
    except:
        pass
    try:
        url = url.decode('utf-8')
    except:
        pass
    if url.startswith('watch_later='):
        watch_later_delete(url)
    else:
        url_resolver = url
        if url.startswith('resolver1_episodes=') or url.startswith('resolver1_mv='):
            url,sub = resolver1_episodes(url)
        elif url.startswith('resolver2_episodes=') or url.startswith('resolver2_mv='):
            url = resolver2_episodes(url)
        elif url.startswith('resolver3_episodes=') or url.startswith('resolver3_mv='):
            url = resolver3_episodes(url)
        elif url.startswith('resolver4_episodes=') or url.startswith('resolver4_mv='):
            url = resolver4_episodes(url)
        if url and not url == 'stop' and not url == 'not found':
            watch_later_downloader(url, url_resolver, content_status['watch_later_name'], content_status['watch_later_season'], name, iconimage, fanart, description)
        else:
            xbmcgui.Dialog().notification("[B]Download Manager[/B]", "[B]Falha ao tentar baixar![/B]", icon, 5000)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode==18:
    if not url:
        watch_later_menu()
        xbmcplugin.setContent(addon_handle, 'movies')
        xbmcplugin.endOfDirectory(addon_handle)
        monitor_switch()
        xbmc.executebuiltin('Container.SetViewMode(54)')
    else:
        content_status['active_menu'] = url
        watch_later_menu(url)
        xbmcplugin.setContent(addon_handle, 'movies')
        xbmcplugin.endOfDirectory(addon_handle)
        monitor_switch()

elif mode==20:
    if '#pesquisar_series' in url:
        if pesquisa_desativar == 'false':
            if search == '':
                search = get_search_string('PESQUISE SUA SÉRIE FAVORITA')
                if search:
                    if search == '' or search == ' ' or search == '  ':
                        pesquisa_desativar = 'false'
                        search = ''
                        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                    pesquisa_desativar = 'true'
                    pesquisar_series()
                    #xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL)
                    xbmcplugin.endOfDirectory(addon_handle)
                    monitor_switch()
                    xbmc.executebuiltin('Container.SetViewMode(54)')
                else:
                    pesquisa_desativar = 'false'
                    search = ''
                    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        else:
            pesquisar_series()
            #xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_LABEL)
            xbmcplugin.endOfDirectory(addon_handle)
            monitor_switch()
            xbmc.executebuiltin('Container.SetViewMode(54)')

elif mode==21:
    CheckUpdate()
    CheckPlugin()
    if epgEnabled == "true": updateEPG()
    if epgEnabled == "false": InstallPlugin()
    parental_password()
    donate_consider()
    if disable_canais_extra == 'true':
        if not addon.getSetting("controledospais"):
            addon.setSettingBool('controledospais', True)
    disable_parental = addon.getSetting("controledospais")
    hashed_pw_verify = features_checker() if features_enable == 'true' and not features_pass == '' else None
    if url == '#menu_canais':
        if ch_layout == 'true':
            blink = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x63\x68\x61\x6e\x6e\x65\x6c\x73\x2e\x78\x6d\x6c'
            teste = getMovieData(blink)
            teste = re.compile('<channel_\d>(.+?)</channel_\d>',re.MULTILINE|re.DOTALL).findall(teste)
            plus_mode = False
            link = ''
            count = 1
            count_name = 1
            try:
                if features_enable == 'true' and not features_pass == '':
                    if hashed_pw_verify:
                        linkedUrl = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'chlist'
                        addDir('[B][COLOR white]OPÇÃO [COLOR gold]%s[/COLOR][/COLOR] [COLOR skyblue]PRO[/COLOR][/B]'%count_name,linkedUrl,1,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
                        count, count_name = 2,2
            except:
                pass
            if plus_mode:
                pass
                #addDir('[B][COLOR white]OPÇÃO [COLOR gold]%s[/COLOR][/COLOR][/B]'%count,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2e\x66\x6f\x72\x75\x6d\x65\x69\x72\x6f\x73\x2e\x63\x6f\x6d\x2f\x68\x32\x36\x2d\x74\x65\x73\x74\x65\x6d\x62',1,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            else:
                for req in teste:
                    addDir('[B][COLOR white]OPÇÃO [COLOR gold]%s[/COLOR][/COLOR][/B]'%count_name,'channel_%s'%count,21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
                    count += 1
                    count_name += 1
            addDir('[B][COLOR white]PLUTO TV[/COLOR][/B]','#pluto_menu',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            if canais_adultos == 'true' and disable_parental == '':
                blink = '\x61\x48\x52\x30\x63\x48\x4d\x36\x4c\x79\x39\x69\x63\x6d\x46\x36\x64\x57\x4e\x68\x63\x47\x78\x68\x65\x53\x35\x6d\x62\x33\x4a\x31\x62\x57\x56\x70\x63\x6d\x39\x7a\x4c\x6d\x4e\x76\x62\x53\x39\x6f\x4f\x54\x63\x74\x63\x32\x56\x79\x64\x6d\x56\x79\x59\x57\x52\x31\x62\x48\x51\x75\x65\x47\x31\x73'
                blink = base64.b64decode(blink).decode('utf-8')
                addDir('[B][COLOR white]CANAIS +18[/COLOR][/B]',blink,1,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]TODOS OS CANAIS[/COLOR][/COLOR][/B]','#todoscanais',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]CANAIS ABERTOS[/COLOR][/COLOR][/B]','#canaisabertos',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]DOCUMENTÁRIOS[/COLOR][/COLOR][/B]','#documentarios',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]ESPORTES[/COLOR][/COLOR][/B]','#esportes',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]FILMES & SÉRIES[/COLOR][/COLOR][/B]','#filmeseseries',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]INFANTIL[/COLOR][/COLOR][/B]','#infantil',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]MÚSICAS & VARIEDADES[/COLOR][/COLOR][/B]','#variedades',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]NOTÍCIAS[/COLOR][/COLOR][/B]','#noticias',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]PLUTO TV[/COLOR][/COLOR][/B]','#pluto_menu',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            addDir('[B][COLOR white]CATEGORIA: [COLOR gold]REALITY SHOWS[/COLOR][/COLOR][/B]','#realityshows',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            if canais_adultos == 'true' and disable_parental == '':
                blink = '\x61\x48\x52\x30\x63\x48\x4d\x36\x4c\x79\x39\x69\x63\x6d\x46\x36\x64\x57\x4e\x68\x63\x47\x78\x68\x65\x53\x35\x6d\x62\x33\x4a\x31\x62\x57\x56\x70\x63\x6d\x39\x7a\x4c\x6d\x4e\x76\x62\x53\x39\x6f\x4f\x54\x63\x74\x63\x32\x56\x79\x64\x6d\x56\x79\x59\x57\x52\x31\x62\x48\x51\x75\x65\x47\x31\x73'
                blink = base64.b64decode(blink).decode('utf-8')
                addDir('[B][COLOR white]CATEGORIA: [COLOR gold]CANAIS +18[/COLOR][/COLOR][/B]',blink,1,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
            xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('channel_'):
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x63\x68\x61\x6e\x6e\x65\x6c\x73\x2e\x78\x6d\x6c'
        channel = getMovieData(link)
        channel = re.compile('<%s>(.+?)</%s>'%(url,url),re.MULTILINE|re.DOTALL).findall(channel)
        if channel:
            getData('<item><epg_active>True</epg_active></item>%s'%str(channel[0]), fanart, chlist=True)
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#pluto_menu' in url:
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]TODOS OS CANAIS[/COLOR][/COLOR][/B]','#plutotv_16',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]ANIME & GEEK[/COLOR][/COLOR][/B]','#plutotv_0',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]COMÉDIA[/COLOR][/COLOR][/B]','#plutotv_1',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]CURIOSIDADES[/COLOR][/COLOR][/B]','#plutotv_2',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]ESPORTES[/COLOR][/COLOR][/B]','#plutotv_3',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]ESTILO DE VIDA[/COLOR][/COLOR][/B]','#plutotv_4',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]FILMES[/COLOR][/COLOR][/B]','#plutotv_5',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]INFANTIL[/COLOR][/COLOR][/B]','#plutotv_6',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]INVESTIGAÇÃO[/COLOR][/COLOR][/B]','#plutotv_7',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]MÚSICA[/COLOR][/COLOR][/B]','#plutotv_8',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]NOTÍCIAS[/COLOR][/COLOR][/B]','#plutotv_9',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]NOVELAS[/COLOR][/COLOR][/B]','#plutotv_10',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]REALITY[/COLOR][/COLOR][/B]','#plutotv_11',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]RETRÔ[/COLOR][/COLOR][/B]','#plutotv_12',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]SOUTH PARK[/COLOR][/COLOR][/B]','#plutotv_13',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]SÉRIES[/COLOR][/COLOR][/B]','#plutotv_14',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        addDir('[B][COLOR white]CATEGORIA: [COLOR gold]TV BRASILEIRA[/COLOR][/COLOR][/B]','#plutotv_15',21,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#plutotv' in url:
        import uuid
        url_select = url
        BASE_API      = 'https://api.pluto.tv'
        BASE_LINEUP   = BASE_API + '/v2/channels.json?%s'
        start = (datetime.fromtimestamp(getLocalTime()).strftime('%Y-%m-%dT%H:00:00Z'))
        stop  = (datetime.fromtimestamp(getLocalTime()) + timedelta(hours=4)).strftime('%Y-%m-%dT%H:00:00Z')
        if xbmcaddon.Addon().getSetting("sid1_hex") and xbmcaddon.Addon().getSetting("deviceId1_hex"):
            pass
        else:
            addon.setSetting("sid1_hex",str(uuid.uuid1().hex))
            addon.setSetting("deviceId1_hex",str(uuid.uuid4().hex))
        header={'User-agent': 'Mozilla/5.0 (Windows NT 6.2; rv:24.0) Gecko/20100101 Firefox/24.0'}
        param={}
        uu1 = addon.getSetting("sid1_hex")
        uu2 = addon.getSetting("deviceId1_hex")
        BASE_LINEUP = BASE_LINEUP%('sid=%s&deviceId=%s'%(uu1,uu2))#original
        req = requests.get(BASE_LINEUP, param, headers=header)
        cacheresponse = req.json()
        genre_number = ['Anime & Geek', 'Comédia', 'Curiosidades', 'Esportes', 'Estilo de Vida', 'Filmes', 'Infantil', 'Investigação', 'Música', 'Notícias', 'Novelas', 'Reality', 'Retrô', 'South Park br', 'Séries', 'TV Brasileira', 'Todos']
        count = url.replace('#plutotv_','')
        genre_number = genre_number[int(count)]
        addLink(name,'here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        add_ch = []
        for canais in cacheresponse:
            if str(genre_number) == 'Todos':
                chid      = canais.get('_id','')
                chname    = canais.get('name','')
                chnum     = canais.get('number','')
                chplot    = (canais.get('description','') or canais.get('summary',''))
                chlogo = canais.get('colorLogoPNG').get('path',canais)
                chart = canais.get('featuredImage').get('path',canais)
                urls = canais.get('stitched',{}).get('urls',[])
                if isinstance(urls, list): urls = [url['url'] for url in urls if url['type'].lower() == 'hls'][0]
                url = urls
                if url.endswith('?deviceType='): url = url.replace('deviceType=','deviceType=&deviceMake=&deviceModel=&&deviceVersion=unknown&appVersion=unknown&deviceDNT=0&userId=&advertisingId=&app_name=&appName=&buildVersion=&appStoreUrl=&architecture=&includeExtendedEvents=false')#todo lazy fix replace
                if 'sid' not in url: url = url.replace('deviceModel=&','deviceModel=&' + LANGUAGE(30022)%(getUUID()))
                url = url.replace('deviceType=&','deviceType=web&').replace('deviceMake=&','deviceMake=Chrome&') .replace('deviceModel=&','deviceModel=Chrome&').replace('appName=&','appName=web&')#todo replace with regex!
                add_ch.append(('[B]%s[/B]'%chname.upper(),url,16,chlogo,chart,'[B][COLOR white]%s[/COLOR][/B]'%chplot))
            else:
                if re.search(requests.utils.quote(genre_number.encode('utf-8')),requests.utils.quote(canais.get('category','').encode('utf-8')),re.IGNORECASE):
                    chid      = canais.get('_id','')
                    chname    = canais.get('name','')
                    chnum     = canais.get('number','')
                    chplot    = (canais.get('description','') or canais.get('summary',''))
                    chlogo = canais.get('colorLogoPNG').get('path',canais)
                    chart = canais.get('featuredImage').get('path',canais)
                    urls = canais.get('stitched',{}).get('urls',[])
                    if isinstance(urls, list): urls = [url['url'] for url in urls if url['type'].lower() == 'hls'][0]
                    url = urls
                    if url.endswith('?deviceType='): url = url.replace('deviceType=','deviceType=&deviceMake=&deviceModel=&&deviceVersion=unknown&appVersion=unknown&deviceDNT=0&userId=&advertisingId=&app_name=&appName=&buildVersion=&appStoreUrl=&architecture=&includeExtendedEvents=false')#todo lazy fix replace
                    if 'sid' not in url: url = url.replace('deviceModel=&','deviceModel=&' + LANGUAGE(30022)%(getUUID()))
                    url = url.replace('deviceType=&','deviceType=web&').replace('deviceMake=&','deviceMake=Chrome&') .replace('deviceModel=&','deviceModel=Chrome&').replace('appName=&','appName=web&')#todo replace with regex!
                    add_ch.append(('[B]%s[/B]'%chname.upper(),url,16,chlogo,chart,'[B][COLOR white]%s[/COLOR][/B]'%chplot))
        add_ch.sort(key=lambda str: str[0])
        for ch_name,ch_url,ch_mode,ch_logo,ch_fanart,ch_plot in add_ch:
            ch_url += helpers.append_headers(header)
            addLink(ch_name,'inputstream_adaptive=%s'%ch_url,ch_mode,ch_logo,ch_fanart,ch_plot,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    else:
        blink,teste,link = '','',''
        if '#menu_canais_adults' in url:
            blink = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x63\x68\x61\x6e\x6e\x65\x6c\x73\x2e\x78\x6d\x6c'
            html = getMovieData(blink)
            channel = re.compile('<channel_adults>(.+?)</channel_adults>',re.MULTILINE|re.DOTALL).findall(html)
            if channel:
                link = channel[0].replace('\n','').replace('\r','').replace('<link>','<link>$'+str(1)+'$')
        else:
            blink = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x63\x68\x61\x6e\x6e\x65\x6c\x73\x2e\x78\x6d\x6c'
            teste = getMovieData(blink)
            teste = re.compile('<channel_\d>(.+?)</channel_\d>',re.MULTILINE|re.DOTALL).findall(teste)
            plus_mode = False
            link = ''
            count = 1
            try:
                if features_enable == 'true' and not features_pass == '':
                    if hashed_pw_verify:
                        linkedUrl = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'chlist'
                        link += getMovieData(linkedUrl).replace('\n','').replace('\r','').replace('<link>','<link>$'+str(count)+'$')
                        link = link.replace('HD[/COLOR][/B]</title>','[COLOR skyblue]PRO[/COLOR][/COLOR][COLOR silver] SERVER 1[/COLOR][/B]</title>')
                        plus_mode = False
                        count = 2
            except:
                pass
            if plus_mode:
                pass
                #link += getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x72\x61\x7a\x75\x63\x61\x70\x6c\x61\x79\x2e\x66\x6f\x72\x75\x6d\x65\x69\x72\x6f\x73\x2e\x63\x6f\x6d\x2f\x68\x32\x36\x2d\x74\x65\x73\x74\x65\x6d\x62').replace('\n','').replace('\r','').replace('<link>','<link>$'+str(count)+'$')
            else:
                for req in teste:
                    link += req.replace('\n','').replace('\r','').replace('[/COLOR][/B]</title>','[/COLOR][COLOR silver] SERVER %s[/COLOR][/B]</title>'%count).replace('<link>','<link>$'+str(count)+'$')
                    count += 1
        from collections import OrderedDict
        seletor = re.findall(r'<item>.+?</item>', link, re.MULTILINE | re.DOTALL)
        itens_filtrados = [item for item in seletor if '|||' not in item and '<epg_active>True</epg_active>' not in item]
        comparar_itens = list(OrderedDict.fromkeys(itens_filtrados))
        comparar_titulos = re.findall(r'<title>.+?</title>', ''.join(comparar_itens), re.DOTALL)
        name_ch=[]
        canais=''
        canais_final=[]
        canaisabertos = ['BAND', 'GLOBO', 'RECORD', 'RPC', 'SBT']
        documentarios = ['ANIMAL PLANET', 'DISCOVERY CHANNEL', 'DISCOVERY SCIENCE', 'DISCOVERY TURBO', 'DISCOVERY WORLD', 'H2', 'HISTORY', 'NAT GEO']
        esportes = ['BAND SPORTS', 'COMBATE', 'CONMEBOL', 'ESPN', 'FOX SPORTS', 'PREMIERE', 'SPORTV', 'NOSSO FUTEBOL', 'NSPORTS']
        filmes = ['A&E', 'AMC', 'AXN', 'CINEMAX', 'FOX', 'FX', 'HBO', 'MEGAPIX', 'PARAMOUNT', 'PRIME VIDEO', 'SONY', 'SPACE', 'STAR', 'SYFY', 'TELECINE', 'TNT', 'USA NETWORK', 'UNIVERSAL', 'WARNER']
        infantil = ['BOOMERANG', 'CARTOON NETWORK', 'DISNEY', 'GLOOB', 'KIDS', 'NICK', 'TOONCAST']
        variedades = ['ARTE 1', 'BIS', 'CANAL BRASIL', 'CANAL OFF', 'COMEDY', 'DISCOVERY HOME', 'E!', 'FISH TV', 'FOOD', 'FOOD NETWORK', 'GLOBOSAT', 'GNT', 'HGTV', 'ID', 'LIFETIME', 'MODO VIAGEM', 'MTV', 'MULTISHOW', 'TBS', 'TERRA', 'TLC', 'TRUTV', 'VIVA']
        noticias = ['BAND NEWS', 'CNN', 'GLOBO NEWS', 'RECORD NEWS']
        realityshows = ['A FAZENDA', 'BBB', 'POWER COUPLE']
        canaisadultos = ['ANGELS','PLAYBOY','HUSTLER','EXXXOTICA','PENTHOUSE','SEXY HOT','SEXTREME','VENUS','SEX PRIVE','O-LA-LA','HOT PLEASURE','HOT XXL','REALITY KINGS']
        if '#canaisabertos' in url:
            addLink('[B][COLOR white]CATEGORIA: [COLOR gold]CANAIS ABERTOS[/COLOR][/COLOR][/B]','here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        elif '#documentarios' in url:
            addLink('[B][COLOR white]CATEGORIA: [COLOR gold]DOCUMENTÁRIOS[/COLOR][/COLOR][/B]','here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        elif '#esportes' in url:
            addLink('[B][COLOR white]CATEGORIA: [COLOR gold]ESPORTES[/COLOR][/COLOR][/B]','here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        elif '#filmeseseries' in url:
            addLink('[B][COLOR white]CATEGORIA: [COLOR gold]FILMES & SÉRIES[/COLOR][/COLOR][/B]','here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        elif '#infantil' in url:
            addLink('[B][COLOR white]CATEGORIA: [COLOR gold]INFANTIL[/COLOR][/COLOR][/B]','here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        elif '#variedades' in url:
            addLink('[B][COLOR white]CATEGORIA: [COLOR gold]MUSICAS & VARIEDADES[/COLOR][/COLOR][/B]','here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        elif '#noticias' in url:
            addLink('[B][COLOR white]CATEGORIA: [COLOR gold]NOTÍCIAS[/COLOR][/COLOR][/B]','here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        elif '#realityshows' in url:
            addLink('[B][COLOR white]CATEGORIA: [COLOR gold]REALITY SHOWS[/COLOR][/COLOR][/B]','here',16,'https://i.imgur.com/dRfcHTf.jpg','https://i.imgur.com/oVVI97U.jpg','[B][COLOR white]OS MELHORES CANAIS [COLOR gold]AO VIVO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        for items in comparar_titulos:
            items = re.sub('(.\[COLOR gold\].*\[\/COLOR\])','',items)
            if '#canaisabertos' in url:
                for test in canaisabertos:
                    if re.search(test,str(items),re.IGNORECASE) and not re.search('SPORTS',str(items),re.IGNORECASE) and not re.search('NEWS',str(items),re.IGNORECASE) and not re.search('GLOBOSAT',str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#documentarios' in url:
                for test in documentarios:
                    if re.search(test,str(items),re.IGNORECASE) and not re.search('KIDS',str(items),re.IGNORECASE) and not re.search('HBO',str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#esportes' in url:
                for test in esportes:
                    if re.search(test,str(items),re.IGNORECASE) and not re.search('UNIVERSAL',str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#filmeseseries' in url:
                for test in filmes:
                    if re.search(test,str(items),re.IGNORECASE) and not re.search('SPORTS',str(items),re.IGNORECASE) and not re.search('BBB',str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#infantil' in url:
                for test in infantil:
                    if re.search(test,str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#variedades' in url and not re.search('KIDS',str(items),re.IGNORECASE):
                for test in variedades:
                    if re.search(test,str(items),re.IGNORECASE) and not re.search('GLOBO',str(items),re.IGNORECASE) and not re.search('RECORD',str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#noticias' in url:
                for test in noticias:
                    if re.search(test,str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#realityshows' in url:
                for test in realityshows:
                    if re.search(test,str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#menu_canais_adults' in url:
                for test in canaisadultos:
                    if re.search(test,str(items),re.IGNORECASE):
                        name_ch.append(items)
            elif '#todoscanais' in url:
                name_ch.append(items)
        name_ch = list(OrderedDict.fromkeys(name_ch))
        for canal in name_ch:
            name_change = re.sub('(.\[COLOR gold\].*\[\/COLOR\])','',canal)
            name_change = name_change.replace('[COLOR white]','').replace('[/COLOR]','')
            ch_icon=''
            for ch1 in comparar_itens:
                ch1_check = re.sub('(.\[COLOR gold\].*\[\/COLOR\])','',ch1)
                ch1_check = ch1_check.replace('[COLOR white]','').replace('[/COLOR]','')
                if name_change in ch1_check:
                    lsname=re.compile('<title>(.+?)</title>').findall(ch1)[0]
                    try:
                        ch_icon=re.compile('<thumbnail>.+?</thumbnail>').findall(ch1)[0]
                    except:
                        ch_icon='<thumbnail></thumbnail>'
                    correct = re.compile('<link>(.+?)</link>').findall(ch1)[0]
                    if not re.search('<link>\$\d\$</link>',ch1):
                        canais += '<link>'+correct+'lsname='+lsname.replace('<title>','').replace('</title>','')+'</link>'
            if not str(name_change)+'</title>' in str(canais_final):
                if not '</link><link>' in str(canais):
                    quality = re.compile('\[COLOR gold\](.+?)\[',re.IGNORECASE).findall(lsname)[0]
                    name_change = '<title>[B]%s [COLOR gold]%s[/COLOR][/B]</title>'%(re.compile('\[COLOR white\](.+?)\[',re.IGNORECASE).findall(lsname)[0],quality)
                canais_final.append('<item>'+str(name_change)+str(canais)+'<epgid></epgid>'+ch_icon+'</item>')
            canais=''
        try:
            natural_sort(canais_final,key=lambda str: re.sub('<link>.+?</item>','',str.replace('<item><title>[B]','').replace('[/B]</title>','')))
        except:
            canais_final.sort()
        canais_final_renew=[]
        canais_final_renew.append('<item><epg_active>True</epg_active></item>')
        for chnew in canais_final:
            chnew = re.sub('\$.+?\$','',chnew)
            if 'lsname=' in chnew and not '$$' in chnew:
                chnew = chnew.replace('lsname=','$$lsname=')
            canais_final_renew.append(chnew)
        getItems(canais_final_renew,fanart)
        xbmcplugin.endOfDirectory(addon_handle)
elif mode==22:
    if url.startswith('animes1='):
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais.[/B]")
        xbmcplugin.endOfDirectory(addon_handle)
        exit()
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x6e\x69\x6d\x65\x73\x68\x6f\x75\x73\x65\x2e\x74\x6f\x70\x2f\x61\x6e\x69\x6d\x65\x2f' + url.split('animes1=')[1]
        url = getMovieData(link,'').replace("'",'"')
        url = re.sub('\x3c\x69\x3e\x2e\x2b\x3f\x3c\x5c\x2f\x69\x3e', '', url)
        dados = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x71\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x69\x74\x6c\x65\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
        if len(dados) > 1:
            for data in dados:
                temp = data.upper()
                temp = temp.replace('TEMPORADA ','').replace(' ','')
                temp = temp + 'ª TEMPORADA'
                listar = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x71\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x69\x74\x6c\x65\x22\x3e'+str(data)+'\x3c\x2f\x73\x70\x61\x6e\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                episodios = re.compile('\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
                addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(temp,episodios,'#animes1_temp=')],22,iconimage,fanart,description,'','')
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            listar = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x71\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x69\x74\x6c\x65\x22\x3e'+dados[0]+'\x3c\x2f\x73\x70\x61\x6e\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
            episodios = re.compile('\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
            temp = dados[0].upper()
            temp = temp.replace('TEMPORADA ','').replace(' ','')
            temp = temp + 'ª TEMPORADA'
            addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',22,iconimage,fanart,description,'','')
            for link,title in episodios:
                addLink('[B]%s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
            xbmcplugin.endOfDirectory(addon_handle)
    elif '#animes1_temp=' in url:
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais.[/B]")
        xbmcplugin.endOfDirectory(addon_handle)
        exit()
        import ast
        url = ast.literal_eval(url)
        temp = url[0][0]
        episodes = url[0][1]
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',22,iconimage,fanart,description,'','')
        for link,title in episodes:
            addLink('[B]%s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('animes2='):
        link = url.split('animes2=')[1]
        params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x33\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x74\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%link
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 2 - Código: 404[/COLOR][/B]')
            exit()
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        html = base64.b64decode(html.encode('utf-8')).decode('utf-8')
        import ast
        params = ast.literal_eval(html)
        if six.PY2:
            from collections import OrderedDict
            params = OrderedDict(sorted(params.items()))
        if not params:
            xbmcgui.Dialog().ok('Aviso:', '[B]Erro 404: [COLOR gold]Anime indisponível no momento![/COLOR][/B]')
        elif len(params) > 1:
            for temp, value in params:
                if not str(value) == '[]':
                    temp = temp + 'ª TEMPORADA'
                    if "'dub'" in str(value) and "'leg'" in str(value):
                        addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(link,temp,value,'#animes2_temp_language=')],22,iconimage,fanart,description,'','')
                    else:
                        addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(link,temp,value,'single','#animes2_temp=')],22,iconimage,fanart,description,'','')
        else:
            for temp, value in params:
                if not str(value) == '[]':
                    temp = temp + 'ª TEMPORADA'
                    if "'dub'" in str(value) and "'leg'" in str(value):
                        addDir('[B][COLOR white]ASSISTIR DUBLADO[/COLOR][/B]',[(link,temp,value,'dub','#animes2_temp=')],22,iconimage,fanart,description,'','')
                        addDir('[B][COLOR white]ASSISTIR LEGENDADO[/COLOR][/B]',[(link,temp,value,'leg','#animes2_temp=')],22,iconimage,fanart,description,'','')
                    else:
                        episodes = ast.literal_eval(str(value))
                        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',22,iconimage,fanart,description,'','')
                        for season,episode,language in episodes:
                            title = 'EPISÓDIO ' + episode
                            addLink('[B]%s[/B]'%title,'resolver3_episodes=%s#%s#%s#%s'%(link,season,episode,language),16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#animes2_temp_language=' in url:
        import ast
        url = ast.literal_eval(url)
        link,temp,value,resolver = url[0]
        addDir('[B][COLOR white]ASSISTIR DUBLADO[/COLOR][/B]',[(link,temp,value,'dub','#animes2_temp=')],22,iconimage,fanart,description,'','')
        addDir('[B][COLOR white]ASSISTIR LEGENDADO[/COLOR][/B]',[(link,temp,value,'leg','#animes2_temp=')],22,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#animes2_temp=' in url:
        import ast
        url = ast.literal_eval(url)
        link = url[0][0]
        temp = url[0][1]
        episodes = url[0][2]
        lang = url[0][3]
        serie_name = url[0][0]
        episodes = ast.literal_eval(str(episodes))
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
        for season,episode,language in episodes:
            if language == lang:
                title = 'EPISÓDIO ' + episode
                addLink('[B]%s[/B]'%title,'resolver3_episodes=%s#%s#%s#%s'%(serie_name,season,episode,language),16,iconimage,fanart,description,'','')
            elif lang == 'single':
                title = 'EPISÓDIO ' + episode
                addLink('[B]%s[/B]'%title,'resolver3_episodes=%s#%s#%s#%s'%(serie_name,season,episode,language),16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('animes3='):
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x6e\x69\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x63\x63\x2e\x74\x6f\x2f\x61\x6e\x69\x6d\x65\x2f' + url.split('animes3=')[1]
        url = getMovieData(link,'')
        dados = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x71\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x69\x74\x6c\x65\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
        if len(dados) > 1:
            for data in dados:
                temp = data.upper()
                temp = temp.replace('TEMPORADA ','').replace(' ','')
                temp = temp + 'ª TEMPORADA'
                listar = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x71\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x69\x74\x6c\x65\x22\x3e'+data+'\x3c\x2f\x73\x70\x61\x6e\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                episodios = re.compile('\x3c\x69\x6d\x67\x20\x73\x72\x63\x3d\x22\x2e\x2b\x3f\x22\x3e\x2e\x2b\x3f\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
                addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(temp,episodios,'#animes3_temp=')],22,iconimage,fanart,description,'','')
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            listar = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x71\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x69\x74\x6c\x65\x22\x3e'+dados[0]+'\x3c\x2f\x73\x70\x61\x6e\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
            episodios = re.compile('\x3c\x69\x6d\x67\x20\x73\x72\x63\x3d\x22\x2e\x2b\x3f\x22\x3e\x2e\x2b\x3f\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
            temp = dados[0].upper()
            temp = temp.replace('TEMPORADA ','').replace(' ','')
            temp = temp + 'ª TEMPORADA'
            addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',22,iconimage,fanart,description,'','')
            for link,title in episodios:
                addLink('[B]%s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
            xbmcplugin.endOfDirectory(addon_handle)
    elif '#animes3_temp=' in url:
        import ast
        url = ast.literal_eval(url)
        temp = url[0][0]
        episodes = url[0][1]
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',22,iconimage,fanart,description,'','')
        for link,title in episodes:
            addLink('[B]%s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('animes4='):
        link = url.split('animes4=')[1]
        params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x31\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x74\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%link
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Animes Resolver 4 - Código: 404[/COLOR][/B]')
            exit()
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        html = base64.b64decode(html.encode('utf-8')).decode('utf-8')
        import ast
        params = ast.literal_eval(html)
        if six.PY2:
            from collections import OrderedDict
            params = OrderedDict(sorted(params.items()))
        if not params:
            xbmcgui.Dialog().ok('Aviso:', '[B]Erro 404: [COLOR gold]Anime indisponível no momento![/COLOR][/B]')
        elif len(params) > 1:
            for temp, value in params.items():
                if not str(value) == '[]':
                    temp = temp.replace('° Temporada','').replace(' ','').replace('Season','') + 'ª TEMPORADA'
                    temp = re.sub('<.+>', '', temp)
                    addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(temp,value,'#animes4_temp=')],22,iconimage,fanart,description,'','')
        else:
            for temp, value in params.items():
                temp = temp.replace('° Temporada','').replace(' ','').replace('Season','') + 'ª TEMPORADA'
                temp = re.sub('<.+>', '', temp)
                episodes = ast.literal_eval(value)
                addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',22,iconimage,fanart,description,'','')
                for episode in episodes:
                    title = 'EPISÓDIO ' + re.sub('(.*) - ', '', episode[0])
                    info = '[B][COLOR gold]Título: [/COLOR]%s[/B][CR]'%episode[2] + description
                    addLink('[B]%s[/B]'%title,episode[1],16,iconimage,fanart,info,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#animes4_temp=' in url:
        import ast
        url = ast.literal_eval(url)
        temp = url[0][0]
        episodes = url[0][1]
        episodes = ast.literal_eval(episodes)
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',22,iconimage,fanart,description,'','')
        for episode in episodes:
            title = 'EPISÓDIO ' + re.sub('(.*) - ', '', episode[0])
            info = '[B][COLOR gold]Título: [/COLOR]%s[/B][CR]'%episode[2] + description
            addLink('[B]%s[/B]'%title,episode[1],16,iconimage,fanart,info,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('animes5='):
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais ou está em manutenção.[/B]")
        xbmcplugin.endOfDirectory(addon_handle)
        exit()
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x65\x74\x74\x65\x72\x61\x6e\x69\x6d\x65\x2e\x6e\x65\x74\x2f\x61\x6e\x69\x6d\x65\x2f' + url.split('animes5=')[1]
        base_html = getMovieData(link)
        html = re.compile('\x69\x64\x3d\x22\x65\x70\x69\x73\x6f\x64\x65\x73\x4c\x69\x73\x74\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x75\x6c\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base_html)
        if html:
            html = html[0]
            episodes = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x2e\x2b\x3f\x3c\x68\x33\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x68\x33\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
            for link,title in episodes:
                addLink('[B]%s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('animes6='):
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais.[/B]")
        xbmcplugin.endOfDirectory(addon_handle)
        exit()
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x78\x70\x61\x6e\x69\x6d\x65\x73\x2e\x63\x6f\x6d\x2f\x25\x73\x2f'%url.split('animes6=')[1]
        base,cookies = CloudRequest(link, CloudInfo=True)
        base = base.replace('</p>','').replace('\n','').replace('\r','')
        base_html = re.compile('\x3c\x75\x6c\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x61\x62\x73\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x75\x6c\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        seasons = re.compile('\x3c\x61\x2e\x2b\x3f\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base_html)
        if len(seasons) > 1:
            season_number = 0
            add_season_dir = []
            for season in seasons:
                if season == 'Episódios':
                    season = '1ª TEMPORADA'
                if not season == 'Filmes':
                    season = season.replace(' <b>(SD/HD)</b>', '').replace("&#8220;","“").replace("&#8221;","”").replace("&#8217;","’")
                    add_season_dir.append((season,season_number))
                season_number += 1
            add_season_dir = sorted(add_season_dir, key=lambda key: key[0])
            for season,seasons_count in add_season_dir:
                if 'ª' in season and len(season) == 2:
                    season = '%s TEMPORADA'%season
                addDir('[B][COLOR white]%s[/COLOR][/B]'%season.upper(),[(link,cookies,'#animes6_temp=',seasons_count,season)],22,iconimage,fanart,description,'','')
        else:
            base_html = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x61\x62\x5f\x63\x6f\x6e\x74\x65\x6e\x74\x22\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x3c\x2f\x6c\x69\x3e\x3c\x2f\x75\x6c\x3e\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
            seasons = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x75\x6d\x5f\x74\x65\x72\x63\x6f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x75\x6c\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base_html)
            if not '\x3c\x61\x20' in seasons[1] and '\x3c\x61\x20' in seasons[0]:
                addLink('[B][COLOR gold]1ª TEMPORADA[/COLOR][/B]','here',22,iconimage,fanart,description,'','')
                seasons = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(seasons[0])
                for link,title in seasons:
                    addLink('[B]%s[/B]'%title.upper(),'\x78\x70\x61\x6e\x69\x6d\x65\x73\x3d\x25\x73\x7c\x25\x73'%(link.replace('&#038;','&'),cookies),16,iconimage,fanart,description,'','')
            if not '\x3c\x61\x20' in seasons[0] and '\x3c\x61\x20' in seasons[1]:
                addLink('[B][COLOR gold]1ª TEMPORADA[/COLOR][/B]','here',22,iconimage,fanart,description,'','')
                seasons = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(seasons[1])
                for link,title in seasons:
                    addLink('[B]%s[/B]'%title.upper(),'\x78\x70\x61\x6e\x69\x6d\x65\x73\x3d\x25\x73\x7c\x25\x73'%(link.replace('&#038;','&'),cookies),16,iconimage,fanart,description,'','')
            else:
                description = '[B]ESCOLHA EM QUAL IDIOMA VOCÊ PREFERE ASSISTIR![/B]'
                addDir('[B][COLOR white]ASSISTIR DUBLADO[/COLOR][/B]',[('#animes6_temp_dub=', seasons[1], cookies, '1ª TEMPORADA')],22,iconimage,fanart,description,'','')
                addDir('[B][COLOR white]ASSISTIR LEGENDADO[/COLOR][/B]',[('#animes6_temp_dub=', seasons[0], cookies, '1ª TEMPORADA')],22,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#animes6_temp=' in url:
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais.[/B]")
        xbmcplugin.endOfDirectory(addon_handle)
        exit()
        import ast
        url = ast.literal_eval(url)
        link = url[0][0]
        temp = url[0][3]
        dir_name = url[0][4]
        cookies = url[0][1]
        dir_name = dir_name.upper()
        base = getMovieData(link).replace('</p>','').replace('\n','').replace('\r','')
        base_html = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x61\x62\x5f\x63\x6f\x6e\x74\x65\x6e\x74\x22\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x3c\x2f\x6c\x69\x3e\x3c\x2f\x75\x6c\x3e\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[int(temp)]
        seasons = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x75\x6d\x5f\x74\x65\x72\x63\x6f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x75\x6c\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base_html)
        if not '\x3c\x61\x20' in seasons[1] and '\x3c\x61\x20' in seasons[0]:
            addLink('[B][COLOR gold]%s[/COLOR][/B]'%dir_name,'here',22,iconimage,fanart,description,'','')
            seasons = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(seasons[0])
            for link,title in seasons:
                addLink('[B]%s[/B]'%title.upper(),'\x78\x70\x61\x6e\x69\x6d\x65\x73\x3d\x25\x73\x7c\x25\x73'%(link.replace('&#038;','&'),cookies),16,iconimage,fanart,description,'','')
        if not '\x3c\x61\x20' in seasons[1] and '\x3c\x61\x20' in seasons[1]:
            addLink('[B][COLOR gold]%s[/COLOR][/B]'%dir_name,'here',22,iconimage,fanart,description,'','')
            seasons = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(seasons[1])
            for link,title in seasons:
                addLink('[B]%s[/B]'%title.upper(),'\x78\x70\x61\x6e\x69\x6d\x65\x73\x3d\x25\x73\x7c\x25\x73'%(link.replace('&#038;','&'),cookies),16,iconimage,fanart,description,'','')
        else:
            description = '[B]ESCOLHA EM QUAL IDIOMA VOCÊ PREFERE ASSISTIR![/B]'
            addDir('[B][COLOR white]ASSISTIR DUBLADO[/COLOR][/B]',[('#animes6_temp_dub=', seasons[1], cookies, dir_name)],22,iconimage,fanart,description,'','')
            addDir('[B][COLOR white]ASSISTIR LEGENDADO[/COLOR][/B]',[('#animes6_temp_dub=', seasons[0], cookies, dir_name)],22,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#animes6_temp_dub=' in url:
        xbmcgui.Dialog().ok("Aviso:", "[B]Servidor removido por direitos autorais.[/B]")
        xbmcplugin.endOfDirectory(addon_handle)
        exit()
        import ast
        url = ast.literal_eval(url)
        season = url[0][1]
        cookies = url[0][2]
        dir_name = url[0][3]
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%dir_name,'here',22,iconimage,fanart,description,'','')
        season = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(season)
        for link,title in season:
            addLink('[B]%s[/B]'%title.upper(),'\x78\x70\x61\x6e\x69\x6d\x65\x73\x3d\x25\x73\x7c\x25\x73'%(link.replace('&#038;','&'),cookies),16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#animes_list='):
        series = url.split('#animes_list=')[1]
        series = series.split('|')
        counter = 1
        name = name.replace('[B][COLOR white]●[/COLOR][/B] ','')
        if not description:
            description = '[B][COLOR white]OS MELHORES ANIMES EM UM SÓ LUGAR[/COLOR][/B]'
        for serie in series:
            if serie.startswith('animes1='):
                title = '[B][COLOR blue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 22
            elif serie.startswith('animes2='):
                title = '[B][COLOR red]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 22
            elif serie.startswith('animes3='):
                title = '[B][COLOR lime]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 22
            elif serie.startswith('animes4='):
                title = '[B][COLOR yellow]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 22
            elif serie.startswith('animes5='):
                title = '[B][COLOR gold]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 22
            elif serie.startswith('animes6='):
                title = '[B][COLOR darkorange]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 22
            else:
                continue
            addDir(title,serie,mode_select,iconimage,fanart,description,'','')
            counter = counter + 1
        xbmcplugin.endOfDirectory(addon_handle)
    elif url == '#animes_menu':
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x41\x6e\x69\x6d\x65\x73\x42\x61\x73\x65'
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]PESQUISAR ANIMES[/COLOR][/B]','#pesquisar_animes',22,iconimage,fanart,'[B][COLOR white]PESQUISE SEU ANIME FAVORITO[/COLOR][/B]','','')
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]TODOS ANIMES[/COLOR][/B]',link,1,iconimage,fanart,'[B][COLOR white]OS MELHORES ANIMES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#pesquisar_animes'):
        if pesquisa_desativar == 'false':
            if search == '':
                search = get_search_string('PESQUISE SEU ANIME FAVORITO')
                if search:
                    if search == '' or search == ' ' or search == '  ':
                        pesquisa_desativar = 'false'
                        search = ''
                        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                    pesquisa_desativar = 'true'
                    pesquisar_animes()
                    xbmcplugin.endOfDirectory(addon_handle)
                    monitor_switch()
                    xbmc.executebuiltin('Container.SetViewMode(54)')
                else:
                    pesquisa_desativar = 'false'
                    search = ''
                    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        else:
            pesquisar_animes()
            xbmcplugin.endOfDirectory(addon_handle)
            monitor_switch()
            xbmc.executebuiltin('Container.SetViewMode(54)')
elif mode==23:
    if 'serie=' in url:
        if six.PY2: notify("[B]Recomendamos assistir essa série no [COLOR gold]Kodi 20.4[/COLOR] ou superior.[/B]")
        from collections import OrderedDict
        url = url.replace('serie=','')
        hosts = ['\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x2e\x69\x6e\x2f\x73\x65\x72\x69\x65\x2f\x6f\x6e\x6c\x69\x6e\x65\x2f',
        '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x2e\x74\x76\x2f\x73\x65\x72\x69\x65\x2f\x6f\x6e\x6c\x69\x6e\x65\x2f',
        '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x66\x69\x6c\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x76\x69\x7a\x65\x72\x2e\x63\x6f\x6d\x2f\x73\x65\x72\x69\x65\x2f\x6f\x6e\x6c\x69\x6e\x65\x2f'
        ]
        for host_url in hosts:
            base = ''
            base = getMovieData(host_url + url)
            if '\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x61\x73\x6f\x6e\x73\x22\x3e' in base:
                break
        base = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x61\x73\x6f\x6e\x73\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x63\x6c\x65\x61\x72\x66\x69\x78\x22\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        temp = re.compile('\x64\x61\x74\x61\x2d\x73\x65\x61\x73\x6f\x6e\x2d\x69\x64\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)
        if len(temp) > 1:
            for temp_id, number in temp:
                link = temp_id
                name = number.replace('º','ª')
                addDir('[B][COLOR white]%s[/COLOR][/B]'%name,'#id='+link,23,iconimage,fanart,description,'','')
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            for temp_id, number in temp:
                link = temp_id
                name = number.replace('º','ª')
                myid = link.replace('#id=','')
                temp = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x74\x76\x2e\x69\x6e\x2f\x69\x6e\x63\x6c\x75\x64\x65\x73\x2f\x61\x6a\x61\x78\x2f\x70\x75\x62\x6c\x69\x63\x46\x75\x6e\x63\x74\x69\x6f\x6e\x73\x2e\x70\x68\x70',post={'getEpisodes':str(myid)})
                tempjson = json.loads(temp, object_pairs_hook=OrderedDict)
                temp = tempjson.get('list')
                addLink('[B][COLOR gold]%s[/COLOR][/B]'%name,'here',16,iconimage,fanart,description,'','')
                for value in temp:
                    my_id = temp.get(value).get('id')
                    my_name = 'EPISÓDIO ' + temp.get(value).get('name')
                    addLink('[B]%s[/B]'%my_name.upper(),'serie='+my_id+'.mp4',16,iconimage,fanart,description,'','')
            xbmcplugin.endOfDirectory(addon_handle)
    elif '#id=' in url:
        from collections import OrderedDict
        myid = url.replace('#id=','')
        temp = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x76\x69\x7a\x65\x72\x74\x76\x2e\x69\x6e\x2f\x69\x6e\x63\x6c\x75\x64\x65\x73\x2f\x61\x6a\x61\x78\x2f\x70\x75\x62\x6c\x69\x63\x46\x75\x6e\x63\x74\x69\x6f\x6e\x73\x2e\x70\x68\x70',post={'getEpisodes':str(myid)})
        tempjson = json.loads(temp, object_pairs_hook=OrderedDict)
        temp = tempjson.get('list')
        addLink(name.replace('[COLOR white]','[COLOR gold]'),'here',16,iconimage,fanart,'','','')
        for value in temp:
            my_id = temp.get(value).get('id')
            my_name = 'EPISÓDIO ' + temp.get(value).get('name')
            addLink('[B]%s[/B]'%my_name.upper(),'serie='+my_id+'.mp4',16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
elif mode==24:
    if 'tseries=' in url:
        url = url.replace('tseries=','')
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x74\x75\x61\x73\x65\x72\x69\x65\x2e\x6e\x65\x74\x2f\x70\x74\x2d\x62\x72\x2f\x73\x65\x72\x69\x65\x73\x2f\x61\x73\x73\x69\x73\x74\x69\x72\x2d\x25\x73\x2d\x6f\x6e\x6c\x69\x6e\x65\x2f'%url
        url = getMovieData(link)
        url = url.replace('se-t se-o','se-t')
        dados = re.compile("<span class='se-t'>.+?</span><span class='title'>(.+?)<i>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
        try:
            if len(dados) > 1:
                for data in dados:
                    temp = data.upper()
                    temp = temp.replace('TEMPORADA ','').replace(' ','')
                    temp = temp + 'ª TEMPORADA'
                    addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,link+'#temp='+str(data),24,iconimage,fanart,description,'','')
                xbmcplugin.endOfDirectory(addon_handle)
            else:
                listar = re.compile("<span class='se-t'>.+?</span><span class='title'>"+dados[0]+'<i>(.+?)</div></div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                episodios = re.compile("<img src='(.+?)'>.+?<a href='(.+?)'>(.+?)</a>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
                temp = dados[0].upper()
                temp = temp.replace('TEMPORADA ','').replace(' ','')
                temp = temp + 'ª TEMPORADA'
                addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',24,iconimage,fanart,description,'','')
                for img,link,title in episodios:
                    addLink('[B]%s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
                xbmcplugin.endOfDirectory(addon_handle)
        except:
            notify('[B][COLOR gold]SÉRIE INDISPONÍVEL![/COLOR][/B]')
            exit()
    elif '#temp=' in url:
        temp = url.split('#temp=')[1]
        url = url.split('#temp=')[0]
        url = getMovieData(url)
        url = url.replace('se-t se-o','se-t')
        listar = re.compile("<span class='se-t'>.+?</span><span class='title'>"+temp+'<i>(.+?)</div></div>', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
        episodios = re.compile("<img src='(.+?)'>.+?<a href='(.+?)'>(.+?)</a>", re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
        if len(episodios) == 0:
            notify('[B][COLOR gold]TEMPORADA INDISPONÍVEL![/COLOR][/B]')
            exit()
        temp = temp.upper()
        temp = temp.replace('TEMPORADA ','').replace(' ','')
        temp = temp + 'ª TEMPORADA'
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',16,iconimage,fanart,description,'','')
        for img,link,title in episodios:
            addLink('[B]%s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
elif mode==25:
    if url.startswith('novelas='):
        def novelas_get(host_base):
            url = getMovieData(host_base,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x61\x75\x64\x65\x65\x66\x69\x74\x6e\x65\x73\x73\x2e\x74\x6f\x70\x2f').replace('${chapterStr}','')
            success = ['\x63\x6f\x6e\x73\x74\x20\x74\x65\x6d\x70\x6f\x72\x61\x64\x61\x73','\x6c\x65\x74\x20\x74\x6f\x74\x61\x6c\x43\x68\x61\x70\x74\x65\x72\x73','\x6c\x65\x74\x20\x6f\x72\x69\x67\x69\x6e\x61\x6c\x55\x72\x6c','\x3c\x6f\x70\x74\x69\x6f\x6e\x20\x76\x61\x6c\x75\x65\x3d\x22']
            if not any(x in url for x in success):
                url = custom_proxy(host_base,'\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x61\x75\x64\x65\x65\x66\x69\x74\x6e\x65\x73\x73\x2e\x74\x6f\x70\x2f').replace('${chapterStr}','')
            if any(x in url for x in success):
                return url
            return ''
        url_404 = url.split('novelas=')[1].split('#')[1]
        server = url.split('novelas=')[1].split('#')[0]
        url = ''
        host_base = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6e\x6f\x76\x65\x66\x78\x2e\x62\x69\x7a\x2f\x6e\x6f\x76\x6f\x66\x6f\x72\x6d\x61\x74\x6f\x2f\x6e\x6f\x76\x2f\x25\x73\x2f\x25\x73\x2e\x70\x68\x70'%(server,url_404)
        if server == 'psn':
            host_base = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6e\x6f\x76\x65\x66\x78\x2e\x62\x69\x7a\x2f\x25\x73\x2f\x6e\x6f\x76\x65\x6c\x61\x73\x2f\x25\x73\x2e\x70\x68\x70'%(server,url_404)
            url = novelas_get(host_base)
            if not url:
                url = novelas_get('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x6e\x6f\x76\x65\x66\x78\x2e\x62\x69\x7a\x2f\x25\x73\x2f\x73\x65\x72\x69\x65\x73\x2f\x25\x73\x2e\x70\x68\x70'%(server,url_404))
        if not url:
            url = novelas_get(host_base)
        succeeded = False
        if '\x63\x6f\x6e\x73\x74\x20\x74\x65\x6d\x70\x6f\x72\x61\x64\x61\x73' in url and '\x6c\x65\x74\x20\x6f\x72\x69\x67\x69\x6e\x61\x6c\x55\x72\x6c' in url:
            succeeded = True
            pattern = "\x63\x6f\x6e\x73\x74\x20\x74\x65\x6d\x70\x6f\x72\x61\x64\x61\x73\x20\x3d\x20\x28\x5c\x5b\x2e\x2a\x3f\x5c\x5d\x29\x3b"
            match = re.search(pattern, url, re.S)
            original_url_pattern = "\x6c\x65\x74\x20\x6f\x72\x69\x67\x69\x6e\x61\x6c\x55\x72\x6c\x5c\x73\x2a\x3d\x5c\x73\x2a\x60\x28\x5b\x5e\x60\x5d\x2b\x29\x60\x3b"
            original_url = re.search(original_url_pattern, url)
            original_url = original_url.group(1) if original_url else None
            if match:
                json_data = match.group(1)
                json_data = re.sub(r',\s*\]', ']', json_data)
                json_data = re.sub(r'([{,]\s*)(\w+)\s*:', r'\1"\2":', json_data)
                temporadas = json.loads(json_data)
                for season in temporadas:
                    title = '%sª TEMPORADA'%season.get('nome').replace('TEMPORADA','').strip()
                    link = 'url=%s&episodes=%s|%s'%(original_url,season.get('inicio'),season.get('fim'))
                    addDir('[B][COLOR white]%s[/COLOR][/B]'%title,'novelas_temp='+link,25,iconimage,fanart,description,'','')
        elif '\x6c\x65\x74\x20\x74\x6f\x74\x61\x6c\x43\x68\x61\x70\x74\x65\x72\x73' in url and '\x6c\x65\x74\x20\x6f\x72\x69\x67\x69\x6e\x61\x6c\x55\x72\x6c' in url or '\x6c\x65\x74\x20\x6f\x72\x69\x67\x69\x6e\x61\x6c\x55\x72\x6c' in url and '\x77\x68\x69\x6c\x65\x20\x28\x63\x68\x61\x70\x74\x65\x72\x73\x41\x64\x64\x65\x64' in url:
            succeeded = True
            total_chapters_pattern = "\x6c\x65\x74\x20\x74\x6f\x74\x61\x6c\x43\x68\x61\x70\x74\x65\x72\x73\x5c\x73\x2a\x3d\x5c\x73\x2a\x28\x5c\x64\x2b\x29\x3b"
            original_url_pattern = "\x6c\x65\x74\x20\x6f\x72\x69\x67\x69\x6e\x61\x6c\x55\x72\x6c\x5c\x73\x2a\x3d\x5c\x73\x2a\x60\x28\x5b\x5e\x60\x5d\x2b\x29\x60\x3b"
            if not '\x6c\x65\x74\x20\x74\x6f\x74\x61\x6c\x43\x68\x61\x70\x74\x65\x72\x73' in url and '\x77\x68\x69\x6c\x65\x20\x28\x63\x68\x61\x70\x74\x65\x72\x73\x41\x64\x64\x65\x64' in url:
                total_chapters_pattern = "\x63\x68\x61\x70\x74\x65\x72\x73\x41\x64\x64\x65\x64\x5c\x73\x2a\x3c\x5c\x73\x2a\x28\x5c\x64\x2b\x29"
            total_chapters = re.search(total_chapters_pattern, url)
            original_url = re.search(original_url_pattern, url)
            total_chapters = int(total_chapters.group(1)) if total_chapters else None
            original_url = original_url.group(1) if original_url else None
            chapter_numbers = [i for i in range(1, total_chapters + 1)]
            chapter_urls = [("{}{:03}".format(original_url,num),'CAPÍTULO %s'%num) for num in chapter_numbers]
            for episode,title in chapter_urls:
                addLink('[B]%s[/B]'%title,'novelas_play='+episode,16,iconimage,fanart,description,'','')
            if '\x3c\x62\x3e\x46\x49\x4e\x41\x4c\x49\x5a\x41\x44\x41\x3c\x2f\x62\x3e' in url:
                addLink('[B][COLOR gold]FINALIZADA![/COLOR][/B]','here',16,iconimage,fanart,description,'','')
        elif '\x3c\x6f\x70\x74\x69\x6f\x6e\x20\x76\x61\x6c\x75\x65\x3d\x22' in url:
            succeeded = True
            pattern = '\x3c\x6f\x70\x74\x69\x6f\x6e\x20\x76\x61\x6c\x75\x65\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x3e\x2e\x5c\x73\x28\x2e\x2a\x3f\x29\x3c\x5c\x2f\x6f\x70\x74\x69\x6f\x6e\x3e'
            episodes = re.findall(pattern, url)
            for link,title in episodes:
                title = title.replace('Episódio 0','CAPÍTULO ').replace('Episódio','CAPÍTULO')
                if 'CAPÍTULO' in title:
                    addLink('[B]%s[/B]'%title,'novelas_play='+link,16,iconimage,fanart,description,'','')
            if '\x4e\x4f\x56\x45\x4c\x41\x20\x43\x4f\x4d\x50\x4c\x45\x54\x41\x21' in url:
                addLink('[B][COLOR gold]FINALIZADA![/COLOR][/B]','here',16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=succeeded)
    elif url.startswith('novelas_temp='):
        url = url.split('novelas_temp=')[1]
        episodes = [int(num) for num in url.split('episodes=')[1].split('&')[0].split('|')]
        url = url.split('url=')[1].split('&')[0]
        addLink(name.replace('[COLOR white]','[COLOR gold]'),'here',16,iconimage,fanart,description,'','')
        for episode in range(episodes[0],episodes[1]+1):
            title = 'CAPÍTULO %s'%episode
            link = '{}{:03}'.format(url,episode)
            addLink('[B]%s[/B]'%title,'novelas_play='+link,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('novelas2='):
        link = url.split('novelas2=')[1]
        url = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x61\x73\x6b\x66\x6c\x69\x78\x2e\x62\x69\x7a\x2f\x73\x65\x72\x69\x65\x73\x2f\x25\x73\x2f'%link).replace("'",'"')
        if not '\x3c\x75\x6c\x20\x69\x64\x3d\x22\x65\x70\x69\x73\x6f\x64\x65\x5f\x62\x79\x5f\x74\x65\x6d\x70\x22' in url:
            url = custom_proxy('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x61\x73\x6b\x66\x6c\x69\x78\x2e\x62\x69\x7a\x2f\x73\x65\x72\x69\x65\x73\x2f\x25\x73\x2f'%link)
        status = '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x73\x65\x61\x73\x6f\x6e\x73\x22\x3e' in url
        if status:
            res_results = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x71\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x74\x69\x74\x6c\x65\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)
            res_dict = {}
            for result in res_results:
                listar = re.compile(str(result)+'\x3c\x2f\x73\x70\x61\x6e\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                list_result = re.compile('\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
                res_dict.update({result: list_result})
            if len(res_dict) > 1:
                temp = 1
                for key, items in res_dict.items():
                    addDir('[B][COLOR white]%sª TEMPORADA[/COLOR][/B]'%temp,'#novelas2_temp=%s'%items,25,iconimage,fanart,description,'','')
                    temp += 1
            else:
                res_dict = list(res_dict.items())[0][1]
                for episode, title in res_dict:
                    addLink('[B]%s[/B]'%title.upper(),episode,16,iconimage,fanart,description,'','')
        else:
            xbmcgui.Dialog().ok('Aviso:', '[B]Acesso bloqueado pela sua internet.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore[/COLOR][/B]')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=status)
    elif url.startswith('#novelas2_temp='):
        import ast
        addLink(name.replace('[COLOR white]','[COLOR gold]'),'here',16,iconimage,fanart,description,'','')
        res_dict = ast.literal_eval(url.split('#novelas2_temp=')[1])
        for episode, title in res_dict:
            addLink('[B]%s[/B]'%title.upper(),episode,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#novelas_menu'):
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x30\x37\x66\x31\x66\x34\x63\x64\x31\x62\x32\x30\x33\x63\x62\x66\x32\x65\x66\x65\x63\x39\x35\x39\x63\x34\x65\x38\x36\x34\x35\x61\x2f\x72\x61\x77\x2f\x6e\x6f\x76\x65\x6c\x61\x73\x2e\x78\x6d\x6c'
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]PESQUISAR NOVELAS[/COLOR][/B]','#pesquisar_novelas',25,iconimage,fanart,'[B][COLOR white]PESQUISE SUA NOVELA FAVORITA[/COLOR][/B]','','')
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]TODAS NOVELAS[/COLOR][/B]',link,1,iconimage,fanart,'[B][COLOR white]AS MELHORES NOVELAS DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#pesquisar_novelas'):
        if pesquisa_desativar == 'false':
            if search == '':
                search = get_search_string('PESQUISE SUA NOVELA FAVORITA')
                if search:
                    if search == '' or search == ' ' or search == '  ':
                        pesquisa_desativar = 'false'
                        search = ''
                        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                    pesquisa_desativar = 'true'
                    pesquisar_novelas()
                    xbmcplugin.endOfDirectory(addon_handle)
                    monitor_switch()
                    xbmc.executebuiltin('Container.SetViewMode(54)')
                else:
                    pesquisa_desativar = 'false'
                    search = ''
                    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        else:
            pesquisar_novelas()
            xbmcplugin.endOfDirectory(addon_handle)
            monitor_switch()
            xbmc.executebuiltin('Container.SetViewMode(54)')
elif mode==26:
    if url.startswith('serie2='):
        if six.PY2: notify("[B]Recomendamos assistir essa série no [COLOR gold]Kodi 20.4[/COLOR] ou superior.[/B]")
        url = url.replace('serie2=','')
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x73\x75\x70\x65\x72\x74\x65\x6c\x61\x2e\x77\x66\x2f\x73\x65\x72\x69\x65\x73\x2f' + url
        url = getMovieData(link)
        try:
            dados = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x63\x74\x69\x6f\x6e\x2d\x73\x65\x61\x73\x6f\x6e\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
            dados = re.compile('\x3c\x6c\x69\x20\x64\x61\x74\x61\x2d\x69\x64\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x20\x64\x61\x74\x61\x2d\x74\x65\x6d\x70\x3d\x22\x2e\x2b\x3f\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x6c\x69\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(dados)
        except:
            notify('[B]Houve um problema na conexão - Tente novamente mais tarde.[/B]')
            exit()
        try:
            if len(dados) > 1:
                for season,data in dados:
                    temp = data.upper()
                    temp = temp.replace('TEMPORADA ','').replace(' ','')
                    temp = temp + 'ª TEMPORADA'
                    addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,link+'#temp='+str(season),26,iconimage,fanart,description,'','')
                xbmcplugin.endOfDirectory(addon_handle)
            else:
                listar = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x61\x73\x6f\x6e\x2d\x69\x74\x65\x6e\x73\x22\x20\x69\x64\x3d\x22\x69\x74\x65\x6d\x2d\x31\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                episodios = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x2d\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x63\x6c\x61\x73\x73\x3d\x22\x73\x75\x62\x74\x69\x74\x6c\x65\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e\x2e\x2b\x3f\x63\x6c\x61\x73\x73\x3d\x22\x69\x6e\x66\x6f\x2d\x65\x70\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
                temp = dados[0][1].upper()
                temp = temp.replace('TEMPORADA ','').replace(' ','')
                temp = temp + 'ª TEMPORADA'
                addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',26,iconimage,fanart,description,'','')
                for link,img,subtitle,title in episodios:
                    if subtitle.upper() == title.upper():
                        addLink('[B]EPISÓDIO %s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
                    else:
                        addLink('[B]EPISÓDIO %s[/B] - %s'%(title.upper(),subtitle.upper()),link,16,iconimage,fanart,description,'','')
                xbmcplugin.endOfDirectory(addon_handle)
        except:
            notify('[B][COLOR gold]SÉRIE INDISPONÍVEL![/COLOR][/B]')
            exit()
    elif '#temp=' in url:
        temp = url.split('#temp=')[1]
        url = url.split('#temp=')[0]
        url = getMovieData(url)
        listar = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x61\x73\x6f\x6e\x2d\x69\x74\x65\x6e\x73\x22\x20\x69\x64\x3d\x22'+temp+'\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
        episodios = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x73\x72\x63\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x63\x6c\x61\x73\x73\x3d\x22\x73\x75\x62\x74\x69\x74\x6c\x65\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e\x2e\x2b\x3f\x63\x6c\x61\x73\x73\x3d\x22\x69\x6e\x66\x6f\x2d\x65\x70\x22\x3e\x2e\x2b\x3f\x3c\x73\x70\x61\x6e\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
        if len(episodios) == 0:
            notify('[B][COLOR gold]TEMPORADA INDISPONÍVEL![/COLOR][/B]')
            exit()
        addLink(name.replace('[COLOR white]','[COLOR gold]'),'here',16,iconimage,fanart,description,'','')
        for link,img,subtitle,title in episodios:
            if subtitle.upper() == title.upper():
                addLink('[B]EPISÓDIO %s[/B]'%title.upper(),link,16,iconimage,fanart,description,'','')
            else:
                addLink('[B]EPISÓDIO %s[/B] - %s'%(title.upper(),subtitle.upper()),link,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('serie3='):
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x2f\x25\x73\x2f'%(OVERFLIXTV_HOST,url.split('serie3=')[1])
        base = getMovieData(link).replace("'",'"')
        if not re.findall('\x3c\x75\x6c\x20\x63\x6c\x61\x73\x73\x3d\x22\x6c\x69\x73\x74\x61\x22\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x75\x6c\x3e', base, re.MULTILINE|re.DOTALL|re.IGNORECASE):
            xbmcgui.Dialog().ok("Aviso:", "[B]Conteúdo não encontrado![CR][COLOR gold]Pode ter sido removido por direitos autorais.[/COLOR][/B]")
            exit()
        html = re.compile('\x3c\x75\x6c\x20\x63\x6c\x61\x73\x73\x3d\x22\x6c\x69\x73\x74\x61\x22\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x75\x6c\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        seasons = re.compile('\x6c\x6f\x61\x64\x5c\x28\x28\x2e\x2a\x3f\x29\x5c\x29', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
        if len(seasons) > 1:
            for season in seasons:
                temp = '%sª TEMPORADA'%season
                addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,'serie3_temp=%s/?temporada=%s'%(link,season),26,iconimage,fanart,description,'','')
        else:
            html = re.compile('\x3c\x75\x6c\x20\x69\x64\x3d\x22\x6c\x69\x73\x74\x61\x67\x65\x6d\x22\x3e\x28\x2e\x2a\x3f\x29\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x76\x62\x54\x61\x62\x53\x6c\x69\x64\x65\x72\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
            episodes = re.compile('\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
            addLink('[B][COLOR gold]%sª TEMPORADA[/COLOR][/B]'%seasons[0],'here',26,iconimage,fanart,description,'','')
            for url,episode in episodes:
                episode = episode.replace('Episódio','EPISÓDIO')
                addLink('[B]%s[/B]'%episode.upper(),url,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('serie3_temp='):
        base = getMovieData(url.split('serie3_temp=')[1])
        html = re.compile('\x3c\x75\x6c\x20\x69\x64\x3d\x22\x6c\x69\x73\x74\x61\x67\x65\x6d\x22\x3e\x28\x2e\x2a\x3f\x29\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x76\x62\x54\x61\x62\x53\x6c\x69\x64\x65\x72\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        episodes = re.compile('\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2a\x3f\x29\x22\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x61\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(html)
        addLink(name.replace('[COLOR white]','[COLOR gold]'),'here',16,iconimage,fanart,description,'','')
        for url,episode in episodes:
            episode = episode.replace('Episódio','EPISÓDIO')
            addLink('[B]%s[/B]'%episode.upper(),url,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('seriecdn='):
        from collections import OrderedDict
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x65\x6d\x62\x65\x64\x2e\x77\x61\x72\x65\x7a\x63\x64\x6e\x2e\x6c\x69\x6e\x6b\x2f\x73\x65\x72\x69\x65\x2f\x25\x73'%url.split('seriecdn=')[1]
        base = getMovieData(link)
        host = urlparse(link).netloc
        if not 'cachedSeasons' in base:
            xbmcgui.Dialog().ok('Aviso:', '[B]Verifique se há bloqueios em sua conexão.[CR][COLOR gold]Use DNS ou o APP 1.1.1.1 + WARP da Playstore.[/COLOR][/B]')
            exit()
        cachedSeasons = re.compile('\x63\x61\x63\x68\x65\x64\x53\x65\x61\x73\x6f\x6e\x73\x20\x3d\x20\x22\x28\x2e\x2a\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(base)[0]
        base_link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x25\x73\x2f\x25\x73'%(host,cachedSeasons)
        base = getMovieData(base_link, link)
        base_json = json.loads(base, object_pairs_hook=OrderedDict)
        seasons = base_json.get('seasons')
        if base_json.get('seasonCount') > 1:
            for index,season in seasons.items():
                temp = seasons.get(index).get('name') + 'ª TEMPORADA'
                addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[('seriecdn_temp=',index,base_link,link)],26,iconimage,fanart,description,'','')
        else:
            number = [index for index,value in seasons.items()][0]
            temp = seasons.get(number).get('name') + 'ª TEMPORADA'
            episodes = seasons.get(number).get('episodes')
            addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',16,iconimage,fanart,description,'','')
            for cdn_number,value in episodes.items():
                addLink('[B]EPISÓDIO %s[/B]'%value.get('name'),'seriecdn=%s#%s'%(value.get('id'),link),16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif 'seriecdn_temp=' in url:
        import ast,json
        from collections import OrderedDict
        url = ast.literal_eval(url)
        number = url[0][1]
        base_link = url[0][2]
        refer = url[0][3]
        base = getMovieData(base_link,refer)
        episodes = json.loads(base, object_pairs_hook=OrderedDict).get('seasons').get(number).get('episodes')
        addLink(name.replace('[COLOR white]','[COLOR gold]'),'here',16,iconimage,fanart,description,'','')
        for cdn_number,value in episodes.items():
            addLink('[B]EPISÓDIO %s[/B]'%value.get('name'),'seriecdn=%s#%s'%(value.get('id'),refer),16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
elif mode==27:
    if url.startswith('#filmes_menu'):
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x35\x62\x38\x37\x37\x39\x37\x33\x32\x39\x63\x37\x62\x34\x36\x34\x32\x32\x35\x36\x35\x66\x66\x62\x61\x61\x62\x33\x62\x65\x37\x65\x2f\x72\x61\x77\x2f\x25\x73'
        menu_list = [
            ('GÊNEROS','#filmes_por_generos_menu',27,'https://i.imgur.com/xV7RPua.jpg','https://i.imgur.com/eWpI9V3.jpg','[B][COLOR white]FILMES ORGANIZADOS POR [COLOR gold]GÊNERO[/COLOR][/COLOR][/B]'),
            ('LANÇAMENTOS',link%'lancamentos.xml',1,'https://i.imgur.com/WETopHh.jpg','https://image.tmdb.org/t/p/original/orjiB3oUIsyz60hoEqkiGpy5CeO.jpg','[B][COLOR white]OS MELHORES [COLOR gold]LANÇAMENTOS[/COLOR][/COLOR][/B]'),
            ('ORDEM ALFABÉTICA','#movies_pages=%s'%(link%'page.xml#1'),27,'https://i.imgur.com/osBDac3.jpg','https://i.imgur.com/225XKdt.jpg','[B][COLOR white]OS MELHORES FILMES EM [COLOR gold]ORDEM ALFABÉTICA[/COLOR][/COLOR][/B]'),
            ('TRILOGIA','#trilogias_list',3,'https://i.imgur.com/CVxxV3r.jpg','https://image.tmdb.org/t/p/original/hziiv14OpD73u9gAak4XDDfBKa2.jpg','[B][COLOR white]OS MELHORES FILMES [COLOR gold]TRILOGIA[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]')
        ]
        addDir('[B][COLOR blue]●[/COLOR] [COLOR white]PESQUISE POR FILMES[/COLOR][/B]','#home=search_movies#',6,iconimage,fanart,'[B][COLOR white]PESQUISE O SEU FILME FAVORITO[/COLOR][/B]','','')
        for title,url,mode,thumb,fanArt,info in menu_list:
            title = '[B][COLOR white]CATEGORIA: [COLOR gold]%s[/COLOR][/COLOR][/B]'%title
            addDir(title,url,mode,thumb,fanArt,info,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#filmes_por_generos_menu'):
        link = '\x23\x6d\x6f\x76\x69\x65\x73\x5f\x70\x61\x67\x65\x73\x3d\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x35\x62\x38\x37\x37\x39\x37\x33\x32\x39\x63\x37\x62\x34\x36\x34\x32\x32\x35\x36\x35\x66\x66\x62\x61\x61\x62\x33\x62\x65\x37\x65\x2f\x72\x61\x77\x2f\x25\x73'
        menu_list = [
            ('ANIMAÇÃO', 'animacao.xml#1', 27, 'https://i.imgur.com/kR943xO.jpg', 'https://pt.best-wallpaper.net/wallpaper/3840x2160/1607/Cartoon-movie-Hotel-Transylvania-2_3840x2160.jpg'),
            ('AVENTURA', 'aventura.xml#1', 27, iconimage, fanart),
            ('AÇÃO', 'acao.xml#1', 27, iconimage, fanart),
            ('CINEMA TV', 'cinematv.xml#1', 27, iconimage, fanart),
            ('COMÉDIA', 'comedia.xml#1', 27, iconimage, fanart),
            ('CRIME', 'crime.xml#1', 27, iconimage, fanart),
            ('DOCUMENTÁRIO', 'documentario.xml#1', 27, 'https://i.imgur.com/sy3hO5d.jpg', fanart),
            ('DRAMA', 'drama.xml#1', 27, iconimage, fanart),
            ('FAMÍLIA', 'familia.xml#1', 27, iconimage, fanart),
            ('FANTASIA', 'fantasia.xml#1', 27, iconimage, fanart),
            ('FAROESTE', 'faroeste.xml#1', 27, iconimage, fanart),
            ('FICÇÃO CIENTÍFICA', 'ficcaocientifica.xml#1', 27, iconimage, 'https://www.wallpaperup.com/uploads/wallpapers/2013/09/09/145600/e5f68c072dea5a38da9c9db848abf166-700.jpg'),
            ('GUERRA', 'guerra.xml#1', 27, 'https://i.imgur.com/dFl8K9y.jpg', 'https://images8.alphacoders.com/724/724296.png'),
            ('HISTÓRIA', 'historia.xml#1', 27, iconimage, fanart),
            ('MISTÉRIO', 'misterio.xml#1', 27, iconimage, fanart),
            ('MÚSICA', 'musica.xml#1', 27, iconimage, fanart),
            ('ROMANCE', 'romance.xml#1', 27, iconimage, fanart),
            ('SUSPENSE', 'suspense.xml#1', 27, iconimage, fanart),
            ('TERROR', 'terror.xml#1', 27, 'https://i.imgur.com/YRuqdGo.jpg', 'https://natysign.files.wordpress.com/2011/08/silent-hill-wallpaper-9.jpg'),
            ('THRILLER', 'thriller.xml#1', 27, iconimage, fanart),
        ]
        for title,url,mode,thumb,fanArt in menu_list:
            url = link%url
            title = '[B][COLOR white]CATEGORIA: [COLOR gold]%s[/COLOR][/COLOR][/B]'%title
            addDir(title,url,mode,thumb,fanArt,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#series_menu'):
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x53\x65\x72\x69\x65\x73\x42\x61\x73\x65'
        try:
            if features_enable == 'true' and not features_pass == '':
                hashed_pw_verify = features_checker()
                if hashed_pw_verify:
                    link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'srs'
        except:
            pass
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]PESQUISAR SÉRIES[/COLOR][/B]','#pesquisar_series',20,iconimage,fanart,'[B][COLOR white]PESQUISE SUA SÉRIE FAVORITA[/COLOR][/B]','','')
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]TODAS SÉRIES[/COLOR][/B]',link,1,iconimage,fanart,'[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#series_list='):
        series = url.split('#series_list=')[1]
        series = series.split('|')
        counter = 1
        name = name.replace('[B][COLOR white]●[/COLOR][/B] ','')
        if not description:
            description = '[B][COLOR white]AS MELHORES SÉRIES DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]'
        for serie in series:
            if serie.startswith('serie2='):
                title = '[B][COLOR blue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 26
            elif serie.startswith('serie3='):
                title = '[B][COLOR dodgerblue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 26
            elif serie.startswith('ntcdn_tvshows='): #Reservado
                title = '[B][COLOR orangered]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('seriecdn='):
                title = '[B][COLOR orange]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 26
            elif serie.startswith('sfserie='):
                title = '[B][COLOR yellow]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 29
                try:
                    serie = base64.b64decode(serie.split('sfserie=')[1]).decode('utf-8')
                    serie = 'sfserie=' + serie
                except:
                    pass
            elif serie.startswith('wvmob='):
                title = '[B][COLOR gold]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 30
                try:
                    serie = base64.b64decode(serie.split('wvmob=')[1]).decode('utf-8')
                    serie = 'wvmob=' + serie
                except:
                    pass
            elif serie.startswith('resolver1_tvshows='):
                title = '[B][COLOR yellow]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('resolver2_tvshows='):
                title = '[B][COLOR lime]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('resolver3_tvshows='):
                title = '[B][COLOR skyblue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('resolver4_tvshows='):
                title = '[B][COLOR mediumslateblue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('onedrive='):
                title = '[B][COLOR darkorange]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('tseries='):
                title = '[B][COLOR gold]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 24
            elif serie.startswith('serie='):
                title = '[B][COLOR red]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 23
                try:
                    serie = base64.b64decode(serie.split('serie=')[1]).decode('utf-8')
                    serie = 'serie=' + serie
                except:
                    pass
            elif serie.startswith('desenhos='):
                title = '[B][COLOR orange]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 28
            elif serie.startswith('desenhos2='):
                title = '[B][COLOR red]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 28
            elif serie.startswith('rede='):
                serie = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x65\x64\x65\x63\x61\x6e\x61\x69\x73\x2e\x63\x78\x2f\x62\x72\x6f\x77\x73\x65\x2d' + serie.replace('rede=','') + '\x2d\x76\x69\x64\x65\x6f\x73\x2d\x31\x2d\x64\x61\x74\x65\x2e\x68\x74\x6d\x6c'
                title = '[B][COLOR red]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 7
            else:
                continue
            addDir(title,serie,mode_select,iconimage,fanart,description,'','')
            counter = counter + 1
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#novelas_list='):
        series = url.split('#novelas_list=')[1]
        series = series.split('|')
        counter = 1
        name = name.replace('[B][COLOR white]●[/COLOR][/B] ','')
        if not description:
            description = '[B][COLOR white]AS MELHORES NOVELAS EM UM SÓ LUGAR[/COLOR][/B]'
        for serie in series:
            if serie.startswith('rede='):
                serie = serie.replace('rede=','')
                serie = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x72\x65\x64\x65\x63\x61\x6e\x61\x69\x73\x2e\x63\x78\x2f\x62\x72\x6f\x77\x73\x65\x2d' + serie + '\x2d\x76\x69\x64\x65\x6f\x73\x2d\x31\x2d\x64\x61\x74\x65\x2e\x68\x74\x6d\x6c'
                title = '[B][COLOR red]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 7
            elif serie.startswith('novelas='):
                title = '[B][COLOR gold]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 25
            elif serie.startswith('novelas2='):
                title = '[B][COLOR blue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 25
            elif serie.startswith('resolver1_tvshows='):
                title = '[B][COLOR yellow]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('resolver3_tvshows='):
                title = '[B][COLOR skyblue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            else:
                continue
            addDir(title,serie,mode_select,iconimage,fanart,description,'','')
            counter = counter + 1
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#movies_pages='):
        url,page = url.split('#movies_pages=')[1].split('#')
        html = getMovieData(url)
        total = re.findall('<page_\d.*?>',html)
        nextpage = False
        if total and not page == '1':
            total = int(total[-1].replace('<page_','').replace('>',''))
            dialog = xbmcgui.Dialog()
            atual = int(int(page) - 1)
            idm = ['[B][COLOR gold]PÁGINA %s[/COLOR][/B]'%number if number == atual else '[B]PÁGINA %s[/B]'%number for number in range(1,total + 1)]
            index = dialog.select('ESCOLHA UMA PÁGINA: [B][COLOR gold]ATUAL %s[/COLOR][/B]'%atual, idm)
            if index >= 0:
                nextpage = True
                page = index + 1
            else:
                html = ''
        listar = re.compile('\x3c\x70\x61\x67\x65\x5f\x7b\x30\x7d\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x70\x61\x67\x65\x5f\x7b\x30\x7d\x3e'.format(page),re.MULTILINE|re.DOTALL).findall(html)
        if listar:
            item = re.compile('\x3c\x69\x74\x65\x6d\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x69\x74\x65\x6d\x3e',re.MULTILINE|re.DOTALL).findall(listar[0])
            getItems(item,fanart)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True if listar else False, updateListing=nextpage)
    elif url.startswith('#series_pages='):
        url,page = url.split('#series_pages=')[1].split('#')
        html = getMovieData(url)
        total = re.findall('<page_\d.*?>',html)
        nextpage = False
        if total and not page == '1':
            total = int(total[-1].replace('<page_','').replace('>',''))
            dialog = xbmcgui.Dialog()
            atual = int(int(page) - 1)
            idm = ['[B][COLOR gold]PÁGINA %s[/COLOR][/B]'%number if number == atual else '[B]PÁGINA %s[/B]'%number for number in range(1,total + 1)]
            index = dialog.select('ESCOLHA UMA PÁGINA: [B][COLOR gold]ATUAL %s[/COLOR][/B]'%atual, idm)
            if index >= 0:
                nextpage = True
                page = index + 1
            else:
                html = ''
        listar = re.compile('\x3c\x70\x61\x67\x65\x5f\x7b\x30\x7d\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x70\x61\x67\x65\x5f\x7b\x30\x7d\x3e'.format(page),re.MULTILINE|re.DOTALL).findall(html)
        if listar:
            item = re.compile('\x3c\x63\x68\x61\x6e\x6e\x65\x6c\x3e\x28\x2e\x2a\x3f\x29\x3c\x2f\x63\x68\x61\x6e\x6e\x65\x6c\x3e',re.MULTILINE|re.DOTALL).findall(listar[0])
            getData(item,fanart,chlist=True)
        xbmcplugin.endOfDirectory(addon_handle, succeeded=True if listar else False, updateListing=nextpage)
elif mode==28:
    if url.startswith('desenhos='):
        desenhos = url.split('desenhos=')[1]
        desenhos = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x65\x73\x65\x6e\x68\x6f\x73\x61\x6e\x69\x6d\x61\x64\x6f\x73\x2e\x73\x69\x74\x65\x2f\x25\x73'%desenhos)
        if not '\x3c\x75\x6c\x20\x63\x6c\x61\x73\x73\x3d\x22\x65\x70\x69\x73\x6f\x64\x69\x6f\x73\x22\x3e' in desenhos:
            notify('[B]DESENHO FORA DO AR![/B]')
        else:
            sinopse = re.compile('\x3c\x2f\x73\x74\x72\x6f\x6e\x67\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x70\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(desenhos)[0]
            if sinopse:
                sinopse = sinopse.replace("&#8220;","“").replace("&#8221;","”").replace("&#8217;","’")
            else:
                sinopse = 'Sem sinopse.'
            listar = re.compile('\x3c\x75\x6c\x20\x63\x6c\x61\x73\x73\x3d\x22\x65\x70\x69\x73\x6f\x64\x69\x6f\x73\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x70\x6f\x73\x74\x2d\x63\x6f\x6d\x65\x6e\x74\x61\x72\x69\x6f\x73\x22\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(desenhos)[0]
            episodios = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x2e\x2b\x3f\x3c\x68\x32\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x68\x32\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
            count_ep = 1
            for link,title in episodios:
                title = title.split('- ')[-1].upper()
                title = title.replace('EPISODIO','EPISÓDIO')
                if not 'EPISÓDIO' in title:
                    title = 'EPISÓDIO %s - '%str(count_ep) + title
                addLink('[B]%s[/B]'%title,link,16,iconimage,fanart,sinopse,'','')
                count_ep = count_ep + 1
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('desenhos2='):
        cookies = {'\x5f\x5f\x64\x64\x67\x69\x64\x5f':'\x72\x41\x63\x62\x33\x68\x32\x6b\x66\x70\x41\x73\x45\x58\x72\x68',
                   '\x5f\x5f\x64\x64\x67\x32\x5f':'\x65\x59\x38\x4c\x52\x4f\x30\x59\x66\x4a\x34\x34\x4d\x56\x55\x31',
                   '\x5f\x5f\x64\x64\x67\x31\x5f':'\x50\x68\x73\x4c\x35\x37\x72\x58\x50\x57\x6a\x59\x53\x4c\x65\x49\x56\x50\x35\x31'
        }
        desenhos = url.split('desenhos2=')[1]
        desenhos = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x61\x6e\x69\x6d\x65\x73\x6f\x6e\x6c\x69\x6e\x65\x70\x2e\x63\x6f\x6d\x2f\x76\x69\x64\x65\x6f\x2f\x25\x73'%desenhos,cookies=cookies)
        desenhos = desenhos.replace("#038;","").replace("&#192;","À").replace("&#193;","Á").replace("&#194;","Â").replace("&#195;","Ã").replace("&#196;","Ä").replace("&#224;","à").replace("&#225;","á").replace("&#226;","â").replace("&#227;","ã").replace("&#228;","ä").replace("&#200;","È").replace("&#201;","È").replace("&#202;","Ê").replace("&#203;","Ë").replace("&#232;","è").replace("&#233;","é").replace("&#234;","ê").replace("&#235;","ë").replace("&#204;","Ì").replace("&#205;","Í").replace("&#206;","Î").replace("&#207;","Ï").replace("&#236;","ì").replace("&#237;","í").replace("&#238;","î").replace("&#239;","ï").replace("&#211;","Ó").replace("&#243;","ó").replace("&#212;","Ô").replace("&#244;","ô").replace("&#244;","ô").replace("&#213;","Õ").replace("&#245;","õ").replace("&#217;","Ù").replace("&#218;","Ú").replace("&#219;","Û").replace("&#220;","Ü").replace("&#249;","ù").replace("&#250;","ú").replace("&#251;","û").replace("&#252;","ü").replace("&#199;","Ç").replace("&#231;","ç").replace("&#8230;","...").replace("&#038;","&").replace("&#8211;","–").replace("&#8217;","'").replace('&#147;','“').replace('&#148;','”').replace('&#34;','"').replace(" \n\n\t\t \n\t\t", "").replace("\n\t\t \n\t\t ", "").replace(r"\xc1","Á").replace(r"\xea","ê").replace(r"\xe7","ç").replace(r"\xe3","ã").replace(r"\xe9","é").replace(r"\xed","í").replace(r"\xe1","á").replace(r"\xe3","ó").replace(r"\xe0","à").replace(r"\xe0","à").replace(r"\xe2","â").replace("&#039;","'")
        try:
            sinopse = re.compile('\x3c\x70\x20\x69\x64\x3d\x22\x73\x69\x6e\x6f\x70\x73\x65\x32\x22\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x70\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(desenhos)[0]
        except:
            sinopse = None
        if sinopse:
            sinopse = sinopse.replace("&#8220;","“").replace("&#8221;","”").replace("&#8217;","’")
        else:
            sinopse = 'Sem sinopse.'
        listar = re.compile('\x3c\x75\x6c\x20\x63\x6c\x61\x73\x73\x3d\x22\x6c\x63\x70\x5f\x63\x61\x74\x6c\x69\x73\x74\x22\x20\x69\x64\x3d\x22\x6c\x63\x70\x5f\x69\x6e\x73\x74\x61\x6e\x63\x65\x5f\x30\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x64\x69\x76\x3e', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(desenhos)[0]
        episodios = re.compile('\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x20\x74\x69\x74\x6c\x65\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
        if len(episodios) == 0:
            notify('[B][COLOR gold]DESENHO INDISPONÍVEL.[/COLOR][/B]')
            exit()
        elif len(episodios) == 1:
            error = episodios[0][1].split('– ')[-1].upper()
            error = error.replace('EPISODIO','EPISÓDIO')
            if error == 'TODOS OS EPISÓDIOS':
                notify('[B][COLOR gold]DESENHO INDISPONÍVEL.[/COLOR][/B]')
                exit()
        count_ep = 1
        for link,title in episodios:
            title = title.split('– ')[-1].upper()
            title = title.replace('EPISODIO','EPISÓDIO')
            if not 'EPISÓDIO' in title:
                title = 'EPISÓDIO %s - '%str(count_ep) + title
            if not title == 'TODOS OS EPISÓDIOS':
                addLink('[B]%s[/B]'%title,link,16,iconimage,fanart,sinopse,'','')
                count_ep = count_ep + 1
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#desenhos_menu'):
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x44\x65\x73\x65\x6e\x68\x6f\x73\x42\x61\x73\x65'
        try:
            if features_enable == 'true' and not features_pass == '':
                hashed_pw_verify = features_checker()
                if hashed_pw_verify:
                    link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x62\x69\x74\x2e\x6c\x79\x2f' + hashed_pw_verify + features_pass + 'des'
        except:
            pass
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]PESQUISAR DESENHOS[/COLOR][/B]','#pesquisar_desenhos',28,iconimage,fanart,'[B][COLOR white]PESQUISE SEU DESENHO FAVORITO[/COLOR][/B]','','')
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]TODOS DESENHOS[/COLOR][/B]',link,1,iconimage,fanart,'[B][COLOR white]OS MELHORES DESENHOS DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#pesquisar_desenhos'):
        if pesquisa_desativar == 'false':
            if search == '':
                search = get_search_string('PESQUISE SEU DESENHO FAVORITO')
                if search:
                    if search == '' or search == ' ' or search == '  ':
                        pesquisa_desativar = 'false'
                        search = ''
                        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                    pesquisa_desativar = 'true'
                    pesquisar_desenhos()
                    xbmcplugin.endOfDirectory(addon_handle)
                    monitor_switch()
                    xbmc.executebuiltin('Container.SetViewMode(54)')
                else:
                    pesquisa_desativar = 'false'
                    search = ''
                    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        else:
            pesquisar_desenhos()
            xbmcplugin.endOfDirectory(addon_handle)
            monitor_switch()
            xbmc.executebuiltin('Container.SetViewMode(54)')
elif mode==29:
    if 'sfserie=' in url:
        if six.PY2: notify("[B]Recomendamos assistir essa série no [COLOR gold]Kodi 20.4[/COLOR] ou superior.[/B]")
        url = url.replace('sfserie=','')
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x74\x65\x6c\x61\x6d\x69\x78\x2e\x6e\x65\x74\x2f' + url
        url = getMovieData(link)
        dados = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x62\x64\x22\x3e\x28\x2e\x2a\x29\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x63\x6f\x6d\x6d\x65\x6e\x74\x73\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
        dados = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x61\x61\x2d\x64\x72\x70\x20\x63\x68\x6f\x6f\x73\x65\x2d\x73\x65\x61\x73\x6f\x6e\x22\x3e\x2e\x2b\x3f\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(dados)
        try:
            if len(dados) > 1:
                for data in range(len(dados)):
                    temp = data + 1
                    temp = str(temp) + 'ª TEMPORADA'
                    addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,dados[data]+'#temp='+str(data),29,iconimage,fanart,description,'','')
                xbmcplugin.endOfDirectory(addon_handle)
            else:
                listar = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x62\x64\x22\x3e\x28\x2e\x2a\x29\x3c\x66\x6f\x6f\x74\x65\x72', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
                episodios = re.compile('\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x6e\x75\x6d\x2d\x65\x70\x69\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e\x2e\x2b\x3f\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(listar)
                temp = '1'
                temp_name = '1ª TEMPORADA'
                addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp_name,'here',16,iconimage,fanart,description,'','')
                for title,link in episodios:
                    if 'x' in title:
                        for number in range(50):
                            try:
                                title = title.replace(str(number) + 'x','')
                            except:
                                pass
                    title = title.upper()
                    title = title.replace(str(temp) + 'X','')
                    addLink('[B]EPISÓDIO %s[/B]'%title,link,16,iconimage,fanart,description,'','')
                xbmcplugin.endOfDirectory(addon_handle)
        except:
            notify('[B][COLOR gold]SÉRIE INDISPONÍVEL![/COLOR][/B]')
            exit()
    elif '#temp=' in url:
        temp = url.split('#temp=')[1]
        url = url.split('#temp=')[0]
        url = getMovieData(url)
        dados = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x62\x64\x22\x3e\x28\x2e\x2a\x29\x3c\x66\x6f\x6f\x74\x65\x72', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(url)[0]
        episodios = re.compile('\x3c\x73\x70\x61\x6e\x20\x63\x6c\x61\x73\x73\x3d\x22\x6e\x75\x6d\x2d\x65\x70\x69\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x73\x70\x61\x6e\x3e\x2e\x2b\x3f\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22', re.MULTILINE|re.DOTALL|re.IGNORECASE).findall(dados)
        if len(episodios) == 0:
            notify('[B][COLOR gold]TEMPORADA INDISPONÍVEL![/COLOR][/B]')
            exit()
        temp = int(temp) + 1
        temp_name = str(temp) + 'ª TEMPORADA'
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp_name,'here',16,iconimage,fanart,description,'','')
        for title,link in episodios:
            title = title.upper()
            title = title.replace(str(temp) + 'X','')
            addLink('[B]EPISÓDIO %s[/B]'%title,link,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
elif mode==30:
    if 'wvmob=' in url:
        if features_enable == 'true' and not features_pass == '':
            if not features_checker():
                xbmcgui.Dialog().ok('Aviso:', '[B]Opção indisponível - Reinicie seu Kodi.[/B]')
                exit()
        else:
            xbmcgui.Dialog().ok('Aviso:', '[B]Opção indisponível - Reinicie seu Kodi.[/B]')
            exit()
        if six.PY2:
            notify("[B]Essa opção só funciona no [COLOR gold]Kodi 20.4[/COLOR] ou superior.[/B]")
            exit()
        WOVY_URI = decode(features_pass, WOVY_URL)
        serie_id = '\x25\x73\x2f\x74\x76\x2f\x25\x73'%(WOVY_URI,url.split('wvmob=')[1])
        serie_refer = '\x25\x73\x2f\x74\x76\x2d\x73\x68\x6f\x77\x73'%WOVY_URI
        wvmob_user = ''
        if not xbmcaddon.Addon().getSetting("wvmob_user"):
            wvmob_time = str(time.time()).split('.')[0]
            wvmob_time = datetime.fromtimestamp(int(wvmob_time)) + timedelta(hours=5)
            params = '\x7b\x27\x77\x76\x6d\x6f\x62\x27\x3a\x20\x31\x7d'
            params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
            wvmob_user = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params))
            wvmob_user = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(wvmob_user)[0]
            addon.setSetting("wvmob_user",str(wvmob_user))
            addon.setSetting("wvmob_time",str(wvmob_time.timestamp()).split('.')[0])
        elif xbmcaddon.Addon().getSetting("wvmob_time") and int(xbmcaddon.Addon().getSetting("wvmob_time")) <= int(str(time.time()).split('.')[0]):
            wvmob_time = str(time.time()).split('.')[0]
            wvmob_time = datetime.fromtimestamp(int(wvmob_time)) + timedelta(hours=5)
            params = '\x7b\x27\x77\x76\x6d\x6f\x62\x27\x3a\x20\x31\x7d'
            params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
            wvmob_user = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params))
            wvmob_user = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(wvmob_user)[0]
            addon.setSetting("wvmob_user",str(wvmob_user))
            addon.setSetting("wvmob_time",str(wvmob_time.timestamp()).split('.')[0])
        else:
            wvmob_user = xbmcaddon.Addon().getSetting("wvmob_user")
        html = getWVMData(serie_id,serie_refer,wvmob_user).replace("'",'"').replace('    ','')
        try:
            listar = re.findall('\x3c\x64\x69\x76\x20\x78\x2d\x73\x68\x6f\x77\x3d\x22\x73\x65\x61\x73\x6f\x6e\x4d\x6f\x64\x61\x6c\x4f\x70\x65\x6e\x22\x2e\x2a\x3f\x3c\x64\x69\x76\x20\x78\x2d\x73\x68\x6f\x77\x3d\x22\x74\x72\x61\x69\x6c\x65\x72\x4f\x70\x65\x6e\x22', html, re.DOTALL)[0].replace('\n','').replace('\r','')
        except:
            wvmob_time = str(time.time()).split('.')[0]
            wvmob_time = datetime.fromtimestamp(int(wvmob_time)) + timedelta(hours=5)
            params = '\x7b\x27\x77\x76\x6d\x6f\x62\x27\x3a\x20\x31\x7d'
            params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
            wvmob_user = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params))
            wvmob_user = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(wvmob_user)[0]
            addon.setSetting("wvmob_user",str(wvmob_user))
            addon.setSetting("wvmob_time",str(wvmob_time.timestamp()).split('.')[0])
            serie = getWVMData(serie_id,serie_refer,wvmob_user).replace('    ','')
        try:
            listar = re.findall('\x3c\x64\x69\x76\x20\x78\x2d\x73\x68\x6f\x77\x3d\x22\x73\x65\x61\x73\x6f\x6e\x4d\x6f\x64\x61\x6c\x4f\x70\x65\x6e\x22\x2e\x2a\x3f\x3c\x64\x69\x76\x20\x78\x2d\x73\x68\x6f\x77\x3d\x22\x74\x72\x61\x69\x6c\x65\x72\x4f\x70\x65\x6e\x22', html, re.DOTALL)[0].replace('\n','').replace('\r','')
        except:
            notify('[B]Houve um problema na conexão - Tente novamente mais tarde.[/B]')
            exit()
        seasons = re.findall('\x3c\x62\x75\x74\x74\x6f\x6e\x5b\x5e\x3e\x5d\x2a\x3f\x77\x69\x72\x65\x3a\x63\x6c\x69\x63\x6b\x3d\x22\x5c\x24\x73\x65\x74\x5c\x28\x22\x73\x65\x6c\x65\x63\x74\x65\x64\x22\x2c\x5c\x73\x2a\x28\x5c\x64\x2b\x29\x5c\x29\x22', listar)
        if len(seasons) > 1:
            for season in seasons:
                addDir('[B][COLOR white]%sª TEMPORADA[/COLOR][/B]'%season,[(season,serie_id,wvmob_user)],30,iconimage,fanart,description,'','')
            xbmcplugin.endOfDirectory(addon_handle)
        else:
            addLink('[B][COLOR gold]%sª TEMPORADA[/COLOR][/B]'%seasons[0],'here',16,iconimage,fanart,description,'','')
            # Regex para capturar todos os episódios
            pattern = re.compile(
                '\x3c\x61\x5c\x73\x2b\x68\x72\x65\x66\x3d\x22\x28\x3f\x50\x3c\x6c\x69\x6e\x6b\x3e\x5b\x5e\x22\x5d\x2b\x29\x22\x5b\x5e\x3e\x5d\x2a\x3f\x3e\x5c\x73\x2a'
                '\x3c\x64\x69\x76\x5b\x5e\x3e\x5d\x2a\x3f\x3e\x5c\x73\x2a\x28\x3f\x50\x3c\x6e\x75\x6d\x3e\x5c\x64\x2b\x29\x5c\x73\x2a\x3c\x2f\x64\x69\x76\x3e\x5c\x73\x2a'
                '\x3c\x64\x69\x76\x5b\x5e\x3e\x5d\x2a\x3f\x63\x6c\x61\x73\x73\x3d\x22\x6c\x69\x6e\x65\x2d\x63\x6c\x61\x6d\x70\x2d\x31\x22\x3e\x5c\x73\x2a\x28\x3f\x50\x3c\x74\x69\x74\x75\x6c\x6f\x3e\x5b\x5e\x3c\x5d\x2b\x29\x5c\x73\x2a\x3c\x2f\x64\x69\x76\x3e',
                re.DOTALL
            )
            # Encontrar todos os episódios
            episodios = pattern.findall(html)
            # Exibir todos os episódios
            for link, num, titulo in episodios:
                if not 'EPISÓDIO %s'%num in titulo.upper():
                    addLink('[B]EPISÓDIO %s - %s[/B]'%(num,titulo.upper()),[link,serie_id,wvmob_user],16,iconimage,fanart,description,'','')
                else:
                    addLink('[B]EPISÓDIO %s[/B]'%num,[link,serie_id,wvmob_user],16,iconimage,fanart,description,'','')
            xbmcplugin.endOfDirectory(addon_handle)
    elif '/tv/' in url:
        import ast
        url = ast.literal_eval(url)
        season = url[0][0]
        page_url = url[0][1]
        agent = url[0][2]
        addLink('[B][COLOR gold]%sª TEMPORADA[/COLOR][/B]'%season,'here',16,iconimage,fanart,description,'','')
        html = wovy_seasonslinks(page_url,season,agent)
        # Regex para capturar todos os episódios
        pattern = re.compile(
            '\x3c\x61\x5c\x73\x2b\x68\x72\x65\x66\x3d\x22\x28\x3f\x50\x3c\x6c\x69\x6e\x6b\x3e\x5b\x5e\x22\x5d\x2b\x29\x22\x5b\x5e\x3e\x5d\x2a\x3f\x3e\x5c\x73\x2a'
            '\x3c\x64\x69\x76\x5b\x5e\x3e\x5d\x2a\x3f\x3e\x5c\x73\x2a\x28\x3f\x50\x3c\x6e\x75\x6d\x3e\x5c\x64\x2b\x29\x5c\x73\x2a\x3c\x2f\x64\x69\x76\x3e\x5c\x73\x2a'
            '\x3c\x64\x69\x76\x5b\x5e\x3e\x5d\x2a\x3f\x63\x6c\x61\x73\x73\x3d\x22\x6c\x69\x6e\x65\x2d\x63\x6c\x61\x6d\x70\x2d\x31\x22\x3e\x5c\x73\x2a\x28\x3f\x50\x3c\x74\x69\x74\x75\x6c\x6f\x3e\x5b\x5e\x3c\x5d\x2b\x29\x5c\x73\x2a\x3c\x2f\x64\x69\x76\x3e',
            re.DOTALL
        )
        # Encontrar todos os episódios
        episodios = pattern.findall(html)
        # Exibir todos os episódios
        for link, num, titulo in episodios:
            if not 'EPISÓDIO %s'%num in titulo.upper():
                addLink('[B]EPISÓDIO %s - %s[/B]'%(num,titulo.upper()),[link,page_url,wvmob_user],16,iconimage,fanart,description,'','')
            else:
                addLink('[B]EPISÓDIO %s[/B]'%num,[link,page_url,wvmob_user],16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
elif mode==31:
    if url.startswith('resolver1_tvshows='):
        content_status['watch_later_url'] = url
        content_status['watch_later_name'] = name
        link = url.split('resolver1_tvshows=')[1]
        params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x31\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x74\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%link
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Séries Resolver 1 - Código: 404[/COLOR][/B]')
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        if html == 'API Under Maintenance':
            html = 'eydzdGF0dXMnOiAnQVBJIFVuZGVyIE1haW50ZW5hbmNlJ30='
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 1: [COLOR gold]API em manutenção[/COLOR][/B]')
        html = base64.b64decode(html.encode('utf-8')).decode('utf-8') if html else ''
        import ast
        params = ast.literal_eval(html) if html else {}
        if six.PY2:
            from collections import OrderedDict
            def extract_season_number(key):
                match = re.search(r'(\d+)', key)
                return int(match.group(1)) if match else 0
            params = dict(params)
            params = OrderedDict(sorted(params.items(), key=lambda x: extract_season_number(x[0])))
        if 'API Under Maintenance' in html:
            html = ''
        elif not params:
            xbmcgui.Dialog().ok('Aviso:', '[B]Erro 404: [COLOR gold]Série indisponível no momento![/COLOR][/B]')
        elif len(params) > 1:
            for temp, value in params.items():
                if not str(value) == '[]':
                    temp = temp.replace('° Temporada','').replace(' ','').replace('Season','') + 'ª TEMPORADA'
                    temp = re.sub('<.+>', '', temp)
                    addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(temp,value,'#resolver1_temp=')],31,iconimage,fanart,description,'','')
        else:
            for temp, value in params.items():
                temp = temp.replace('° Temporada','').replace(' ','').replace('Season','') + 'ª TEMPORADA'
                temp = re.sub('<.+>', '', temp)
                episodes = ast.literal_eval(value)
                addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
                for episode in episodes:
                    subtitle = corrigir_texto(episode[2], 'upper')
                    title = 'EPISÓDIO ' + re.sub('(.*) - ', '', episode[0])
                    title += ' - %s'%subtitle if not title in subtitle else ''
                    info = '[B][COLOR gold]Título: [/COLOR]%s[/B][CR]'%corrigir_texto(episode[2]) + description
                    addLink('[B]%s[/B]'%title,episode[1],16,iconimage,fanart,info,'','')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=bool(html))
    elif '#resolver1_temp=' in url:
        content_status['watch_later_season'] = name
        import ast
        url = ast.literal_eval(url)
        temp = url[0][0]
        episodes = url[0][1]
        episodes = ast.literal_eval(episodes)
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
        for episode in episodes:
            subtitle = corrigir_texto(episode[2], 'upper')
            title = 'EPISÓDIO ' + re.sub('(.*) - ', '', episode[0])
            title += ' - %s'%subtitle if not title in subtitle else ''
            info = '[B][COLOR gold]Título: [/COLOR]%s[/B][CR]'%corrigir_texto(episode[2]) + description
            addLink('[B]%s[/B]'%title,episode[1],16,iconimage,fanart,info,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('resolver2_tvshows='):
        content_status['watch_later_url'] = url
        content_status['watch_later_name'] = name
        link = url.split('resolver2_tvshows=')[1]
        params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x32\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x74\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%link
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Séries Resolver 2 - Código: 404[/COLOR][/B]')
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        if html == 'API Under Maintenance':
            html = 'eydzdGF0dXMnOiAnQVBJIFVuZGVyIE1haW50ZW5hbmNlJ30='
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 2: [COLOR gold]API em manutenção[/COLOR][/B]')
        html = base64.b64decode(html.encode('utf-8')).decode('utf-8') if html else ''
        import ast
        params = ast.literal_eval(html) if html else {}
        if six.PY2:
            from collections import OrderedDict
            def extract_season(key):
                match = re.search(r'Temporada (\d+)', key)
                return int(match.group(1)) if match else 0
            params = OrderedDict(sorted(params.items(), key=lambda x: extract_season(x[0])))
        if 'API Under Maintenance' in html:
            html = ''
        elif not params:
            xbmcgui.Dialog().ok('Aviso:', '[B]Erro 404: [COLOR gold]Série indisponível no momento![/COLOR][/B]')
        elif len(params) > 1:
            for temp, value in params.items():
                if not str(value) == '[]':
                    temp = temp.replace('Temporada ','').replace(' ','').replace('Season','') + 'ª TEMPORADA'
                    temp = re.sub('<.+>', '', temp)
                    addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(temp,value,'#resolver2_temp=')],31,iconimage,fanart,description,'','')
        else:
            for temp, value in params.items():
                temp = temp.replace('Temporada ','').replace(' ','').replace('Season','') + 'ª TEMPORADA'
                temp = re.sub('<.+>', '', temp)
                episodes = ast.literal_eval(value)
                addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
                for episode in episodes:
                    subtitle = corrigir_texto(episode[2], 'upper')
                    title = 'EPISÓDIO ' + re.sub('(.*) - ', '', episode[0])
                    title += ' - %s'%subtitle if not title in subtitle else ''
                    info = '[B][COLOR gold]Título: [/COLOR]%s[/B][CR]'%corrigir_texto(episode[2]) + description
                    addLink('[B]%s[/B]'%title,episode[1],16,iconimage,fanart,info,'','')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=bool(html))
    elif '#resolver2_temp=' in url:
        content_status['watch_later_season'] = name
        import ast
        url = ast.literal_eval(url)
        temp = url[0][0]
        episodes = url[0][1]
        episodes = ast.literal_eval(episodes)
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
        for episode in episodes:
            subtitle = corrigir_texto(episode[2], 'upper')
            title = 'EPISÓDIO ' + re.sub('(.*) - ', '', episode[0])
            title += ' - %s'%subtitle if not title in subtitle else ''
            info = '[B][COLOR gold]Título: [/COLOR]%s[/B][CR]'%corrigir_texto(episode[2]) + description
            addLink('[B]%s[/B]'%title,episode[1],16,iconimage,fanart,info,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('resolver3_tvshows='):
        link = url.split('resolver3_tvshows=')[1]
        params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x33\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x74\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%link
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Séries Resolver 3 - Código: 404[/COLOR][/B]')
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        if html == 'API Under Maintenance':
            html = 'eydzdGF0dXMnOiAnQVBJIFVuZGVyIE1haW50ZW5hbmNlJ30='
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 3: [COLOR gold]API em manutenção[/COLOR][/B]')
        html = base64.b64decode(html.encode('utf-8')).decode('utf-8') if html else ''
        import ast
        params = ast.literal_eval(html) if html else {}
        if 'API Under Maintenance' in html:
            html = ''
        elif not params:
            xbmcgui.Dialog().ok('Aviso:', '[B]Erro 404: [COLOR gold]Série indisponível no momento![/COLOR][/B]')
        elif len(params) > 1:
            for temp, value in params:
                if not str(value) == '[]':
                    temp = temp + 'ª TEMPORADA'
                    if "'dub'" in str(value) and "'leg'" in str(value):
                        addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(link,temp,value,'#resolver3_temp_language=')],31,iconimage,fanart,description,'','')
                    else:
                        addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(link,temp,value,'single','#resolver3_temp=')],31,iconimage,fanart,description,'','')
        else:
            for temp, value in params:
                if not str(value) == '[]':
                    temp = temp + 'ª TEMPORADA'
                    if "'dub'" in str(value) and "'leg'" in str(value):
                        addDir('[B][COLOR white]ASSISTIR DUBLADO[/COLOR][/B]',[(link,temp,value,'dub','#resolver3_temp=')],31,iconimage,fanart,description,'','')
                        addDir('[B][COLOR white]ASSISTIR LEGENDADO[/COLOR][/B]',[(link,temp,value,'leg','#resolver3_temp=')],31,iconimage,fanart,description,'','')
                    else:
                        episodes = ast.literal_eval(str(value))
                        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
                        for season,episode,language in episodes:
                            title = 'EPISÓDIO ' + episode
                            addLink('[B]%s[/B]'%title,'resolver3_episodes=%s#%s#%s#%s'%(link,season,episode,language),16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=bool(html))
    elif '#resolver3_temp_language=' in url:
        import ast
        url = ast.literal_eval(url)
        link,temp,value,resolver = url[0]
        addDir('[B][COLOR white]ASSISTIR DUBLADO[/COLOR][/B]',[(link,temp,value,'dub','#resolver3_temp=')],31,iconimage,fanart,description,'','')
        addDir('[B][COLOR white]ASSISTIR LEGENDADO[/COLOR][/B]',[(link,temp,value,'leg','#resolver3_temp=')],31,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#resolver3_temp=' in url:
        import ast
        url = ast.literal_eval(url)
        link = url[0][0]
        temp = url[0][1]
        episodes = url[0][2]
        lang = url[0][3]
        serie_name = url[0][0]
        episodes = ast.literal_eval(str(episodes))
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
        for season,episode,language in episodes:
            if language == lang:
                title = 'EPISÓDIO ' + episode
                addLink('[B]%s[/B]'%title,'resolver3_episodes=%s#%s#%s#%s'%(serie_name,season,episode,language),16,iconimage,fanart,description,'','')
            elif lang == 'single':
                title = 'EPISÓDIO ' + episode
                addLink('[B]%s[/B]'%title,'resolver3_episodes=%s#%s#%s#%s'%(serie_name,season,episode,language),16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('resolver4_tvshows='):
        link = url.split('resolver4_tvshows=')[1]
        params = '\x7b\x27\x72\x65\x73\x6f\x6c\x76\x65\x72\x27\x3a\x20\x34\x2c\x20\x27\x72\x65\x71\x75\x65\x73\x74\x27\x3a\x20\x27\x74\x76\x73\x68\x6f\x77\x73\x3d\x25\x73\x27\x7d'%link
        params = base64.b64encode(params.encode('utf-8')).decode('utf-8')
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x65\x65\x6b\x61\x6e\x74\x65\x6e\x61\x64\x6f\x2e\x66\x6c\x79\x2e\x64\x65\x76\x2f\x3f\x72\x65\x73\x6f\x6c\x76\x65\x72\x3d'+str(params), timeout=30)
        if html == '\x3c\x64\x69\x76\x20\x69\x64\x3d\x22\x64\x69\x76\x22\x20\x73\x74\x79\x6c\x65\x3d\x22\x64\x69\x73\x70\x6c\x61\x79\x3a\x6e\x6f\x6e\x65\x22\x3e\x3c\x2f\x64\x69\x76\x3e':
            xbmcgui.Dialog().ok('Aviso:', '[B]Tente novamente - caso continue avise um moderador sobre esse problema.[CR][COLOR gold]Séries Resolver 4 - Código: 404[/COLOR][/B]')
        html = re.compile('\x3c\x64\x69\x76\x2e\x2b\x3f\x3e\x28\x2e\x2b\x3f\x29\x3c\x5c\x2f\x64\x69\x76\x3e',re.MULTILINE|re.IGNORECASE|re.DOTALL).findall(html)[0]
        if html == 'API Under Maintenance':
            html = 'eydzdGF0dXMnOiAnQVBJIFVuZGVyIE1haW50ZW5hbmNlJ30='
            xbmcgui.Dialog().ok('Aviso:', '[B]Resolver 4: [COLOR gold]API em manutenção[/COLOR][/B]')
        html = base64.b64decode(html.encode('utf-8')).decode('utf-8') if html else ''
        import ast
        params = ast.literal_eval(html) if html else {}
        if six.PY2:
            from collections import OrderedDict
            def extract_season(key):
                match = re.search(r'Season (\d+)', key)
                return int(match.group(1)) if match else 0
            params = OrderedDict(sorted(params.items(), key=lambda x: extract_season(x[0])))
        if 'API Under Maintenance' in html:
            html = ''
        elif not params:
            xbmcgui.Dialog().ok('Aviso:', '[B]Erro 404: [COLOR gold]Série indisponível no momento![/COLOR][/B]')
        elif len(params) > 1:
            for temp, value in params.items():
                if not str(value) == '[]':
                    temp = temp.replace('° Temporada','').replace(' ','').replace('Season','') + 'ª TEMPORADA'
                    temp = re.sub('<.+>', '', temp)
                    addDir('[B][COLOR white]%s[/COLOR][/B]'%temp,[(temp,value,'#resolver4_temp=')],31,iconimage,fanart,description,'','')
        else:
            for temp, value in params.items():
                temp = temp.replace('° Temporada','').replace(' ','').replace('Season','') + 'ª TEMPORADA'
                temp = re.sub('<.+>', '', temp)
                episodes = ast.literal_eval(value)
                addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
                for episode in episodes:
                    subtitle = corrigir_texto(episode[2], 'upper')
                    title = 'EPISÓDIO ' + re.sub('(.*) - ', '', episode[0])
                    title += ' - %s'%subtitle if not title in subtitle else ''
                    info = '[B][COLOR gold]Título: [/COLOR]%s[/B][CR]'%corrigir_texto(episode[2]) + description
                    addLink('[B]%s[/B]'%title,episode[1],16,iconimage,fanart,info,'','')
        xbmcplugin.endOfDirectory(addon_handle, succeeded=bool(html))
    elif '#resolver4_temp=' in url:
        import ast
        url = ast.literal_eval(url)
        temp = url[0][0]
        episodes = url[0][1]
        episodes = ast.literal_eval(episodes)
        addLink('[B][COLOR gold]%s[/COLOR][/B]'%temp,'here',31,iconimage,fanart,description,'','')
        for episode in episodes:
            subtitle = corrigir_texto(episode[2], 'upper')
            title = 'EPISÓDIO ' + re.sub('(.*) - ', '', episode[0])
            title += ' - %s'%subtitle if not title in subtitle else ''
            info = '[B][COLOR gold]Título: [/COLOR]%s[/B][CR]'%corrigir_texto(episode[2]) + description
            addLink('[B]%s[/B]'%title,episode[1],16,iconimage,fanart,info,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('onedrive='):
        try:
            import ast
            import json
            url = ast.literal_eval(url.split('onedrive=')[1])
            count = 1
            if len(url) > 1:
                for temp in url:
                    addDir('[B][COLOR white]%sª TEMPORADA[/COLOR][/B]'%count,[(temp,'#onedrive_temp=')],31,iconimage,fanart,description,'','')
                    count += 1
            else:
                token,auth = url[0]
                html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x70\x69\x2e\x6f\x6e\x65\x64\x72\x69\x76\x65\x2e\x63\x6f\x6d\x2f\x76\x31\x2e\x30\x2f\x64\x72\x69\x76\x65\x73\x2f\x7b\x30\x7d\x2f\x69\x74\x65\x6d\x73\x2f\x7b\x31\x7d\x2f\x63\x68\x69\x6c\x64\x72\x65\x6e\x3f\x25\x32\x34\x74\x6f\x70\x3d\x31\x30\x30\x26\x25\x32\x34\x65\x78\x70\x61\x6e\x64\x3d\x74\x68\x75\x6d\x62\x6e\x61\x69\x6c\x73\x25\x32\x43\x6c\x65\x6e\x73\x65\x73\x25\x32\x43\x74\x61\x67\x73\x26\x73\x65\x6c\x65\x63\x74\x3d\x2a\x25\x32\x43\x6f\x63\x72\x25\x32\x43\x77\x65\x62\x44\x61\x76\x55\x72\x6c\x25\x32\x43\x73\x68\x61\x72\x65\x70\x6f\x69\x6e\x74\x49\x64\x73\x25\x32\x43\x69\x73\x52\x65\x73\x74\x72\x69\x63\x74\x65\x64\x25\x32\x43\x63\x6f\x6d\x6d\x65\x6e\x74\x53\x65\x74\x74\x69\x6e\x67\x73\x25\x32\x43\x73\x70\x65\x63\x69\x61\x6c\x46\x6f\x6c\x64\x65\x72\x25\x32\x43\x63\x6f\x6e\x74\x61\x69\x6e\x69\x6e\x67\x44\x72\x69\x76\x65\x50\x6f\x6c\x69\x63\x79\x53\x63\x65\x6e\x61\x72\x69\x6f\x56\x69\x65\x77\x70\x6f\x69\x6e\x74\x26\x75\x6d\x70\x3d\x31\x26\x61\x75\x74\x68\x4b\x65\x79\x3d\x7b\x32\x7d'.format(token.split('!')[0].lower(),token,auth))
                listar = json.loads(html).get('value')
                count = 1
                for values in listar:
                    addLink('[B]EPISÓDIO %s[/B]'%count,'onedrive=%s'%values.get('@content.downloadUrl'),16,iconimage,fanart,description,'','')
                    count += 1
        except:
            xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]OneDrive - Código: 404[/COLOR][/B]')
        xbmcplugin.endOfDirectory(addon_handle)
    elif '#onedrive_temp=' in url:
        try:
            import ast
            url = ast.literal_eval(url)
            token,auth = url[0][0]
            html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x61\x70\x69\x2e\x6f\x6e\x65\x64\x72\x69\x76\x65\x2e\x63\x6f\x6d\x2f\x76\x31\x2e\x30\x2f\x64\x72\x69\x76\x65\x73\x2f\x7b\x30\x7d\x2f\x69\x74\x65\x6d\x73\x2f\x7b\x31\x7d\x2f\x63\x68\x69\x6c\x64\x72\x65\x6e\x3f\x25\x32\x34\x74\x6f\x70\x3d\x31\x30\x30\x26\x25\x32\x34\x65\x78\x70\x61\x6e\x64\x3d\x74\x68\x75\x6d\x62\x6e\x61\x69\x6c\x73\x25\x32\x43\x6c\x65\x6e\x73\x65\x73\x25\x32\x43\x74\x61\x67\x73\x26\x73\x65\x6c\x65\x63\x74\x3d\x2a\x25\x32\x43\x6f\x63\x72\x25\x32\x43\x77\x65\x62\x44\x61\x76\x55\x72\x6c\x25\x32\x43\x73\x68\x61\x72\x65\x70\x6f\x69\x6e\x74\x49\x64\x73\x25\x32\x43\x69\x73\x52\x65\x73\x74\x72\x69\x63\x74\x65\x64\x25\x32\x43\x63\x6f\x6d\x6d\x65\x6e\x74\x53\x65\x74\x74\x69\x6e\x67\x73\x25\x32\x43\x73\x70\x65\x63\x69\x61\x6c\x46\x6f\x6c\x64\x65\x72\x25\x32\x43\x63\x6f\x6e\x74\x61\x69\x6e\x69\x6e\x67\x44\x72\x69\x76\x65\x50\x6f\x6c\x69\x63\x79\x53\x63\x65\x6e\x61\x72\x69\x6f\x56\x69\x65\x77\x70\x6f\x69\x6e\x74\x26\x75\x6d\x70\x3d\x31\x26\x61\x75\x74\x68\x4b\x65\x79\x3d\x7b\x32\x7d'.format(token.split('!')[0].lower(),token,auth))
            listar = json.loads(html).get('value')
            count = 1
            for values in listar:
                addLink('[B]EPISÓDIO %s[/B]'%count,'onedrive=%s'%values.get('@content.downloadUrl'),16,iconimage,fanart,description,'','')
                count += 1
        except:
            xbmcgui.Dialog().ok('Aviso:', '[B]Avise um moderador sobre esse problema.[CR][COLOR gold]OneDrive - Código: 404[/COLOR][/B]')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('doramas_resolver1='):
        html = getMovieData('\x68\x74\x74\x70\x73\x3a\x2f\x2f\x64\x6f\x72\x61\x6d\x61\x73\x6f\x6e\x6c\x69\x6e\x65\x2e\x6f\x72\x67\x2f\x62\x72\x2f\x73\x65\x72\x69\x65\x73\x2f\x25\x73\x2f'%url.split('doramas_resolver1=')[1]).replace("'",'"').replace(' </div>','</div>')
        if '\x3c\x62\x6f\x64\x79\x20\x69\x64\x3d\x22\x65\x72\x72\x6f\x72\x2d\x70\x61\x67\x65\x22\x3e' in html:
            xbmcgui.Dialog().ok('Aviso:', '[B]Em manutenção - Aguarde...[/B]')
            exit()
        if not re.findall('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x75\x6c\x3e',html):
            xbmcgui.Dialog().ok('Aviso:', '[B]Erro ao carregar o Dorama - Avise um moderador ou aguarde a atualização.[/B]')
            exit()
        seasons = re.compile('\x3c\x64\x69\x76\x20\x63\x6c\x61\x73\x73\x3d\x22\x73\x65\x2d\x63\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x75\x6c\x3e',re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(html)
        for ignore in seasons:
            if '\x3c\x6c\x69\x20\x63\x6c\x61\x73\x73\x3d\x22\x6e\x6f\x6e\x65\x22\x3e' in ignore:
                seasons.pop()
        if len(seasons) > 1:
            count_temp = 1
            for season in seasons:
                addDir('[B][COLOR white]%sª TEMPORADA[/COLOR][/B]'%count_temp,'doramas_resolver1_temp=%s'%season,31,iconimage,fanart,description,'','')
                count_temp += 1
        else:
            addLink('[B][COLOR gold]1ª TEMPORADA[/COLOR][/B]','here',16,iconimage,fanart,description,'','')
            seasons = re.compile('\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e',re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(seasons[0])
            for season,title in seasons:
                addLink('[B]%s[/B]'%title.upper(),'doramas_resolver1='+season,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('doramas_resolver1_temp='):
        html = url.split('doramas_resolver1_temp=')[1]
        addLink(name.replace('[COLOR white]','[COLOR gold]'),'here',16,iconimage,fanart,description,'','')
        seasons = re.compile('\x3c\x61\x20\x68\x72\x65\x66\x3d\x22\x28\x2e\x2b\x3f\x29\x22\x3e\x28\x2e\x2b\x3f\x29\x3c\x2f\x61\x3e',re.IGNORECASE|re.DOTALL|re.MULTILINE).findall(html)
        for season,title in seasons:
            addLink('[B]%s[/B]'%title.upper(),'doramas_resolver1='+season,16,iconimage,fanart,description,'','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#doramas_menu'):
        link = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x73\x74\x2e\x67\x69\x74\x68\x75\x62\x75\x73\x65\x72\x63\x6f\x6e\x74\x65\x6e\x74\x2e\x63\x6f\x6d\x2f\x73\x6b\x79\x72\x69\x73\x6b\x2f\x31\x36\x30\x37\x30\x33\x34\x37\x66\x32\x30\x63\x38\x37\x63\x37\x32\x35\x34\x30\x66\x39\x66\x38\x30\x35\x62\x35\x37\x61\x36\x36\x2f\x72\x61\x77\x2f\x44\x6f\x72\x61\x6d\x61\x73\x42\x61\x73\x65'
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]PESQUISAR DORAMAS[/COLOR][/B]','#pesquisar_doramas',31,iconimage,fanart,'[B][COLOR white]PESQUISE SEU DORAMA FAVORITO[/COLOR][/B]','','')
        addDir('[B][COLOR blue]●[/COLOR][COLOR firebrick]●[/COLOR] [COLOR white]TODOS DORAMAS[/COLOR][/B]',link,1,iconimage,fanart,'[B][COLOR white]OS MELHORES DORAMAS DO [COLOR gold]MUNDO[/COLOR] EM UM SÓ LUGAR[/COLOR][/B]','','')
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#doramas_list='):
        series = url.split('#doramas_list=')[1]
        series = series.split('|')
        counter = 1
        name = name.replace('[B][COLOR white]●[/COLOR][/B] ','')
        if not description:
            description = '[B][COLOR white]OS MELHORES DORAMAS EM UM SÓ LUGAR[/COLOR][/B]'
        for serie in series:
            if serie.startswith('doramas_resolver1='):
                title = '[B][COLOR gold]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('resolver1_tvshows='):
                title = '[B][COLOR yellow]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('resolver3_tvshows='):
                title = '[B][COLOR skyblue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            elif serie.startswith('resolver4_tvshows='):
                title = '[B][COLOR mediumslateblue]OPÇÃO %s ●[/COLOR][/B] '%counter + name
                mode_select = 31
            else:
                continue
            addDir(title,serie,mode_select,iconimage,fanart,description,'','')
            counter = counter + 1
        xbmcplugin.endOfDirectory(addon_handle)
    elif url.startswith('#pesquisar_doramas'):
        if pesquisa_desativar == 'false':
            if search == '':
                search = get_search_string('PESQUISE SEU DORAMA FAVORITO')
                if search:
                    if search == '' or search == ' ' or search == '  ':
                        pesquisa_desativar = 'false'
                        search = ''
                        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
                    pesquisa_desativar = 'true'
                    pesquisar_doramas()
                    xbmcplugin.endOfDirectory(addon_handle)
                    monitor_switch()
                    xbmc.executebuiltin('Container.SetViewMode(54)')
                else:
                    pesquisa_desativar = 'false'
                    search = ''
                    xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        else:
            pesquisar_doramas()
            xbmcplugin.endOfDirectory(addon_handle)
            monitor_switch()
            xbmc.executebuiltin('Container.SetViewMode(54)')